function [] = eigen_test(A)
syms c
s = size(A);
eigenvalues = double(solve((det(A - c * eye(s)) == 0),c)); %Extracting Eigenvalues
realeig = real(eigenvalues);
imageig = imag(eigenvalues);
if all(realeig < 0) %Check eigenvalues for stability analysis
    disp('All of the system eigenvalues have negative real part. Thus,the system is stable.')
    h = figure('Color','white');
    datacursormode(h,'on');
    plot(realeig,imageig,'Marker','o','MarkerSize',6,'MarkerEdgeColor',[0 0.5 0],'MarkerFaceColor',[0 0.5 0],'LineWidth',2,'LineStyle','none')
    title('Eigenvalues Plot','fontweight','bold','fontsize',13)
    xlabel ('Real Axis (seconds^{-1})')
    ylabel ('Imaginary Axis (seconds^{-1})')
    grid on
    set (gca,'GridLineStyle',':') 
elseif all(realeig > 0)
    disp('All of the system eigenvalues have positive real part. Thus, the system is not stable.')
    h = figure('Color','white');
    datacursormode(h,'on');
    plot(realeig,imageig,'Marker','o','MarkerSize',6,'MarkerEdgeColor','red','MarkerFaceColor','red','LineWidth',2,'LineStyle','none')
    title('Eigenvalues Plot','fontweight','bold','fontsize',13)
    xlabel ('Real Axis (seconds^{-1})')
    ylabel ('Imaginary Axis (seconds^{-1})')
    grid on
    set (gca,'GridLineStyle',':') 
elseif all(realeig == 0)
    disp('All of the system eigenvalues have zero real part. Thus, the system is marginally stable.')
    h = figure('Color','white');
    datacursormode(h,'on');
    plot(realeig,imageig,'Marker','o','MarkerSize',6,'MarkerEdgeColor','yellow','MarkerFaceColor','yellow','LineWidth',2,'LineStyle','none')
    title('Eigenvalues Plot','fontweight','bold','fontsize',13)
    xlabel ('Real Axis (seconds^{-1})')
    ylabel ('Imaginary Axis (seconds^{-1})')
    grid on
    set (gca,'GridLineStyle',':') 
end
end
