
(* ========================================================================= *)
(*                                                                           *)
(*                    Properties of Bond Graph Model                         *)
(*                                                                           *)
(*     (c)  Ujala Qasim,                                                     *)
(*          Adnan Rashid,                                                    *)
(*          Osman Hasan                                                      *)
(* 	    SYSTEM ANALYSIS & VERIFICATION (SAVe) LAB                        *)
(*	    National University of Sciences and Technology (NUST), PAKISTAN  *)
(*   Last update: September 19, 2020                                         *)
(*                                                                           *)
(* ========================================================================= *)



let PROPERTY_1 = prove
   (`!(j:jun_list) (i:num)(k:num)(t:real^1).
         ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 2) /\ 
         ((causality j i k) = F)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 3) /\
         ((causality j i k) = T))) ==>
	 ((case_selection j i k t) = (frst_ordr_ele_a j i t))`,
    REPEAT STRIP_TAC THEN REWRITE_TAC [case_selection] THEN 
    ASM_REWRITE_TAC [] THEN ASM_REWRITE_TAC []);;


(************************************************************)

let PROPERTY_2 = prove
   (`!(j:jun_list) (i:num)(k:num)(t:real^1).
       ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 3) /\
         ((causality j i k) = T)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 2) /\
         ((causality j i k) = F)))  ==>
	 ((case_selection j i k t) = (frst_ordr_ele_b j i k t))`,
    REPEAT STRIP_TAC THEN REWRITE_TAC[case_selection] THEN 
    ASM_REWRITE_TAC[] THEN ASM_REWRITE_TAC[]);;


(************************************************************)

let PROPERTY_3 = prove
   (`!(j:jun_list) (i:num)(k:num)(t:real^1).
        ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 4) /\
         ((causality j i k) = T)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 4) /\
         ((causality j i k) = F)) \/
	 (((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 4) /\
         ((causality j i k) = F)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 4) /\
         ((causality j i k) = T))) ==>
	 ((case_selection j i k t) = (zero_ordr_ele j i k t))`,
    REPEAT STRIP_TAC THEN REWRITE_TAC[case_selection] THEN 
    ASM_REWRITE_TAC[] THEN ARITH_TAC );;


(************************************************************)

let PROPERTY_4 = prove
   (`!(j:jun_list) (i:num)(k:num)(t:real^1).
        ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 2) /\
         ((causality j i k) = T)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 3) /\
         ((causality j i k) = F))) ==>
	 ((case_selection j i k t) = (diff_causal_ele_b j i k t))`,
    REPEAT STRIP_TAC THEN REWRITE_TAC[case_selection] THEN 
    ASM_REWRITE_TAC[] THEN ARITH_TAC);;
   

(************************************************************)

let PROPERTY_5 = prove
   (`!(j:jun_list) (i:num)(t:real^1).
         ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 3) /\
         ((causality j i k) = F)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 2)) /\
         ((causality j i k) = T)) ==>
	 ((case_selection j i k t) =  (diff_causal_ele_a j i t))`,
    REPEAT STRIP_TAC THEN REWRITE_TAC[case_selection] THEN 
    ASM_REWRITE_TAC[] THEN ARITH_TAC);;



(************************************************************)

let PROPERTY_6 = prove
   (`!(j:jun_list) (i:num)(k:num)(t:real^1).
       (((((type_of_jun j i) = T) /\
         ((branch j i k) = T) /\ 
         ((causality j i k) = F)) /\
	 (((type_of_ele j i k) = 0) \/
         ((type_of_ele j i k) = 5) \/ 
         ((type_of_ele j i k) = 6))) \/
	 ((((type_of_jun j i) = F) /\
         ((branch j i k) = T) /\
         ((causality j i k) = T)) /\
	 (((type_of_ele j i k) = 0) \/
         ((type_of_ele j i k) = 5) \/ 
         ((type_of_ele j i k) = 6)))) ==>
	 ((case_selection j i k t) = (branch_type_a j i k t))`,
    REPEAT STRIP_TAC THEN REWRITE_TAC[case_selection] THEN 
    ASM_REWRITE_TAC[] THEN ARITH_TAC);;


(************************************************************)

let PROPERTY_7 = prove
   (`!(j:jun_list) (i:num)(k:num)(t:real^1).
          (((((type_of_jun j i) = T) /\
         ((branch j i k) = T) /\ 
         ((causality j i k) = T)) /\
         (((type_of_ele j i k) = 0) \/
         ((type_of_ele j i k) = 5) \/ 
         ((type_of_ele j i k) = 6))) \/
	 ((((type_of_jun j i) = F) /\
         ((branch j i k) = T) /\
         ((causality j i k) = F)) /\
	 (((type_of_ele j i k) = 0) \/
         ((type_of_ele j i k) = 5) \/ 
         ((type_of_ele j i k) = 6)))) ==>
	 ((case_selection j i k t) = (branch_type_b j i k t))`,
    REPEAT STRIP_TAC THEN REWRITE_TAC[case_selection] THEN 
    ASM_REWRITE_TAC[] THEN ARITH_TAC);;

(* =========================================================== *)
