(* ========================================================================= *)
(*                                                                           *)
(*              ANTHROPOMORPHIC MECHATRONIC PROSTHETIC HAND                  *)
(*                                                                           *)
(*     (c)  Ujala Qasim,                                                     *)
(*          Adnan Rashid,                                                    *)
(*          Osman Hasan                                                      *)
(* 	    SYSTEM ANALYSIS & VERIFICATION (SAVe) LAB                        *)
(*	    National University of Sciences and Technology (NUST), PAKISTAN  *)
(*   Last update: September 19, 2020                                         *)
(*                                                                           *)
(* ========================================================================= *)


(*---------------------------------------------------------------------------*)
(*                          Theories to load                                 *)
(*---------------------------------------------------------------------------*)

needs "BG Model.ml";;
needs "Basic_Elements.ml";;
needs "numbers.ml";;
needs "Simplification Tactics.ml";;

(* ------------------------------------------------------------------------- *)
(*                       Prosthetic Hand Fingers BG                          *)
(* ------------------------------------------------------------------------- *)

let thumb_flex_ext = new_definition
 ` thumb_flex_ext (p0:real^2) q0 (e111:real^1->real^2) e112 f112 e113 f113 e121 
    f122 e123 f123 e124 f124 e131 e132 f132 e133 f133 f141 e142 f142 f143 
    (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 = 
   [(0,(T,[(F,F,(F,0),4,([Cx(&1);Cx(&1)]),
      (e111,res_f Ra_1 e111));
       (T,T,(T,312),0,([Cx(&1);Cx(&1)]),(e112,f112));
        (T,F,(F,0),6,([Cx(&1 / Motor_1);Cx(Motor_1)]),(e113,f113))]));
    (1,(T,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e121 p0,inertance_f Jm_1 e121 p0));
        (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e Dm_1 f122,f122));
         (T,T,(F,0),6,([Cx(&1 / Motor_1);Cx(Motor_1)]),(e123,f123));
          (T,F,(F,0),5,([Cx(&1 / Geer_1);Cx(Geer_1)]),(e124,f124))]));
    (2,(F,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e131 p0,inertance_f J_1 e131 p0));
        (F,T,(F,0),5,([Cx(Geer_1);Cx(&1 / Geer_1)]),(e132,f132));
         (T,F,(F,0),0,([Cx(&1);Cx(&1)]),(e133,f133))]));
    (3,(T,[(T,F,(F,0),3,([Cx(&1);Cx(&1)]),(compliance_e K_1 f141 q0,displacement_der f141 q0));
        (F,T,(F,0),0,([Cx(&1);Cx(&1)]),(e142,f142));
         (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e D_1 f143,f143))]))]`;;


let thumb_abd_add = new_definition
 ` thumb_abd_add (p0:real^2) (e211:real^1->real^2) e212 f212 e213 f213 e221 f222 e223 f223 e224
    f224 e231 e232 f232 f233 (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 =
   [(0,(T,[(F,F,(F,0),4,([Cx(&1);Cx(&1)]),(e211,res_f Ra_2 e211));
        (T,T,(T,311),0,([Cx(&1);Cx(&1)]),(e212, f212));
         (T,F,(F,0),6,([Cx(&1 / Motor_2);Cx(Motor_2)]),(e213,f213))]));
    (1,(T,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e221 p0,inertance_f Jm_2 e221 p0));
        (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e Dm_2 f222,f222));
         (T,T,(F,0),6,([Cx(&1 / Motor_2);Cx(Motor_2)]),(e223,f223));
          (T,F,(F,0),5,([Cx(&1 / Geer_2);Cx(Geer_2)]),(e224,f224))]));
    (2,(F,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e231 p0,inertance_f J_2 e231 p0));
        (F,T,(F,0),5,([Cx(Geer_2);Cx(&1 / Geer_2)]),(e232,f232));
         (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e D_2 f233,f233))]))]`;;


let thumb_up_down = new_definition
 ` thumb_up_down (p0:real^2) (e311:real^1->real^2) f311 e312 f312 e313 f313 e314 f314 
   f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
    (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se =
     [(0,(F,[(F,F,(T,311),0,([Cx(&1);Cx(&1)]),(e311,f311));
      (F,F,(T,312),0,([Cx(&1);Cx(&1)]),(e312,f312));
       (F,F,(T,313),0,([Cx(&1);Cx(&1)]),(e313,f313));
        (F,F,(T,314),0,([Cx(&1);Cx(&1)]),(e314,f314));
         (T,T,(F,0),1,([Cx(&1);Cx(&1)]),(src_e Se,f315));
          (F,F,(F,0),0,([Cx(&1);Cx(&1)]),(e316,f316))]));
    (1,(T,[(F,F,(F,0),4,([Cx(&1);Cx(&1)]),(e321,res_f Ra_3 e321));
        (T,T,(F,0),0,([Cx(&1);Cx(&1)]),(e322, f322));
         (T,F,(F,0),6,([Cx(&1 / Motor_3);Cx(Motor_3)]),(e323,f323))]));
    (2,(T,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e331 p0,inertance_f Jm_3 e331 p0));
        (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e Dm_3 f332,f332));
         (T,T,(F,0),6,([Cx(&1 / Motor_3);Cx(Motor_3)]),(e333,f333));
          (T,F,(F,0),5,([Cx(&1 / Geer_3);Cx(Geer_3)]),(e334,f334))]));
    (3,(F,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e341 p0,inertance_f J_3 e341 p0));
        (F,T,(F,0),5,([Cx(Geer_3);Cx(&1 / Geer_3)]),(e342,f342));
         (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e D_3 f343,f343))]))] `;;


let index_finger_flex_ext = new_definition
 ` index_finger_flex_ext (p0:real^2) q0 (e411:real^1->real^2) e412 f412 e413 f413 e421 
   f422 e423 f423 e424 f424 e431 e432 f432 e433 f433 f441 e442 f442 f443 
    (Ra_4:real) Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 =
    [(0,(T,[(F,F,(F,0),4,([Cx(&1);Cx(&1)]),
      (e411,res_f Ra_4 e411));
       (T,T,(T,313),0,([Cx(&1);Cx(&1)]),(e412,f412));
        (T,F,(F,0),6,([Cx(&1 / Motor_4);Cx(Motor_4)]),(e413,f413))]));
    (1,(T,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e421 p0,inertance_f Jm_4 e421 p0));
        (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e Dm_4 f422,f422));
         (T,T,(F,0),6,([Cx(&1 / Motor_4);Cx(Motor_4)]),(e423,f423));
          (T,F,(F,0),5,([Cx(&1 / Geer_4);Cx(Geer_4)]),(e424,f424))]));
    (2,(F,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e431 p0,inertance_f J_4 e431 p0));
        (F,T,(F,0),5,([Cx(Geer_4);Cx(&1 / Geer_4)]),(e432,f432));
         (T,F,(F,0),0,([Cx(&1);Cx(&1)]),(e433,f433))]));
    (3,(T,[(T,F,(F,0),3,([Cx(&1);Cx(&1)]),(compliance_e K_2 f441 q0,displacement_der f441 q0));
        (F,T,(F,0),0,([Cx(&1);Cx(&1)]),(e442,f442));
         (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e D_4 f443,f443))]))]`;;


let index_finger_abd_add = new_definition
 ` index_finger_abd_add (p0:real^2) (e511:real^1->real^2) e512 f512 e513 f513 e521 f522 e523 f523 e524
      f524 e531 e532 f532 f533 (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 =
    [(0,(T,[(F,F,(F,0),4,([Cx(&1);Cx(&1)]),(e511,res_f Ra_5 e511));
        (T,T,(T,314),0,([Cx(&1);Cx(&1)]),(e512, f512));
         (T,F,(F,0),6,([Cx(&1 / Motor_5);Cx(Motor_5)]),(e513,f513))]));
    (1,(T,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e521 p0,inertance_f Jm_5 e521 p0));
        (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e Dm_5 f522,f522));
         (T,T,(F,0),6,([Cx(&1 / Motor_5);Cx(Motor_5)]),(e523,f523));
          (T,F,(F,0),5,([Cx(&1 / Geer_5);Cx(Geer_5)]),(e524,f524))]));
    (2,(F,[(F,F,(F,0),2,([Cx(&1);Cx(&1)]),(momentum_der e531 p0,inertance_f J_5 e531 p0));
        (F,T,(F,0),5,([Cx(Geer_5);Cx(&1 / Geer_5)]),(e532,f532));
         (T,F,(F,0),4,([Cx(&1);Cx(&1)]),(res_e D_5 f533,f533))]))]`;;

(* ------------------------------------------------------------------------- *)
(*                        Prosthetic Hand Fingers EQS.                       *)
(* ------------------------------------------------------------------------- *)

let thumb_flex_ext_eqs = new_definition
 ` thumb_flex_ext_eqs (p0:real^2) q0 (e111:real^1->real^2) e112 f112 e121 f122 e131 f141 f143 
    (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 (t:real^1) = 
     (e111 t = (e112 t - Cx Motor_1 * inertance_f Jm_1 e121 p0 t) /\
       f112 t = res_f Ra_1 e111 t /\
         momentum_der e121 p0 t = (-- res_e Dm_1 f122 t - Cx Geer_1 * (compliance_e K_1 f141 q0 t + res_e D_1 f143 t)
                             + Cx Motor_1 * res_f Ra_1 e111 t) /\ 
           f122 t = inertance_f Jm_1 e121 p0 t /\
             momentum_der e131 p0 t = (compliance_e K_1 f141 q0 t + res_e D_1 f143 t) /\
               displacement_der f141 q0 t = (--inertance_f J_1 e131 p0 t + Cx Geer_1 * inertance_f Jm_1 e121 p0 t) /\
                 f143 t = (--inertance_f J_1 e131 p0 t + Cx Geer_1 * inertance_f Jm_1 e121 p0 t))`;;


let thumb_abd_add_eqs = new_definition
 ` thumb_abd_add_eqs (p0:real^2) (e211:real^1->real^2) e212 f212 e221 f222 e231 f233 
   (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 (t:real^1) =
    (e211 t =  (-- Cx Motor_2 * inertance_f Jm_2 e221 p0 t + e212 t ) /\
      f212 t = res_f Ra_2 e211 t /\
        momentum_der e221 p0 t =  (-- res_e Dm_2 f222 t - Cx Geer_2 * ( res_e D_2 f233 t) + Cx Motor_2 * res_f Ra_2 e211 t ) /\
          f222 t = inertance_f Jm_2 e221 p0 t /\
            momentum_der e231 p0 t =  res_e D_2 f233 t /\
              f233 t =  (-- inertance_f J_2 e231 p0 t + Cx Geer_2 * (inertance_f Jm_2 e221 p0 t)))`;;


let thumb_up_down_eqs = new_definition
 ` thumb_up_down_eqs (p0:real^2) (e311:real^1->real^2) e312 e313 e314 e321 e331 f332 e341 f343 
    (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se (t:real^1) =
    (e311 t = src_e Se t /\ e312 t = src_e Se t /\ e313 t = src_e Se t /\ e314 t = src_e Se t /\
      e321 t =  (-- Cx Motor_3 * inertance_f Jm_3 e331 p0 t + src_e Se t ) /\
        momentum_der e331 p0 t =  (-- res_e Dm_3 f332 t - Cx Geer_3 * ( res_e D_3 f343 t) + Cx Motor_3 * res_f Ra_3 e321 t ) /\
          f332 t = inertance_f Jm_3 e331 p0 t /\
            momentum_der e341 p0 t =  res_e D_3 f343 t /\
              f343 t =  (-- inertance_f J_3 e341 p0 t + Cx Geer_3 * (inertance_f Jm_3 e331 p0 t)))`;;


let index_finger_flex_ext_eqs = new_definition
 ` index_finger_flex_ext_eqs (p0:real^2) q0 (e411:real^1->real^2) e412 f412 e421 f422 e431 f441 f443 
    (Ra_4:real) Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 (t:real^1) =
     (e411 t = (e412 t - Cx Motor_4 * inertance_f Jm_4 e421 p0 t) /\
       f412 t = res_f Ra_4 e411 t /\
         momentum_der e421 p0 t = (-- res_e Dm_4 f422 t - Cx Geer_4 * (compliance_e K_2 f441 q0 t + res_e D_4 f443 t)
                             + Cx Motor_4 * res_f Ra_4 e411 t) /\ 
           f422 t = inertance_f Jm_4 e421 p0 t /\
             momentum_der e431 p0 t = (compliance_e K_2 f441 q0 t + res_e D_4 f443 t) /\
               displacement_der f441 q0 t = (--inertance_f J_4 e431 p0 t + Cx Geer_4 * inertance_f Jm_4 e421 p0 t) /\
                 f443 t = (--inertance_f J_4 e431 p0 t + Cx Geer_4 * inertance_f Jm_4 e421 p0 t))`;;


let index_finger_abd_add_eqs = new_definition
 ` index_finger_abd_add_eqs (p0:real^2) (e511:real^1->real^2) e512 f512 e521 f522 e531 f533
   (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 (t:real^1) =
     (e511 t =  (-- Cx Motor_5 * inertance_f Jm_5 e521 p0 t + e512 t ) /\
      f512 t = res_f Ra_5 e511 t /\
        momentum_der e521 p0 t =  (-- res_e Dm_5 f522 t - Cx Geer_5 * ( res_e D_5 f533 t) + Cx Motor_5 * res_f Ra_5 e511 t ) /\
          f522 t = inertance_f Jm_5 e521 p0 t /\
            momentum_der e531 p0 t =  res_e D_5 f533 t /\
              f533 t =  (-- inertance_f J_5 e531 p0 t + Cx Geer_5 * (inertance_f Jm_5 e521 p0 t)))`;;


(* ------------------------------------------------------------------------- *)
(*                 Prosthetic Hand Fingers Simplified EQS.                   *)
(* ------------------------------------------------------------------------- *)

let thumb_flex_ext_simplified_eqs = new_definition
 ` thumb_flex_ext_simplified_eqs (p0:real^2) q0 (e111:real^1->real^2) e112 f112 e121 f122 e131 f141 f143 
    (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se (t:real^1) = 
     (e111 t = (e112 t - Cx Motor_1 * inertance_f Jm_1 e121 p0 t) /\
         f112 t = res_f Ra_1 e111 t /\
          momentum_der e121 p0 t = ( ( Cx (-- Dm_1 / Jm_1) - Cx ((((Geer_1) pow 2) * (D_1)) / Jm_1)
                                  - Cx (((Motor_1) pow 2) / (Jm_1 * Ra_1))) * momentum e121 p0 t   
                               + Cx (((Geer_1) * (D_1)) / J_1) * momentum e131 p0 t
                                + Cx (-- Geer_1 / K_1) * displacement f141 q0 t + Cx (Motor_1 / Ra_1) * Cx(Se)) /\ 
            f122 t = inertance_f Jm_1 e121 p0 t /\
              momentum_der e131 p0 t = ( Cx (((Geer_1) * (D_1)) / Jm_1) * momentum e121 p0 t 
                                     + Cx(-- D_1 / J_1) * momentum e131 p0 t + Cx(&1 / K_1) * displacement f141 q0 t) /\
                displacement_der f141 q0 t = ( Cx(Geer_1 / Jm_1) *  momentum e121 p0 t + Cx(-- &1 / J_1) * momentum e131 p0 t) /\
                  f143 t = (--inertance_f J_1 e131 p0 t + Cx Geer_1 * inertance_f Jm_1 e121 p0 t))`;;



let thumb_abd_add_simplified_eqs = new_definition
 ` thumb_abd_add_simplified_eqs (p0:real^2) (e211:real^1->real^2) e212 f212 e221 f222
     e231 f233 (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se (t:real^1) =
    (e211 t =  (-- Cx Motor_2 * inertance_f Jm_2 e221 p0 t + e212 t ) /\
       f212 t = res_f Ra_2 e211 t /\
        momentum_der e221 p0 t = (( Cx (-- Dm_2 / Jm_2) - Cx ((((Geer_2) pow 2) * (D_2)) / Jm_2)
                                  - Cx (((Motor_2) pow 2) / (Jm_2 * Ra_2))) * momentum e221 p0 t 
                                    + Cx (((Geer_2) * (D_2)) / J_2) * momentum e231 p0 t
                                      + Cx (Motor_2 / Ra_2) * Cx(Se) ) /\ 
          f222 t = inertance_f Jm_2 e221 p0 t /\
            momentum_der e231 p0 t =  ( Cx (((Geer_2) * (D_2)) / Jm_2) * momentum e221 p0 t 
                                    + Cx(-- D_2 / J_2) * momentum e231 p0 t) /\
              f233 t =  (-- inertance_f J_2 e231 p0 t + Cx Geer_2 * (inertance_f Jm_2 e221 p0 t)))`;;


let thumb_up_down_simplified_eqs = new_definition
 ` thumb_up_down_simplified_eqs (p0:real^2) (e311:real^1->real^2) e312 e313 e314 e321 e331 f332 e341 f343 
    (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se (t:real^1) =
    (e311 t = src_e Se t /\ e312 t = src_e Se t /\ e313 t = src_e Se t /\ e314 t = src_e Se t /\
      e321 t =  (-- Cx Motor_3 * inertance_f Jm_3 e331 p0 t + src_e Se t ) /\
        momentum_der e331 p0 t =  ((Cx (-- Dm_3 / Jm_3) - Cx ((((Geer_3) pow 2) * (D_3)) / Jm_3)
                                  - Cx (((Motor_3) pow 2) / (Jm_3 * Ra_3))) * momentum e331 p0 t 
                                    + Cx (((Geer_3) * (D_3)) / J_3) * momentum e341 p0 t
                                      + Cx (Motor_3 / Ra_3) * Cx(Se)) /\
          f332 t = inertance_f Jm_3 e331 p0 t /\
            momentum_der e341 p0 t =  ( Cx (((Geer_3) * (D_3)) / Jm_3) * momentum e331 p0 t 
                                    + Cx(-- D_3 / J_3) * momentum e341 p0 t) /\
              f343 t =  (-- inertance_f J_3 e341 p0 t + Cx Geer_3 * (inertance_f Jm_3 e331 p0 t)))`;;


let index_finger_flex_ext_simplified_eqs = new_definition
 ` index_finger_flex_ext_simplified_eqs (p0:real^2) q0 (e411:real^1->real^2) f412 e421 f422 e431 f441 f443 
    (Ra_4:real) Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 Se (t:real^1) =
     (e411 t = (Cx(Se) - Cx Motor_4 * inertance_f Jm_4 e421 p0 t) /\
         f412 t = res_f Ra_4 e411 t /\
          momentum_der e421 p0 t = ((Cx (-- Dm_4 / Jm_4) - Cx ((((Geer_4) pow 2) * (D_4)) / Jm_4)
                                  - Cx (((Motor_4) pow 2) / (Jm_4 * Ra_4))) * momentum e421 p0 t 
                                    + Cx (((Geer_4) * (D_4)) / J_4) * momentum e431 p0 t
                                     + Cx (-- Geer_4 / K_2) * displacement f441 q0 t + Cx (Motor_4 / Ra_4) * Cx(Se)) /\
            f422 t = inertance_f Jm_4 e421 p0 t /\
              momentum_der e431 p0 t = ( Cx (((Geer_4) * (D_4)) / Jm_4) * momentum e421 p0 t 
                                     + Cx(-- D_4 / J_4) * momentum e431 p0 t + Cx(&1 / K_2) * displacement f441 q0 t) /\
                displacement_der f441 q0 t = ( Cx(Geer_4 / Jm_4) *  momentum e421 p0 t + Cx(-- &1 / J_4) * momentum e431 p0 t) /\
                  f443 t = (--inertance_f J_4 e431 p0 t + Cx Geer_4 * inertance_f Jm_4 e421 p0 t))`;;



let index_finger_abd_add_simplified_eqs = new_definition
 ` index_finger_abd_add_simplified_eqs (p0:real^2) (e511:real^1->real^2) e512 f512 e521 f522 e531 f533 
   (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se (t:real^1) =
     (e511 t =  (-- Cx Motor_5 * inertance_f Jm_5 e521 p0 t + e512 t ) /\
       f512 t = res_f Ra_5 e511 t /\
        momentum_der e521 p0 t = ((Cx (-- Dm_5 / Jm_5) - Cx ((((Geer_5) pow 2) * (D_5)) / Jm_5)
                                  - Cx (((Motor_5) pow 2) / (Jm_5 * Ra_5))) * momentum e521 p0 t 
                                    + Cx (((Geer_5) * (D_5)) / J_5) * momentum e531 p0 t
                                      + Cx (Motor_5 / Ra_5) * Cx(Se) ) /\  
          f522 t = inertance_f Jm_5 e521 p0 t /\
            momentum_der e531 p0 t =  ( Cx (((Geer_5) * (D_5)) / Jm_5) * momentum e521 p0 t 
                                    + Cx(-- D_5 / J_5) * momentum e531 p0 t) /\
              f533 t =  (-- inertance_f J_5 e531 p0 t + Cx Geer_5 * (inertance_f Jm_5 e521 p0 t)))`;;


(* ------------------------------------------------------------------------- *)
(*                 Prosthetic Hand Fingers State-space Model                 *)
(* ------------------------------------------------------------------------- *)


(************************ THUMB FLEX. & EXT. ****************************)

let thumb_flex_ext_system_mat = new_definition 
  ` thumb_flex_ext_system_mat (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 D_1 K_1 =  
    ((vector [vector [ Cx ( (-- Dm_1 / Jm_1) - ((((Geer_1) pow 2) * (D_1)) / Jm_1) - (((Motor_1) pow 2) / (Jm_1 * Ra_1)));
                             Cx (((Geer_1) * (D_1)) / J_1); Cx (-- Geer_1 / K_1)];
                   vector [ Cx ((Geer_1 * D_1) / Jm_1);  Cx (-- D_1 / J_1); Cx (&1 / K_1)];
                    vector [ Cx (Geer_1 / Jm_1); Cx (-- &1 / J_1); Cx(&0)]]): (complex)^3^3)`;;


let thumb_flex_ext_input_mat = new_definition 
  ` thumb_flex_ext_input_mat (Ra_1:real) Motor_1 = 
     ((vector [vector [Cx ( Motor_1 / Ra_1)];vector [Cx(&0)] ; vector[Cx(&0)]]): (complex)^1^3)`;;


 let thumb_flex_ext_state_vec = new_definition 
  ` thumb_flex_ext_state_vec (p0:real^2) q0 (e121:real^1->real^2) e131 f141 (t:real^1) = 
       (vector [( momentum e121 p0 t); (momentum e131 p0 t); (displacement f141 q0 t)]: (complex)^3)`;; 

let thumb_flex_ext_state_vec_der = new_definition 
  ` thumb_flex_ext_state_vec_der (p0:real^2) q0 (e121:real^1->real^2) e131 f141 (t:real^1) = 
       ((vector [( momentum_der e121 p0 t); (momentum_der e131 p0 t); (displacement_der f141 q0 t)]): (complex)^3)`;; 


let thumb_flex_ext_input_vec = new_definition 
  ` thumb_flex_ext_input_vec (Se:real) = (vector [Cx(Se)])`;;

let thumb_flex_ext_ss_model = new_definition
  `thumb_flex_ext_ss_model (p0:real^2) q0 (e121:real^1->real^2) e131 f141 (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 D_1 K_1 Se (t:real^1) =
   (ss_model (thumb_flex_ext_system_mat Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 D_1 K_1) (thumb_flex_ext_input_mat Ra_1 Motor_1) 
               (thumb_flex_ext_state_vec p0 q0 e121 e131 f141 t) (thumb_flex_ext_state_vec_der p0 q0 e121 e131 f141 t)
                (thumb_flex_ext_input_vec Se))`;; 


(************************ THUMB ABD. & ADD. ****************************)

let thumb_abd_add_system_mat = new_definition 
  ` thumb_abd_add_system_mat (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 =  
     ((vector [vector [Cx ( (-- Dm_2 / Jm_2) - ((((Geer_2) pow 2) * (D_2)) / Jm_2) - (((Motor_2) pow 2) / (Jm_2 * Ra_2)));
                             Cx (((Geer_2) * (D_2)) / J_2)];
               vector [ Cx (((Geer_2) * (D_2)) / Jm_2); Cx ((-- D_2) / J_2)]]):(complex)^2^2)`;;


let thumb_abd_add_input_mat = new_definition 
  ` thumb_abd_add_input_mat (Ra_2:real) Motor_2 = ((vector [vector [Cx ( Motor_2 / Ra_2)];vector[Cx(&0)]]): (complex)^1^2)`;;


 let thumb_abd_add_state_vec = new_definition 
  ` thumb_abd_add_state_vec (p0:real^2) (e221:real^1->real^2) e231 (t:real^1) = 
       ((vector [( momentum e221 p0 t); (momentum e231 p0 t)]): (complex)^2)`;; 

let thumb_abd_add_state_vec_der = new_definition 
  ` thumb_abd_add_state_vec_der (p0:real^2) (e221:real^1->real^2) e231 (t:real^1) = 
       ((vector [( momentum_der e221 p0 t); (momentum_der e231 p0 t)]): (complex)^2)`;; 


let thumb_abd_add_input_vec = new_definition 
  ` thumb_abd_add_input_vec (Se:real) = (vector [Cx(Se)])`;;

let thumb_abd_add_ss_model = new_definition
  `thumb_abd_add_ss_model (p0:real^2) (e221:real^1->real^2) e231 (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se (t:real^1) =
   (ss_model (thumb_abd_add_system_mat Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2) (thumb_abd_add_input_mat Ra_2 Motor_2) 
               (thumb_abd_add_state_vec p0 e221 e231 t) 
                (thumb_abd_add_state_vec_der p0 e221 e231 t) 
                  (thumb_abd_add_input_vec Se))`;;


(************************ THUMB UP & DOWN ****************************)

let thumb_up_down_system_mat = new_definition 
  ` thumb_up_down_system_mat (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 =  
((vector [vector [Cx ( (-- Dm_3 / Jm_3) - ((((Geer_3) pow 2) * (D_3)) / Jm_3) - (((Motor_3) pow 2) / (Jm_3 * Ra_3)));
                             Cx (((Geer_3) * (D_3)) / J_3)];
                        vector [ Cx (((Geer_3) * (D_3)) / Jm_3); Cx ((-- D_3) / J_3)]]):(complex)^2^2) `;;


let thumb_up_down_input_mat = new_definition 
  ` thumb_up_down_input_mat (Ra_3:real) Motor_3 = ((vector [vector [Cx ( Motor_3 / Ra_3)]; vector[Cx(&0)]]): (complex)^1^2)`;;
 

let thumb_up_down_state_vec = new_definition 
  ` thumb_up_down_state_vec (p0:real^2) (e331:real^1->real^2) e341 (t:real^1) = 
       ((vector [( momentum e331 p0 t); (momentum e341 p0 t)]): (complex)^2)`;; 

let thumb_up_down_state_vec_der = new_definition 
  ` thumb_up_down_state_vec_der (p0:real^2) (e331:real^1->real^2) e341 (t:real^1) = 
       ((vector [( momentum_der e331 p0 t); (momentum_der e341 p0 t)]): (complex)^2)`;; 


let thumb_up_down_input_vec = new_definition 
  ` thumb_up_down_input_vec (Se:real) = (vector [Cx(Se)])`;;

let thumb_up_down_ss_model = new_definition
  `thumb_up_down_ss_model (p0:real^2) (e331:real^1->real^2) e341 (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se (t:real^1) =
   (ss_model (thumb_up_down_system_mat Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3) (thumb_up_down_input_mat Ra_3 Motor_3) 
               (thumb_up_down_state_vec p0 e331 e341 t) 
                (thumb_up_down_state_vec_der p0 e331 e341 t) 
                  (thumb_up_down_input_vec Se))`;; 
 

(********************* INDEX FINGER FLEX. & EXT. **************************)



let index_finger_flex_ext_system_mat = new_definition 
  ` index_finger_flex_ext_system_mat (Ra_4:real) Motor_4 Jm_4 Dm_4 Geer_4 J_4 D_4 K_2 =  
((vector [vector [ Cx ( (-- Dm_4 / Jm_4) - ((((Geer_4) pow 2) * (D_4)) / Jm_4) - (((Motor_4) pow 2) / (Jm_4 * Ra_4)));
                             Cx (((Geer_4) * (D_4)) / J_4); Cx (-- Geer_4 / K_2)];
                   vector [ Cx ((Geer_4 * D_4) / Jm_4);  Cx (-- D_4 / J_4); Cx (&1 / K_2)];
                    vector [ Cx (Geer_4 / Jm_4); Cx (-- &1 / J_4); Cx(&0)]]): (complex)^3^3)`;;


let index_finger_flex_ext_input_mat = new_definition 
  ` index_finger_flex_ext_input_mat (Ra_4:real) Motor_4 =
       ((vector [vector [Cx ( Motor_4 / Ra_4)];vector [Cx(&0)] ; vector[Cx(&0)]]): (complex)^1^3)`;;


 let index_finger_flex_ext_state_vec = new_definition 
  ` index_finger_flex_ext_state_vec (p0:real^2) q0 (e421:real^1->real^2) e431 f441 (t:real^1) = 
       (vector [( momentum e421 p0 t); (momentum e431 p0 t); (displacement f441 q0 t)]: (complex)^3)`;; 

let index_finger_flex_ext_state_vec_der = new_definition 
  ` index_finger_flex_ext_state_vec_der (p0:real^2) q0 (e421:real^1->real^2) e431 f441 (t:real^1) = 
       ((vector [( momentum_der e421 p0 t); (momentum_der e431 p0 t); (displacement_der f441 q0 t)]): (complex)^3)`;; 


let index_finger_flex_ext_input_vec = new_definition 
  ` index_finger_flex_ext_input_vec (Se:real) = (vector [Cx(Se)])`;;

let index_finger_flex_ext_ss_model = new_definition
  `index_finger_flex_ext_ss_model (p0:real^2) q0 (e421:real^1->real^2) e431 f441
   (Ra_4:real) Motor_4 Jm_4 Dm_4 Geer_4 J_4 D_4 K_2 Se (t:real^1) =
   (ss_model (index_finger_flex_ext_system_mat Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 D_4 K_2) (index_finger_flex_ext_input_mat Ra_4 Motor_4) 
               (index_finger_flex_ext_state_vec p0 q0 e421 e431 f441 t) 
               (index_finger_flex_ext_state_vec_der p0 q0 e421 e431 f441 t) 
               (index_finger_flex_ext_input_vec Se))`;; 


(********************* INDEX FINGER ABD. & ADD. **************************)


let index_finger_abd_add_system_mat = new_definition 
  ` index_finger_abd_add_system_mat (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 =  
((vector [vector [Cx ( (-- Dm_5 / Jm_5) - ((((Geer_5) pow 2) * (D_5)) / Jm_5) - (((Motor_5) pow 2) / (Jm_5 * Ra_5)));
                             Cx (((Geer_5) * (D_5)) / J_5)];
                        vector [ Cx (((Geer_5) * (D_5)) / Jm_5); Cx ((-- D_5) / J_5)]]):(complex)^2^2)`;;


let index_finger_abd_add_input_mat = new_definition 
  ` index_finger_abd_add_input_mat (Ra_5:real) Motor_5 = ((vector [vector [Cx ( Motor_5 / Ra_5)];vector[Cx(&0)]]): (complex)^1^2)`;;


 let index_finger_abd_add_state_vec = new_definition 
  ` index_finger_abd_add_state_vec (p0:real^2) (e521:real^1->real^2) e531 (t:real^1) = 
       ((vector [( momentum e521 p0 t); (momentum e531 p0 t)]): (complex)^2)`;; 

let index_finger_abd_add_state_vec_der = new_definition 
  ` index_finger_abd_add_state_vec_der (p0:real^2) (e521:real^1->real^2) e531 (t:real^1) = 
       ((vector [( momentum_der e521 p0 t); (momentum_der e531 p0 t)]): (complex)^2)`;; 


let index_finger_abd_add_input_vec = new_definition 
  ` index_finger_abd_add_input_vec (Se:real) = (vector [Cx(Se)])`;;

let index_finger_abd_add_ss_model = new_definition
  `index_finger_abd_add_ss_model (p0:real^2) (e521:real^1->real^2) e531 (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se (t:real^1) =
   (ss_model (index_finger_abd_add_system_mat Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5) (index_finger_abd_add_input_mat Ra_5 Motor_5) 
               (index_finger_abd_add_state_vec p0 e521 e531 t) 
                (index_finger_abd_add_state_vec_der p0 e521 e531 t) 
                  (index_finger_abd_add_input_vec Se))`;; 



(* ------------------------------------------------------------------------- *)
(*             IMPLEMENTATION of THUMB (Flex. & Ext) EQUALS EQS.             *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) q0 (e111:real^1->real^2) e112 f112 e113 f113 e121 f122 e123 f123 e124
    f124 e131 e132 f132 e133 f133 f141 e142 f142 f143 
     (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 (t:real^1).
    bg_main (thumb_flex_ext p0 q0 e111 e112 f112 e113 f113 e121 
    f122 e123 f123 e124 f124 e131 e132 f132 e133 f133 f141 e142 f142 f143 
    Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1) t =
    thumb_flex_ext_eqs p0 q0 e111 e112 f112 e121 f122 e131 f141 f143 
    Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 t`;;


e (REPEAT GEN_TAC);;
e (REWRITE_TAC [thumb_flex_ext;thumb_flex_ext_eqs]);;
e (CASE_SELECTION_TAC []);;
e (REWRITE_TAC [zero_ordr_ele;res_path_selection]);;
e (REWRITE_TAC [causality;type_of_jun;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl;frst_of_tuple]);;
e (REWRITE_TAC [jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [side_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [search_path_e;LENGTH;ARITH]);;
e (REWRITE_TAC [last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (PATHS_SELECTION_TAC []);;
e (BOND_FLOW_TAC []);;
e (REWRITE_TAC [final_fwrd_path_e;LENGTH;ARITH]);;
e (REWRITE_TAC [snd_last_bond_e]);;
e (REWRITE_TAC [bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (REWRITE_TAC [jun_1_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [ bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond;last_bond_dir_cond]);;
e (BOND_MODULUS_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [ bw_jun_f_sum;bw_last_jun_f;LENGTH;ARITH]);;
e (REWRITE_TAC [jun_0_f;jun_1_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_flow_wd]);;
e (BOND_FLOW_TAC []);;
e (BOND_DIRECTION_TAC []);;

e (REWRITE_TAC [branch_type_b]);;
e (PATHS_SELECTION_TAC []);;
e (CAUSAL_LOOP_TAC []);;
e (BOND_FLOW_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_a;jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [middle_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [causal_paths;last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [jun_1_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [ bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [fw_jun_e_sum;fw_last_jun_e;ARITH]);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;
e (REWRITE_TAC [last_bond_dir; snd_last_bond_dir_cond]);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [jun_1_e; last_bond_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (BOND_DIRECTION_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_b]);;
e (PATHS_SELECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [bw_jun_f_sum;fw_jun_e_sum]);;
e (REWRITE_TAC [bw_last_jun_f;fw_last_jun_e;ARITH]);;
e (REWRITE_TAC [last_bond_e]);;
e (REWRITE_TAC [jun_1_e;jun_0_f;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_effort_wd;bond_flow_wd]);;
e (BOND_FLOW_TAC []);;
e (BOND_EFFORT_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;
e (REWRITE_TAC [last_bond_dir; last_bond_dir_cond;snd_last_bond_dir_cond]);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_MUL_LID;COMPLEX_MUL_RID;COMPLEX_ADD_RID]);;
e (SIMP_TAC [COMPLEX_FIELD `--Cx (&1) * a = -- a`]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let THUMB_FLEX_EXT_IMP_EQS = top_thm();;



(* ------------------------------------------------------------------------- *)
(*            IMPLEMENTATION of THUMB (Abd. & Add.) EQUALS EQS.              *)
(* ------------------------------------------------------------------------- *)



g `!(p0:real^2)(e211:real^1->real^2) e212 f212 e213 f213 e221 f222 e223 f223 e224 f224 e231 e232 f232 f233 
    (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 (t:real^1).
    bg_main (thumb_abd_add p0 e211 e212 f212 e213 f213 e221 f222 e223 f223 e224
    f224 e231 e232 f232 f233 Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2) t =
    thumb_abd_add_eqs p0 e211 e212 f212 e221 f222 e231 f233 
    Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 t `;;


e (REPEAT GEN_TAC);;
e (REWRITE_TAC [thumb_abd_add;thumb_abd_add_eqs]);;
e (CASE_SELECTION_TAC []);;
e (REWRITE_TAC [zero_ordr_ele;res_path_selection]);;
e (REWRITE_TAC [causality;type_of_jun;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl;frst_of_tuple]);;
e (REWRITE_TAC [jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [side_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [search_path_e;search_path_f;LENGTH;ARITH]);;
e (REWRITE_TAC [ backwrd_path_f;final_fwrd_path_e;LENGTH;ARITH]);;
e (PATHS_SELECTION_TAC []);;
e (REWRITE_TAC [last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [jun_0_f;jun_1_e;last_bond_f;snd_last_bond_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_flow_wd]);;
e (REWRITE_TAC [bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;

e (REWRITE_TAC [branch_type_b]);;
e (PATHS_SELECTION_TAC []);;
e (CAUSAL_LOOP_TAC []);;
e (BOND_FLOW_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_a;jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [middle_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [causal_paths;last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [jun_1_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (BOND_EFFORT_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_b]);;
e (PATHS_SELECTION_TAC []);;
e (BOND_EFFORT_TAC []);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_MUL_LID;COMPLEX_MUL_RID;COMPLEX_ADD_RID]);;
e (SIMP_TAC [COMPLEX_FIELD `--Cx (&1) * a = -- a`]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let THUMB_ABD_ADD_IMP_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*   IMPLEMENTATION of THUMB (Up & Down) (Parent/Main BRANCH) EQUALS EQS.    *)
(* ------------------------------------------------------------------------- *)



g `!(p0:real^2)(e311:real^1->real^2) f311 e312 f312 e313 f313 e314 f314 f315 e316 f316 e321
    e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
    (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se (t:real^1).
     bg_main (thumb_up_down p0 e311 f311 e312 f312 e313 f313 e314 f314 
     f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
     Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se) t =
     thumb_up_down_eqs p0 e311 e312 e313 e314 e321 e331 f332 e341 f343 
     Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se t `;;


e (REPEAT GEN_TAC);;
e (REWRITE_TAC [thumb_up_down;thumb_up_down_eqs]);; 
e (CASE_SELECTION_TAC []);;
e (REWRITE_TAC [branch_type_b]);;
e (PATHS_SELECTION_TAC []);;
e (CAUSAL_LOOP_TAC []);;
e (BOND_EFFORT_TAC []);;

e (REWRITE_TAC [zero_ordr_ele;res_path_selection]);;
e (REWRITE_TAC [causality;type_of_jun;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl;frst_of_tuple]);;
e (REWRITE_TAC [jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [middle_jun_sum;side_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [search_path_f;LENGTH;ARITH]);;
e (REWRITE_TAC [causal_paths;last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [ backwrd_path_f;LENGTH;ARITH]);;
e (PATHS_SELECTION_TAC []);;
e (REWRITE_TAC [jun_0_f;last_bond_f;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_flow_wd]);;
e (BOND_FLOW_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;
e (REWRITE_TAC [jun_1_e;last_bond_f;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (BOND_DIRECTION_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_a;jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [middle_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [causal_paths;last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [jun_1_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [ bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_b]);;
e (PATHS_SELECTION_TAC []);;
e (BOND_EFFORT_TAC []);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_MUL_LID;COMPLEX_MUL_RID;COMPLEX_ADD_RID]);;
e (SIMP_TAC [COMPLEX_FIELD `--Cx (&1) * a = -- a`]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let THUMB_UP_DOWN_IMP_EQS = top_thm();;

(* ------------------------------------------------------------------------- *)
(*       IMPLEMENTATION of INDEX FINGER (FLEX. & EXT.) EQUALS EQS.          *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) q0 (e411:real^1->real^2) e412 f412 e413 f413 e421 f422 e423 f423 e424
    f424 e431 e432 f432 e433 f433 f441 e442 f442 f443 
    (Ra_4:real) Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 (t:real^1).
    bg_main (index_finger_flex_ext p0 q0 e411 e412 f412 e413 f413 e421 
   f422 e423 f423 e424 f424 e431 e432 f432 e433 f433 f441 e442 f442 f443 
    Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4) t =
    index_finger_flex_ext_eqs p0 q0 e411 e412 f412 e421 f422 e431 f441 f443 
    Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 t `;;

e (REPEAT GEN_TAC);;
e (REWRITE_TAC [index_finger_flex_ext;index_finger_flex_ext_eqs]);;
e (CASE_SELECTION_TAC []);;
e (REWRITE_TAC [zero_ordr_ele;res_path_selection]);;
e (REWRITE_TAC [causality;type_of_jun;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl;frst_of_tuple]);;
e (REWRITE_TAC [jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [side_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [search_path_e;LENGTH;ARITH]);;
e (REWRITE_TAC [last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (PATHS_SELECTION_TAC []);;
e (BOND_FLOW_TAC []);;
e (REWRITE_TAC [final_fwrd_path_e;LENGTH;ARITH]);;
e (REWRITE_TAC [snd_last_bond_e]);;
e (REWRITE_TAC [bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (REWRITE_TAC [jun_1_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [ bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond;last_bond_dir_cond]);;
e (BOND_MODULUS_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [ bw_jun_f_sum;bw_last_jun_f;LENGTH;ARITH]);;
e (REWRITE_TAC [jun_0_f;jun_1_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_flow_wd]);;
e (BOND_FLOW_TAC []);;
e (BOND_DIRECTION_TAC []);;

e (REWRITE_TAC [branch_type_b]);;
e (PATHS_SELECTION_TAC []);;
e (CAUSAL_LOOP_TAC []);;
e (BOND_FLOW_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_a;jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [middle_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [causal_paths;last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [jun_1_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [ bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [fw_jun_e_sum;fw_last_jun_e;ARITH]);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;
e (REWRITE_TAC [last_bond_dir; snd_last_bond_dir_cond]);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [jun_1_e; last_bond_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (BOND_DIRECTION_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_b]);;
e (PATHS_SELECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [bw_jun_f_sum;fw_jun_e_sum]);;
e (REWRITE_TAC [bw_last_jun_f;fw_last_jun_e;ARITH]);;
e (REWRITE_TAC [last_bond_e]);;
e (REWRITE_TAC [jun_1_e;jun_0_f;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_effort_wd;bond_flow_wd]);;
e (BOND_FLOW_TAC []);;
e (BOND_EFFORT_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;
e (REWRITE_TAC [last_bond_dir; last_bond_dir_cond;snd_last_bond_dir_cond]);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_MUL_LID;COMPLEX_MUL_RID;COMPLEX_ADD_RID]);;
e (SIMP_TAC [COMPLEX_FIELD `--Cx (&1) * a = -- a`]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let INDEX_FINGER_FLEX_EXT_IMP_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*         IMPLEMENTATION of INDEX_FINGER (Abd. & Add.) EQUALS EQS.         *)
(* ------------------------------------------------------------------------- *)



g `!(p0:real^2) (e511:real^1->real^2) e512 f512 e513 f513 e521 f522 e523 f523 e524 f524 e531 e532 f532 f533 
    (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 (t:real^1).
    bg_main (index_finger_abd_add p0 e511 e512 f512 e513 f513 e521 f522 e523 f523 e524
      f524 e531 e532 f532 f533 Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5) t =
    index_finger_abd_add_eqs p0 e511 e512 f512 e521 f522 e531 f533
    Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 t `;;


e (REPEAT GEN_TAC);;
e (REWRITE_TAC [index_finger_abd_add;index_finger_abd_add_eqs]);;
e (CASE_SELECTION_TAC []);;
e (REWRITE_TAC [zero_ordr_ele;res_path_selection]);;
e (REWRITE_TAC [causality;type_of_jun;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl;frst_of_tuple]);;
e (REWRITE_TAC [jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [side_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [search_path_e;search_path_f;LENGTH;ARITH]);;
e (REWRITE_TAC [ backwrd_path_f;final_fwrd_path_e;LENGTH;ARITH]);;
e (PATHS_SELECTION_TAC []);;
e (REWRITE_TAC [last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [jun_0_f;jun_1_e;last_bond_f;snd_last_bond_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_flow_wd]);;
e (REWRITE_TAC [bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;

e (REWRITE_TAC [branch_type_b]);;
e (PATHS_SELECTION_TAC []);;
e (CAUSAL_LOOP_TAC []);;
e (BOND_FLOW_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_a;jun_sum_final; jun_sum;LENGTH;ARITH]);;
e (REWRITE_TAC [middle_jun_sum;type_of_jun;bond;bonds;jun ]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;snd_of_trpl]);;
e (REWRITE_TAC [causal_paths;last_bond_dir;snd_last_bond_dir]);;
e (BOND_DIRECTION_TAC []);;
e (BACKWRD_PATH_TAC []);;
e (FWRD_PATH_TAC []);;
e (REWRITE_TAC [jun_1_e;bonds_length;bond;bonds;jun]);;
e (NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH]);;
e (NUMBER_SFG_TAC1 [VSUM_CLAUSES_NUMSEG]);;
e (REWRITE_TAC [bond_effort_wd]);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (BOND_EFFORT_TAC []);;
e (BOND_DIRECTION_TAC []);;
e (REWRITE_TAC [last_bond_modulus_cond;snd_last_bond_modulus_cond]);;
e (BOND_MODULUS_TAC []);;

e (REWRITE_TAC [frst_ordr_ele_b]);;
e (PATHS_SELECTION_TAC []);;
e (BOND_EFFORT_TAC []);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_MUL_LID;COMPLEX_MUL_RID;COMPLEX_ADD_RID]);;
e (SIMP_TAC [COMPLEX_FIELD `--Cx (&1) * a = -- a`]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;


let INDEX_FINGER_ABD_ADD_IMP_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*            CONNECTING THUMB (Up/DOWN) & THUMB (Flex. & Ext.)              *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) q0 (e311:real^1->real^2) f311 e312 f312 e313 f313 e314 f314 
   f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
   e111 e112 f112 e113 f113 e121 f122 e123 f123 e124 f124 e131 e132 f132 e133 f133 f141 e142 f142 f143
    Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se (t:real^1).
    branch_main (thumb_up_down p0 e311 f311 e312 f312 e313 f313 e314 f314 
   f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
    Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se) 
    (thumb_flex_ext p0 q0 e111 e112 f112 e113 f113 e121 
    f122 e123 f123 e124 f124 e131 e132 f132 e133 f133 f141 e142 f142 f143 
    Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1) t =
    (f312 t = f112 t /\ e312 t = e112 t)`;;  


e (REPEAT GEN_TAC);;
e (REWRITE_TAC [thumb_up_down;thumb_flex_ext]);;
e (BRANCH_TAC []);;
e (REWRITE_TAC [ONE;EL;TL;HD]);;
e (BOND_MODULUS_TAC []);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (REWRITE_TAC [ARITH;COMPLEX_MUL_LID]);;
e (REWRITE_TAC [CONJ_SYM]);;

let BRANCH_1_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*            CONNECTING THUMB (Up/DOWN) & THUMB (Abd. & Add.)               *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2)(e311:real^1->real^2) f311 e312 f312 e313 f313 e314 f314 
   f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
   e211 e212 f212 e213 f213 e221 f222 e223 f223 e224 f224 e231 e232 f232 f233 
    Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se (t:real^1).
    branch_main (thumb_up_down p0 e311 f311 e312 f312 e313 f313 e314 f314 
   f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
    Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se)
    (thumb_abd_add p0 e211 e212 f212 e213 f213 e221 f222 e223 f223 e224
    f224 e231 e232 f232 f233 Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2) t =
      (f311 t = f212 t /\ e311 t = e212 t)`;;  


e (REPEAT GEN_TAC);;
e (REWRITE_TAC [thumb_up_down;thumb_abd_add]);;
e (BRANCH_TAC []);;
e (REWRITE_TAC [ONE;EL;TL;HD]);;
e (BOND_MODULUS_TAC []);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (REWRITE_TAC [ARITH;COMPLEX_MUL_LID]);;
e (REWRITE_TAC [CONJ_SYM]);;

let BRANCH_2_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*         CONNECTING THUMB (Up/DOWN) & INDEX FINGER (Flex. & Ext.)          *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) q0 (e311:real^1->real^2) f311 e312 f312 e313 f313 e314 f314 
   f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343
   e411 e412 f412 e413 f413 e421 f422 e423 f423 e424 f424 e431 e432 f432 e433 f433 f441 e442 f442 f443 
    Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 Se (t:real^1).
    branch_main (thumb_up_down p0 e311 f311 e312 f312 e313 f313 e314 f314 
   f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
    Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se)
    (index_finger_flex_ext p0 q0 e411 e412 f412 e413 f413 e421 
   f422 e423 f423 e424 f424 e431 e432 f432 e433 f433 f441 e442 f442 f443 
    Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4) t =
     (f313 t = f412 t /\ e313 t = e412 t)`;; 
    
  
e (REPEAT GEN_TAC);;
e (REWRITE_TAC [thumb_up_down;index_finger_flex_ext]);;
e (BRANCH_TAC []);;
e (REWRITE_TAC [ONE;EL;TL;HD]);;
e (BOND_MODULUS_TAC []);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (REWRITE_TAC [ARITH;COMPLEX_MUL_LID]);;
e (REWRITE_TAC [CONJ_SYM]);;

let BRANCH_3_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*         CONNECTING THUMB (Up/DOWN) & INDEX FINGER (Abd. & Add.)          *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) (e311:real^1->real^2) f311 e312 f312 e313 f313 e314 f314 
   f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
    e512 f512 e513 f513 e521 f522 e523 f523 e524 f524 e531 e532 f532 f533 
    (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se (t:real^1).
    branch_main (thumb_up_down p0 e311 f311 e312 f312 e313 f313 e314 f314 
   f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
    Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se) 
    (index_finger_abd_add p0 e511 e512 f512 e513 f513 e521 f522 e523 f523 e524
      f524 e531 e532 f532 f533 Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5) t =
    (f314 t = f512 t /\ e314 t = e512 t)`;; 
    
  
e (REPEAT GEN_TAC);;
e (REWRITE_TAC [thumb_up_down;index_finger_abd_add]);;
e (BRANCH_TAC []);;
e (REWRITE_TAC [ONE;EL;TL;HD]);;
e (BOND_MODULUS_TAC []);;
e (BOND_EFFORT_TAC []);;
e (BOND_FLOW_TAC []);;
e (REWRITE_TAC [ARITH;COMPLEX_MUL_LID]);;
e (REWRITE_TAC [CONJ_SYM]);;

let BRANCH_4_EQS = top_thm();;



(* ------------------------------------------------------------------------- *)
(*                 THUMB (Flex. & Ext) SIMPLIFICATION                        *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) q0 (e111:real^1->real^2) e112 f112 e121 f122 e131 f141 f143 e312
    (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se (t:real^1).
     (&0 < Jm_1) /\  (&0 < Ra_1) /\  (&0 < J_1) /\  (&0 < K_1) /\ 
      (f122 t = inertance_f Jm_1 e121 p0 t) /\
      (e111 t = (e112 t - Cx Motor_1 * inertance_f Jm_1 e121 p0 t)) /\ 
        ( f143 t = (--inertance_f J_1 e131 p0 t + Cx Geer_1 * inertance_f Jm_1 e121 p0 t)) /\
         (e312 t = e112 t) /\ (e312 t = src_e Se t) 
  ==> thumb_flex_ext_eqs p0 q0 e111 e112 f112 e121 f122 e131 f141 f143 
      Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 t = 
     thumb_flex_ext_simplified_eqs p0 q0 e111 e112 f112 e121 f122 e131 f141 f143 
     Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se t`;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [thumb_flex_ext_eqs;thumb_flex_ext_simplified_eqs]);;
e (REWRITE_TAC [res_e;res_f;inertance_f; compliance_e;src_e]);;
e (ASM_REWRITE_TAC [inertance_f]);;
e (SUBGOAL_THEN ` (e112:real^1->real^2) (t:real^1) = (e312:real^1->real^2) (t:real^1)` ASSUME_TAC);;
    e (UNDISCH_TAC ` (e312:real^1->real^2) (t:real^1) = (e112:real^1->real^2) (t:real^1)`);;
    e (REWRITE_TAC [EQ_SYM_EQ]);;
e (UNDISCH_TAC ` (e112:real^1->real^2) (t:real^1) = (e312:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (UNDISCH_TAC ` (e312:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);; 
e (SIMP_TAC [src_e]);;
e (DISCH_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let THUMB_FLEX_EXT_EQS_SIMPLIFY = top_thm();;


(* ------------------------------------------------------------------------- *)
(*          IMPLEMENTATION OF THUMB (Flex. & Ext) EQUALS SIMP. EQS.          *)
(* ------------------------------------------------------------------------- *)

g `!(p0:real^2) q0 (e111:real^1->real^2) e112 f112 e113 f113 e121 f122 e123 f123 e124
    f124 e131 e132 f132 e133 f133 f141 e142 f142 f143 e312
    (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se (t:real^1).
     (&0 < Jm_1) /\  (&0 < Ra_1) /\  (&0 < J_1) /\  (&0 < K_1) /\ 
      (f122 t = inertance_f Jm_1 e121 p0 t) /\
      (e111 t = (e112 t - Cx Motor_1 * inertance_f Jm_1 e121 p0 t)) /\ 
        ( f143 t = (--inertance_f J_1 e131 p0 t + Cx Geer_1 * inertance_f Jm_1 e121 p0 t)) /\
         (e312 t = e112 t) /\ (e312 t = src_e Se t) 
 ==>  bg_main (thumb_flex_ext p0 q0 e111 e112 f112 e113 f113 e121 f122 e123 f123 e124
           f124 e131 e132 f132 e133 f133 f141 e142 f142 f143 
             Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1) t =
       (thumb_flex_ext_simplified_eqs p0 q0 e111 e112 f112 e121 f122 e131 f141 f143 
     Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se t) `;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [THUMB_FLEX_EXT_IMP_EQS]);;
e (MATCH_MP_TAC THUMB_FLEX_EXT_EQS_SIMPLIFY);;
e (EXISTS_TAC ` (e312:real^1->real^2)`);;
e (ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN ` (e112:real^1->real^2) (t:real^1) = (e312:real^1->real^2) (t:real^1)` ASSUME_TAC);;
    e (UNDISCH_TAC ` (e312:real^1->real^2) (t:real^1) = (e112:real^1->real^2) (t:real^1)`);;
    e (REWRITE_TAC [EQ_SYM_EQ]);;
e (UNDISCH_TAC ` (e112:real^1->real^2) (t:real^1) = (e312:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (UNDISCH_TAC ` (e312:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);; 
e (SIMP_TAC []);;


let THUMB_FLEX_EXT_IMP_SIMP_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*       THUMB (Flex. & Ext) SIMPLIFIED EQS. EQUALS STATE-SPACE MODEL        *)
(* ------------------------------------------------------------------------- *)

g`! (p0:real^2) q0 (e111:real^1->real^2) e112 f112 e121 f122 e131 f141 f143 
     (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se (t:real^1).
     (f122 t = inertance_f Jm_1 e121 p0 t) /\ (f112 t = res_f Ra_1 e111 t ) /\
      (e111 t = (e112 t - Cx Motor_1 * inertance_f Jm_1 e121 p0 t)) /\ 
        ( f143 t = (--inertance_f J_1 e131 p0 t + Cx Geer_1 * inertance_f Jm_1 e121 p0 t))
 ==> (thumb_flex_ext_simplified_eqs p0 q0 e111 e112 f112 e121 f122 e131 f141 f143 
     Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se t) = 
     (thumb_flex_ext_ss_model p0 q0 e121 e131 f141 Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 D_1 K_1 Se t)`;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [thumb_flex_ext_simplified_eqs;thumb_flex_ext_ss_model;
                ss_model;thumb_flex_ext_system_mat;
                thumb_flex_ext_input_mat;thumb_flex_ext_state_vec;
                thumb_flex_ext_state_vec_der;thumb_flex_ext_input_vec]);;
e (SUBGOAL_THEN`vector [vector [Cx (Motor_1 / Ra_1)]; vector [Cx (&0)]; 
                vector [Cx (&0)]]:complex^1^3 ** vector [Cx Se] = 
                vector [(Cx (Motor_1 / Ra_1)* Cx(Se));Cx (&0);Cx (&0)]`ASSUME_TAC);;
e (CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e (SIMP_TAC [COMPLEX_MUL_LZERO]);;
e (ASM_SIMP_TAC[]);;
e (SUBGOAL_THEN`vector [vector [ Cx ( (-- Dm_1 / Jm_1) - ((((Geer_1) pow 2) * (D_1)) / Jm_1) - (((Motor_1) pow 2) / (Jm_1 * Ra_1)));
                             Cx (((Geer_1) * (D_1)) / J_1); Cx (-- Geer_1 / K_1)];
                   vector [ Cx ((Geer_1 * D_1) / Jm_1);  Cx (-- D_1 / J_1); Cx (&1 / K_1)];
                    vector [ Cx (Geer_1 / Jm_1); Cx (-- &1 / J_1); Cx(&0)]]:complex^3^3 **
                vector [(momentum e121 p0 t); (momentum e131 p0 t); (displacement f141 q0 t)] = 
             vector [(Cx ( (-- Dm_1 / Jm_1) - ((((Geer_1) pow 2) * (D_1)) / Jm_1) - (((Motor_1) pow 2) / (Jm_1 * Ra_1))) * 
                       momentum e121 p0 t + Cx (((Geer_1) * (D_1)) / J_1) * momentum e131 p0 t + Cx (-- Geer_1 / K_1) *
                       displacement f141 q0 t); (Cx ((Geer_1 * D_1) / Jm_1) * momentum e121 p0 t + Cx (-- D_1 / J_1) * momentum e131 p0 t +
                       Cx (&1 / K_1) * displacement f141 q0 t);
                       (Cx (Geer_1 / Jm_1) * momentum e121 p0 t + Cx (-- &1 / J_1) * momentum e131 p0 t)]`ASSUME_TAC);;

e(CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e(SIMP_TAC [COMPLEX_MUL_LZERO]);;
e(SIMP_TAC [COMPLEX_ADD_RID]);;
e(ASM_SIMP_TAC[]);;
e(POP_ASSUM (K ALL_TAC));;
e(POP_ASSUM (K ALL_TAC));;
e(REWRITE_TAC [GSYM CX_SUB]);;
e(CVEC_CMAT_SIMP_TAC []);;
e (REWRITE_TAC [MATRIX_ADD_COMPONENT]);;
e(CVEC_CMAT_SIMP_TAC []);;
e(REWRITE_TAC [GSYM VECTOR_ADD_COMPONENT]);;
e( SIMP_TAC [COMPLEX_ADD_RID] );;
e(REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;
 
let THUMB_FLEX_EXT_SIMP_EQS_SSM = top_thm();;


(* ------------------------------------------------------------------------- *)
(*                 THUMB (Flex. & Ext) FINAL FORM                            *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) q0 (e111:real^1->real^2)e111 e112 f112 e113 f113 e121 f122 e123 f123 e124
           f124 e131 e132 f132 e133 f133 f141 e142 f142 f143 e312
    (Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se (t:real^1).
     (&0 < Jm_1) /\  (&0 < Ra_1) /\  (&0 < J_1) /\  (&0 < K_1) /\ 
      (f122 t = inertance_f Jm_1 e121 p0 t) /\ (f112 t = res_f Ra_1 e111 t ) /\
      (e111 t = (e112 t - Cx Motor_1 * inertance_f Jm_1 e121 p0 t)) /\ 
        ( f143 t = (--inertance_f J_1 e131 p0 t + Cx Geer_1 * inertance_f Jm_1 e121 p0 t)) /\
         (e312 t = e112 t) /\ (e312 t = src_e Se t) 
  ==> bg_main (thumb_flex_ext p0 q0 e111 e112 f112 e113 f113 e121 f122 e123 f123 e124
           f124 e131 e132 f132 e133 f133 f141 e142 f142 f143 
             Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1) t =
      (thumb_flex_ext_ss_model p0 q0 e121 e131 f141 Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 D_1 K_1 Se t)`;;



e (REPEAT STRIP_TAC);;
e (MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `thumb_flex_ext_simplified_eqs p0 q0 e111 e112 f112 e121 f122 e131 f141 f143 
     Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 K_1 D_1 Se t`);;
e (CONJ_TAC);;
e (MATCH_MP_TAC THUMB_FLEX_EXT_IMP_SIMP_EQS);;
e (EXISTS_TAC ` (e312:real^1->real^2)`);;
e (ASM_REWRITE_TAC []);;
e (MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `(e312:real^1->real^2) (t:real^1)`);;
e (CONJ_TAC);;
e (UNDISCH_TAC ` (e312:real^1->real^2) (t:real^1) = (e112:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (UNDISCH_TAC ` (e312:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);; 
e (SIMP_TAC []);;
e (MATCH_MP_TAC THUMB_FLEX_EXT_SIMP_EQS_SSM);;
e (ASM_REWRITE_TAC []);;


let THUMB_FLEX_EXT_FINAL = top_thm();;


(* ------------------------------------------------------------------------- *)
(*                 THUMB (Abd. & Add) SIMPLIFICATION                         *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2)(e211:real^1->real^2) e212 f212 e221 f222 e231 f233 e311
    (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se (t:real^1).
     (&0 < Jm_2) /\  (&0 < Ra_2) /\  (&0 < J_2) /\ 
     (e311 t = e212 t) /\ (e311 t = src_e Se t) /\ 
      (f222 t = inertance_f Jm_2 e221 p0 t) /\ 
       (f233 t =  (-- inertance_f J_2 e231 p0 t + Cx Geer_2 * (inertance_f Jm_2 e221 p0 t))) /\ 
        (e211 t =  (-- Cx Motor_2 * inertance_f Jm_2 e221 p0 t + e212 t ))
 ==> thumb_abd_add_eqs p0 e211 e212 f212 e221 f222 e231 f233 
     Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 t =
     thumb_abd_add_simplified_eqs p0 e211 e212 f212 e221 f222 e231 f233
      Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se t `;;
     


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [thumb_abd_add_eqs;thumb_abd_add_simplified_eqs]);;
e (REWRITE_TAC [res_e;res_f;inertance_f; compliance_e;src_e]);;
e (ASM_REWRITE_TAC [inertance_f]);;
e (SUBGOAL_THEN ` (e212:real^1->real^2) (t:real^1) = (e311:real^1->real^2) (t:real^1)` ASSUME_TAC);;
    e (UNDISCH_TAC ` (e311:real^1->real^2) (t:real^1) = (e212:real^1->real^2) (t:real^1)`);;
    e (REWRITE_TAC [EQ_SYM_EQ]);;
e (UNDISCH_TAC ` (e212:real^1->real^2) (t:real^1) = (e311:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (UNDISCH_TAC ` (e311:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);; 
e (SIMP_TAC [src_e]);;
e (DISCH_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let THUMB_ABD_ADD_EQS_SIMPLIFY = top_thm();;



(* ------------------------------------------------------------------------- *)
(*        IMPLEMENTATION OF THUMB (Abd. & Add) EQUALS SIMP. EQS.             *)
(* ------------------------------------------------------------------------- *)



g `!(p0:real^2) (e211:real^1->real^2) e212 f212 e213 f213 e221 f222 e223 f223 e224 e311
        f224 e231 e232 f232 f233 (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se (t:real^1).
       (&0 < Jm_2) /\  (&0 < Ra_2) /\  (&0 < J_2) /\ 
     (e311 t = e212 t) /\ (e311 t = src_e Se t) /\ 
      (f222 t = inertance_f Jm_2 e221 p0 t) /\ 
       (f233 t =  (-- inertance_f J_2 e231 p0 t + Cx Geer_2 * (inertance_f Jm_2 e221 p0 t))) /\ 
        (e211 t =  (-- Cx Motor_2 * inertance_f Jm_2 e221 p0 t + e212 t ))
 ==>  bg_main (thumb_abd_add p0 e211 e212 f212 e213 f213 e221 f222 e223 f223 e224
        f224 e231 e232 f232 f233 Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2) t =
       (thumb_abd_add_simplified_eqs p0 e211 e212 f212 e221 f222 e231 f233
        Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se t) `;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [THUMB_ABD_ADD_IMP_EQS]);;
e (MATCH_MP_TAC THUMB_ABD_ADD_EQS_SIMPLIFY);;
e (EXISTS_TAC ` (e311:real^1->real^2)`);;
e (ASM_REWRITE_TAC []);;
e (MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `(e311:real^1->real^2) (t:real^1)`);;
e (CONJ_TAC);;
e (UNDISCH_TAC ` (e311:real^1->real^2) (t:real^1) = (e212:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (UNDISCH_TAC ` (e311:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);; 
e (SIMP_TAC []);;

let THUMB_ABD_ADD_IMP_SIMP_EQS = top_thm();;

(* ------------------------------------------------------------------------- *)
(*       THUMB (Abd. & Add) SIMPLIFIED EQS. EQUALS STATE-SPACE MODEL         *)
(* ------------------------------------------------------------------------- *)

g`! (p0:real^2) (e211:real^1->real^2) e212 f212 e221 f222 e231 f233 
     (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se (t:real^1).
      (f222 t = inertance_f Jm_2 e221 p0 t) /\ 
       (f233 t =  (-- inertance_f J_2 e231 p0 t + Cx Geer_2 * (inertance_f Jm_2 e221 p0 t))) /\ 
        (e211 t =  (-- Cx Motor_2 * inertance_f Jm_2 e221 p0 t + e212 t )) /\ (f212 t = res_f Ra_2 e211 t)
 ==> (thumb_abd_add_simplified_eqs p0 e211 e212 f212 e221 f222 e231 f233 
           Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se t) = 
     (thumb_abd_add_ss_model p0 e221 e231 Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se t)`;;

e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [thumb_abd_add_simplified_eqs;thumb_abd_add_ss_model;
                ss_model;thumb_abd_add_system_mat;
                thumb_abd_add_input_mat;thumb_abd_add_state_vec;
                thumb_abd_add_state_vec_der;thumb_abd_add_input_vec]);;

e (SUBGOAL_THEN`vector [vector [Cx (Motor_2 / Ra_2)]; vector [Cx (&0)]]:complex^1^2 ** vector [Cx Se] = 
                vector [(Cx (Motor_2 / Ra_2)* Cx(Se));Cx (&0)]`ASSUME_TAC);;
e (CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e (SIMP_TAC [COMPLEX_MUL_LZERO]);;
e (ASM_SIMP_TAC[]);;

e (SUBGOAL_THEN`vector [vector [Cx ( (-- Dm_2 / Jm_2) - ((((Geer_2) pow 2) * (D_2)) / Jm_2) - (((Motor_2) pow 2) / (Jm_2 * Ra_2)));
                             Cx (((Geer_2) * (D_2)) / J_2)];
                        vector [ Cx (((Geer_2) * (D_2)) / Jm_2); Cx ((-- D_2) / J_2)]]:complex^2^2 ** 
                          vector [momentum e221 p0 t; momentum e231 p0 t] = 
                vector [(Cx ( (-- Dm_2 / Jm_2) - ((((Geer_2) pow 2) * (D_2)) / Jm_2) - (((Motor_2) pow 2) / (Jm_2 * Ra_2))) *
                          momentum e221 p0 t + Cx (((Geer_2) * (D_2)) / J_2) * momentum e231 p0 t);
                            (Cx (((Geer_2) * (D_2)) / Jm_2) * momentum e221 p0 t + Cx ((-- D_2) / J_2) * momentum e231 p0 t)]`ASSUME_TAC);;

e(CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e(ASM_SIMP_TAC[]);;
e(POP_ASSUM (K ALL_TAC));;
e(POP_ASSUM (K ALL_TAC));;
e(REWRITE_TAC [GSYM CX_SUB]);;
e(CVEC_CMAT_SIMP_TAC []);;
e (REWRITE_TAC [MATRIX_ADD_COMPONENT]);;
e(CVEC_CMAT_SIMP_TAC []);;
e(REWRITE_TAC [GSYM VECTOR_ADD_COMPONENT]);;
e( SIMP_TAC [COMPLEX_ADD_RID] );;
e(REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;


let THUMB_ABD_ADD_SIMP_EQS_SSM = top_thm();;

(* ------------------------------------------------------------------------- *)
(*                 THUMB (Abd. & Add) FINAL FORM                             *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2)(e211:real^1->real^2) e212 f212 e213 f213 e221 f222 e223 f223 e224
    f224 e231 e232 f232 f233 e311 (Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se (t:real^1).
    (&0 < Jm_2) /\  (&0 < Ra_2) /\  (&0 < J_2) /\ 
     (e311 t = e212 t) /\ (e311 t = src_e Se t) /\ 
      (f222 t = inertance_f Jm_2 e221 p0 t) /\ (f212 t = res_f Ra_2 e211 t) /\
       (f233 t =  (-- inertance_f J_2 e231 p0 t + Cx Geer_2 * (inertance_f Jm_2 e221 p0 t))) /\ 
        (e211 t =  (-- Cx Motor_2 * inertance_f Jm_2 e221 p0 t + e212 t ))
  ==> bg_main (thumb_abd_add p0 e211 e212 f212 e213 f213 e221 f222 e223 f223 e224
    f224 e231 e232 f232 f233 Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2) t = 
    (thumb_abd_add_ss_model p0 e221 e231 Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se t)`;;


e (REPEAT STRIP_TAC);;
e (MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `thumb_abd_add_simplified_eqs p0 e211 e212 f212 e221 f222 e231 f233 
                                            Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2 Se t`);;
e (CONJ_TAC);;
e (MATCH_MP_TAC THUMB_ABD_ADD_IMP_SIMP_EQS);;
e (EXISTS_TAC ` (e311:real^1->real^2)`);;
e (ASM_REWRITE_TAC []);;
e (MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `(e311:real^1->real^2) (t:real^1)`);;
e (CONJ_TAC);;
e (UNDISCH_TAC ` (e311:real^1->real^2) (t:real^1) = (e212:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (UNDISCH_TAC ` (e311:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);; 
e (SIMP_TAC []);;
e (MATCH_MP_TAC THUMB_ABD_ADD_SIMP_EQS_SSM);;
e (ASM_REWRITE_TAC []);;


let THUMB_ABD_ADD_FINAL = top_thm();;

(* ------------------------------------------------------------------------- *)
(*                  THUMB (UP/Down) SIMPLIFICATION                           *)
(* ------------------------------------------------------------------------- *)


g `!p0 (e311:real^1->real^2) e312 e313 e314 e321 e331 f332 f343 e341  
    (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se (t:real^1).
     (&0 < Jm_3) /\  (&0 < Ra_3) /\  (&0 < J_3) /\ 
      (f332 t = inertance_f Jm_3 e331 p0 t) /\ 
        (f343 t =  (-- inertance_f J_3 e341 p0 t + Cx Geer_3 * (inertance_f Jm_3 e331 p0 t))) /\
          (e321 t =  (-- Cx Motor_3 * inertance_f Jm_3 e331 p0 t + src_e Se t))
 ==> thumb_up_down_eqs p0 e311 e312 e313 e314 e321 e331 f332 e341 f343 
     Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se t = 
     thumb_up_down_simplified_eqs p0 e311 e312 e313 e314 e321 e331 f332 e341 f343 
     Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se t`;;

e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [thumb_up_down_eqs;thumb_up_down_simplified_eqs]);;
e (REWRITE_TAC [res_e;res_f;inertance_f; compliance_e;src_e]);;
e (ASM_REWRITE_TAC [inertance_f;src_e]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let THUMB_UP_DOWN_EQS_SIMPLIFY = top_thm();;


(* ------------------------------------------------------------------------- *)
(*              IMPLEMENTATION OF THUMB (UP/Down) EQUALS SIMP. EQS.          *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) (e311:real^1->real^2) f311 e312 f312 e313 f313 e314 f314 
     f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
      (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se (t:real^1).
       (&0 < Jm_3) /\  (&0 < Ra_3) /\  (&0 < J_3) /\ 
      (f332 t = inertance_f Jm_3 e331 p0 t) /\ 
        (f343 t =  (-- inertance_f J_3 e341 p0 t + Cx Geer_3 * (inertance_f Jm_3 e331 p0 t))) /\
          (e321 t =  (-- Cx Motor_3 * inertance_f Jm_3 e331 p0 t + src_e Se t))
 ==>  bg_main (thumb_up_down p0 e311 f311 e312 f312 e313 f313 e314 f314 
       f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
        Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se) t =
       (thumb_up_down_simplified_eqs p0 e311 e312 e313 e314 e321 e331 f332 e341 f343 
     Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se t) `;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [THUMB_UP_DOWN_IMP_EQS]);;
e (MATCH_MP_TAC THUMB_UP_DOWN_EQS_SIMPLIFY);;
e (ASM_REWRITE_TAC []);;


let THUMB_UP_DOWN_IMP_SIMP_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*           THUMB (UP/Down) SIMPLIFIED EQS. EQUALS STATE-SPACE MODEL        *)
(* ------------------------------------------------------------------------- *)

g`! (p0:real^2) (e311:real^1->real^2) e312 e313 e314 e321 e331 f332 e341 f343 
     (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se (t:real^1). 
      (e311 t = src_e Se t) /\ (e312 t = src_e Se t) /\ (e313 t = src_e Se t) /\
       (e314 t = src_e Se t) /\ (f332 t = inertance_f Jm_3 e331 p0 t ) /\ 
        (f343 t =  (-- inertance_f J_3 e341 p0 t + Cx Geer_3 * (inertance_f Jm_3 e331 p0 t))) /\
          (e321 t =  (-- Cx Motor_3 * inertance_f Jm_3 e331 p0 t + src_e Se t)) 
 ==> (thumb_up_down_simplified_eqs p0 e311 e312 e313 e314 e321 e331 f332 e341 f343 
     Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se t) = 
     (thumb_up_down_ss_model p0 e331 e341 Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se t)`;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [thumb_up_down_simplified_eqs;thumb_up_down_ss_model;
                ss_model;thumb_up_down_system_mat;
                thumb_up_down_input_mat;thumb_up_down_state_vec;
                thumb_up_down_state_vec_der;thumb_up_down_input_vec]);;

e (SUBGOAL_THEN`vector [vector [Cx (Motor_3 / Ra_3)]; vector [Cx (&0)]]:complex^1^2 ** vector [Cx Se] = 
                vector [(Cx (Motor_3 / Ra_3)* Cx(Se));Cx (&0)]`ASSUME_TAC);;
e (CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e (SIMP_TAC [COMPLEX_MUL_LZERO]);;
e (ASM_SIMP_TAC[]);;

e (SUBGOAL_THEN`vector [vector [Cx ( (-- Dm_3 / Jm_3) - ((((Geer_3) pow 2) * (D_3)) / Jm_3) - (((Motor_3) pow 2) / (Jm_3 * Ra_3)));
                                Cx (((Geer_3) * (D_3)) / J_3)];
                        vector [ Cx (((Geer_3) * (D_3)) / Jm_3); Cx ((-- D_3) / J_3)]]:complex^2^2 ** 
                          vector [momentum e331 p0 t; momentum e341 p0 t] = 
                vector [(Cx ( (-- Dm_3 / Jm_3) - ((((Geer_3) pow 2) * (D_3)) / Jm_3) - (((Motor_3) pow 2) / (Jm_3 * Ra_3))) *
                          momentum e331 p0 t + Cx (((Geer_3) * (D_3)) / J_3) * momentum e341 p0 t);
                            (Cx (((Geer_3) * (D_3)) / Jm_3) * momentum e331 p0 t + Cx ((-- D_3) / J_3) * momentum e341 p0 t)]`ASSUME_TAC);;

e(CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e(ASM_SIMP_TAC[]);;
e(POP_ASSUM (K ALL_TAC));;
e(POP_ASSUM (K ALL_TAC));;
e(REWRITE_TAC [GSYM CX_SUB]);;
e(CVEC_CMAT_SIMP_TAC []);;
e (REWRITE_TAC [MATRIX_ADD_COMPONENT]);;
e(CVEC_CMAT_SIMP_TAC []);;
e(REWRITE_TAC [GSYM VECTOR_ADD_COMPONENT]);;
e( SIMP_TAC [COMPLEX_ADD_RID] );;
e(REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;


let THUMB_UP_DOWN_SIMP_EQS_SSM = top_thm();;


(* ------------------------------------------------------------------------- *)
(*                    THUMB (UP/Down) FINAL FORM                             *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) (e311:real^1->real^2) f311 e312 f312 e313 f313 e314 f314 
     f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343
    (Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se (t:real^1).
     (&0 < Jm_3) /\  (&0 < Ra_3) /\  (&0 < J_3) /\ 
      (e311 t = src_e Se t) /\ (e312 t = src_e Se t) /\ (e313 t = src_e Se t) /\
       (e314 t = src_e Se t) /\ (f332 t = inertance_f Jm_3 e331 p0 t ) /\ 
        (f343 t =  (-- inertance_f J_3 e341 p0 t + Cx Geer_3 * (inertance_f Jm_3 e331 p0 t))) /\
          (e321 t =  (-- Cx Motor_3 * inertance_f Jm_3 e331 p0 t + src_e Se t)) 
 ==> bg_main (thumb_up_down p0 e311 f311 e312 f312 e313 f313 e314 f314 
     f315 e316 f316 e321 e322 f322 e323 f323 e331 f332 e333 f333 e334 f334 e341 e342 f342 f343 
     Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se) t =
     (thumb_up_down_ss_model p0 e331 e341 Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se t)`;;



e (REPEAT STRIP_TAC);;
e (MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `thumb_up_down_simplified_eqs p0 e311 e312 e313 e314 e321 e331 f332 e341 f343 
                                             Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3 Se t`);;
e (CONJ_TAC);;
e (MATCH_MP_TAC THUMB_UP_DOWN_IMP_SIMP_EQS);;
e (ASM_REWRITE_TAC []);;
e (MATCH_MP_TAC THUMB_UP_DOWN_SIMP_EQS_SSM);;
e (ASM_REWRITE_TAC []);;


let THUMB_UP_DOWN_FINAL = top_thm();;


(* ------------------------------------------------------------------------- *)
(*              INDEX FINGER (Flex. & Ext) SIMPLIFICATION                    *)
(* ------------------------------------------------------------------------- *)



g `!(p0:real^2) q0 (e411:real^1->real^2) e411 e412 f412 e421 f422 e431 f441 f443 e313
      (Ra_4:real) Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 Se (t:real^1).
       (&0 < Jm_4) /\  (&0 < Ra_4) /\  (&0 < J_4) /\  (&0 < K_2) /\
        (f443 t = (--inertance_f J_4 e431 p0 t + Cx Geer_4 * inertance_f Jm_4 e421 p0 t)) /\ 
         ( f422 t = inertance_f Jm_4 e421 p0 t) /\ 
          (e411 t = (e412 t - Cx Motor_4 * inertance_f Jm_4 e421 p0 t)) /\ 
           (e313 t = e412 t) /\ (e313 t = src_e Se t)
  ==> index_finger_flex_ext_eqs p0 q0 e411 e412 f412 e421 f422 e431 f441 f443 
      Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 t = 
       index_finger_flex_ext_simplified_eqs p0 q0 e411 f412 e421 f422 e431 f441 f443 
       Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 Se t`;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [index_finger_flex_ext_eqs;index_finger_flex_ext_simplified_eqs]);;
e (REWRITE_TAC [res_e;res_f;inertance_f; compliance_e]);;
e (SUBGOAL_THEN ` (e412:real^1->real^2) (t:real^1) = (e313:real^1->real^2) (t:real^1)` ASSUME_TAC);;
    e (UNDISCH_TAC ` (e313:real^1->real^2) (t:real^1) = (e412:real^1->real^2) (t:real^1)`);;
    e (REWRITE_TAC [EQ_SYM_EQ]);;
e (UNDISCH_TAC ` (e412:real^1->real^2) (t:real^1) = (e313:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (UNDISCH_TAC ` (e313:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);; 
e (SIMP_TAC [src_e]);;
e (DISCH_TAC);;
e (SUBGOAL_THEN ` (momentum_der e421 p0 t = --(Cx Dm_4 * f422 t) - Cx Geer_4 * (Cx (&1 / K_2) * displacement f441 q0 t + Cx D_4 * f443 t) +
                   Cx Motor_4 * Cx (&1 / Ra_4) * e411 t) = ( momentum_der e421 p0 t = (Cx (--Dm_4 / Jm_4) - Cx ((Geer_4 pow 2 * D_4) / Jm_4) -
                    Cx (Motor_4 pow 2 / (Jm_4 * Ra_4))) * momentum e421 p0 t + Cx ((Geer_4 * D_4) / J_4) * momentum e431 p0 t +
                     Cx (--Geer_4 / K_2) * displacement f441 q0 t + Cx (Motor_4 / Ra_4) * Cx Se)`ASSUME_TAC);;
e (UNDISCH_TAC ` (f422:real^1->real^2) (t:real^1) = inertance_f Jm_4 e421 p0 t`);;
e (SIMP_TAC [inertance_f]);;
e (DISCH_TAC);;
e (UNDISCH_TAC `(e411:real^1->real^2) (t:real^1) = e412 t - Cx Motor_4 * inertance_f Jm_4 e421 p0 t`);;
e (SIMP_TAC [inertance_f]);;
e (DISCH_TAC);;
e (UNDISCH_TAC ` (e412:real^1->real^2) (t:real^1) = (e313:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (UNDISCH_TAC ` (e313:real^1->real^2) (t:real^1) = Cx (Se:real) `);; 
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (UNDISCH_TAC ` (f443:real^1->real^2) (t:real^1) = --inertance_f J_4 e431 p0 t + Cx Geer_4 * inertance_f Jm_4 e421 p0 t`);;
e (SIMP_TAC [inertance_f]);;
e (DISCH_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `(momentum_der e421 p0 t = --(Cx Dm_4 * f422 t) - Cx Geer_4 * (Cx (&1 / K_2) * displacement f441 q0 t + Cx D_4 * f443 t) +
                   Cx Motor_4 * Cx (&1 / Ra_4) * e411 t) = ( momentum_der e421 p0 t = (Cx (--Dm_4 / Jm_4) - Cx ((Geer_4 pow 2 * D_4) / Jm_4) -
                    Cx (Motor_4 pow 2 / (Jm_4 * Ra_4))) * momentum e421 p0 t + Cx ((Geer_4 * D_4) / J_4) * momentum e431 p0 t +
                     Cx (--Geer_4 / K_2) * displacement f441 q0 t + Cx (Motor_4 / Ra_4) * Cx Se)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (SUBGOAL_THEN ` (momentum_der e431 p0 t = Cx (&1 / K_2) * displacement f441 q0 t + Cx D_4 * f443 t) = (momentum_der e431 p0 t =
                   Cx ((Geer_4 * D_4) / Jm_4) * momentum e421 p0 t + Cx (--D_4 / J_4) * momentum e431 p0 t + 
                     Cx (&1 / K_2) * displacement f441 q0 t)`ASSUME_TAC);;
e (UNDISCH_TAC ` (f443:real^1->real^2) (t:real^1) = --inertance_f J_4 e431 p0 t + Cx Geer_4 * inertance_f Jm_4 e421 p0 t`);;
e (SIMP_TAC [inertance_f]);;
e (DISCH_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `(momentum_der e431 p0 t = Cx (&1 / K_2) * displacement f441 q0 t + Cx D_4 * f443 t) = (momentum_der e431 p0 t =
                   Cx ((Geer_4 * D_4) / Jm_4) * momentum e421 p0 t + Cx (--D_4 / J_4) * momentum e431 p0 t + 
                     Cx (&1 / K_2) * displacement f441 q0 t)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (SUBGOAL_THEN `(displacement_der f441 q0 t = --(Cx (&1 / J_4) * momentum e431 p0 t) +
                  Cx Geer_4 * Cx (&1 / Jm_4) * momentum e421 p0 t) = (displacement_der f441 q0 t = Cx (Geer_4 / Jm_4) * momentum e421 p0 t +
                    Cx (-- &1 / J_4) * momentum e431 p0 t)`ASSUME_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `(displacement_der f441 q0 t = --(Cx (&1 / J_4) * momentum e431 p0 t) +
                  Cx Geer_4 * Cx (&1 / Jm_4) * momentum e421 p0 t) = (displacement_der f441 q0 t = Cx (Geer_4 / Jm_4) * momentum e421 p0 t +
                    Cx (-- &1 / J_4) * momentum e431 p0 t)`);;
e (SIMP_TAC []);;

let INDEX_FINGER_FLEX_EXT_EQS_SIMPLIFY = top_thm();;


(* ------------------------------------------------------------------------- *)
(*   IMPLEMENTATION OF INDEX FINGER (Flex. & Ext) EQUALS SIMP. EQS.          *)
(* ------------------------------------------------------------------------- *)

g `!(p0:real^2) q0 (e411:real^1->real^2) p0 q0 e411 e412 f412 e413 f413 e421 f422 e423 f423 e424
       f424 e431 e432 f432 e433 f433 f441 e442 f442 f443 e313
      (Ra_4:real) Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 Se (t:real^1).
       (&0 < Jm_4) /\  (&0 < Ra_4) /\  (&0 < J_4) /\  (&0 < K_2) /\
        (f443 t = (--inertance_f J_4 e431 p0 t + Cx Geer_4 * inertance_f Jm_4 e421 p0 t)) /\ 
         ( f422 t = inertance_f Jm_4 e421 p0 t) /\ 
          (e411 t = (e412 t - Cx Motor_4 * inertance_f Jm_4 e421 p0 t)) /\
           (e313 t = e412 t) /\ (e313 t = src_e Se t)
 ==>  bg_main (index_finger_flex_ext p0 q0 e411 e412 f412 e413 f413 e421 f422 e423 f423 e424
       f424 e431 e432 f432 e433 f433 f441 e442 f442 f443 
       Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4) t =
       (index_finger_flex_ext_simplified_eqs p0 q0 e411 f412 e421 f422 e431 f441 f443 
       Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 Se t) `;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [INDEX_FINGER_FLEX_EXT_IMP_EQS]);;
e (MATCH_MP_TAC INDEX_FINGER_FLEX_EXT_EQS_SIMPLIFY);;
e (EXISTS_TAC ` (e313:real^1->real^2)`);;
e (REPEAT STRIP_TAC);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC ` (e313:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);;
e (SIMP_TAC []);;


let INDEX_FINGER_FLEX_EXT_IMP_SIMP_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*   INDEX FINGER (Flex. & Ext) SIMPLIFIED EQS. EQUALS STATE-SPACE MODEL     *)
(* ------------------------------------------------------------------------- *)

g`! (p0:real^2) q0 (e421:real^1->real^2) e431 f441 (Ra_4:real) Motor_4 Jm_4
    Dm_4 Geer_4 J_4 D_4 K_2 Se (t:real^1).
     e411 t = (Cx(Se) - Cx Motor_4 * inertance_f Jm_4 e421 p0 t) /\
         f412 t = res_f Ra_4 e411 t /\ f422 t = inertance_f Jm_4 e421 p0 t /\
           f443 t = (--inertance_f J_4 e431 p0 t + Cx Geer_4 * inertance_f Jm_4 e421 p0 t) 
 ==> (index_finger_flex_ext_simplified_eqs p0 q0 e411 f412 e421 f422 e431 f441 f443 
       Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 Se t) = 
     (index_finger_flex_ext_ss_model p0 q0 e421 e431 f441 Ra_4 Motor_4 Jm_4 
      Dm_4 Geer_4 J_4 D_4 K_2 Se t)`;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC  [index_finger_flex_ext_simplified_eqs;index_finger_flex_ext_ss_model;ss_model;index_finger_flex_ext_system_mat;
                 index_finger_flex_ext_input_mat;index_finger_flex_ext_state_vec;
                 index_finger_flex_ext_state_vec_der;index_finger_flex_ext_input_vec]);;
e (SUBGOAL_THEN`vector [vector [Cx (Motor_4 / Ra_4)]; vector [Cx (&0)]; vector [Cx (&0)]]:complex^1^3 ** vector [Cx Se] = 
                vector[(Cx (Motor_4 / Ra_4)* Cx(Se));Cx (&0);Cx (&0)]`ASSUME_TAC);;
e (CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e (SIMP_TAC [COMPLEX_MUL_LZERO]);;
e (ASM_SIMP_TAC[]);;
e (SUBGOAL_THEN`vector[vector[Cx(--Dm_4 / Jm_4 - (Geer_4 pow 2 * D_4) / Jm_4 - Motor_4 pow 2 / (Jm_4 * Ra_4));
                              Cx ((Geer_4 * D_4) / J_4); Cx (--Geer_4 / K_2)];
                vector [Cx ((Geer_4 * D_4) / Jm_4); Cx (--D_4 / J_4); Cx (&1 / K_2)];
                vector [Cx (Geer_4 / Jm_4); Cx (-- &1 / J_4); Cx (&0)]]:complex^3^3 **
                vector [(momentum e421 p0 t); (momentum e431 p0 t); (displacement f441 q0 t)] =  
                vector [(Cx (--Dm_4 / Jm_4 - (Geer_4 pow 2 * D_4) / Jm_4 - Motor_4 pow 2 / (Jm_4 * Ra_4)) * momentum e421 p0 t +
                        Cx ((Geer_4 * D_4) / J_4) * momentum e431 p0 t + Cx (--Geer_4 / K_2) * displacement f441 q0 t);
                        (Cx ((Geer_4 * D_4) / Jm_4) * momentum e421 p0 t + Cx (--D_4 / J_4) * momentum e431 p0 t + 
                        Cx (&1 / K_2) * displacement f441 q0 t);(Cx (Geer_4 / Jm_4)*momentum e421 p0 t + 
                        Cx (-- &1 / J_4) * momentum e431 p0 t)]`ASSUME_TAC);;
e(CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e(SIMP_TAC [COMPLEX_MUL_LZERO]);;
e(SIMP_TAC [COMPLEX_ADD_RID]);;
e(ASM_SIMP_TAC[]);;
e(POP_ASSUM (K ALL_TAC));;
e(POP_ASSUM (K ALL_TAC));;
e(REWRITE_TAC [GSYM CX_SUB]);;
e(CVEC_CMAT_SIMP_TAC []);;
e (REWRITE_TAC [MATRIX_ADD_COMPONENT]);;
e(CVEC_CMAT_SIMP_TAC []);;
e(REWRITE_TAC [GSYM VECTOR_ADD_COMPONENT]);;
e( SIMP_TAC [COMPLEX_ADD_RID] );;
e(REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;

let INDEX_FINGER_FLEX_EXT_SIMP_EQS_SSM = top_thm();;


(* ------------------------------------------------------------------------- *)
(*             INDEX FINGER (Flex. & Ext) FINAL FORM                         *)
(* ------------------------------------------------------------------------- *)


g `! (p0:real^2) q0 (e421:real^1->real^2) e431 f441 e313 (Ra_4:real) Motor_4 Jm_4 
      Dm_4 Geer_4 J_4 D_4 K_2 Se (t:real^1).
      (&0 < Jm_4) /\  (&0 < Ra_4) /\  (&0 < J_4) /\  (&0 < K_2) /\
        (f443 t = (--inertance_f J_4 e431 p0 t + Cx Geer_4 * inertance_f Jm_4 e421 p0 t)) /\ 
         ( f422 t = inertance_f Jm_4 e421 p0 t) /\ 
          (f412 t = res_f Ra_4 e411 t) /\ 
          (e411 t = (e412 t - Cx Motor_4 * inertance_f Jm_4 e421 p0 t)) /\ 
           (e313 t = e412 t) /\ (e313 t = src_e Se t)
 ==> bg_main (index_finger_flex_ext p0 q0 e411 e412 f412 e413 f413 e421 
     f422 e423 f423 e424 f424 e431 e432 f432 e433 f433 f441 e442 f442 f443 
      Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4) t = 
     (index_finger_flex_ext_ss_model p0 q0 e421 e431 f441 Ra_4 Motor_4 Jm_4 
      Dm_4 Geer_4 J_4 D_4 K_2 Se t)`;;


e (REPEAT STRIP_TAC);;
e (MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `index_finger_flex_ext_simplified_eqs p0 q0 e411 f412 e421 f422 e431 f441 f443 
       Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 K_2 D_4 Se t`);;
e (CONJ_TAC);;
e (MATCH_MP_TAC INDEX_FINGER_FLEX_EXT_IMP_SIMP_EQS);;
e (EXISTS_TAC ` (e313:real^1->real^2)`);;
e (REPEAT STRIP_TAC);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC ` (e313:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);;
e (SIMP_TAC []);;

e (MATCH_MP_TAC INDEX_FINGER_FLEX_EXT_SIMP_EQS_SSM);;;
e (REPEAT STRIP_TAC);;
e (SUBGOAL_THEN ` (e412:real^1->real^2) (t:real^1) = (e313:real^1->real^2) (t:real^1)` ASSUME_TAC);;
    e (UNDISCH_TAC ` (e313:real^1->real^2) (t:real^1) = (e412:real^1->real^2) (t:real^1)`);;
    e (REWRITE_TAC [EQ_SYM_EQ]);;
e (SUBGOAL_THEN `(e411 t = Cx Se - Cx Motor_4 * inertance_f Jm_4 e421 p0 t) = 
                  (e411 t = e412 t - Cx Motor_4 * inertance_f Jm_4 e421 p0 t)` ASSUME_TAC);;
e (UNDISCH_TAC ` (e412:real^1->real^2) (t:real^1) = (e313:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC[]);;
e (DISCH_TAC);;
e (UNDISCH_TAC ` (e313:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);; 
e (SIMP_TAC [src_e]);;
e (UNDISCH_TAC `(e411 t = Cx Se - Cx Motor_4 * inertance_f Jm_4 e421 p0 t) = 
                  (e411 t = e412 t - Cx Motor_4 * inertance_f Jm_4 e421 p0 t)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (UNDISCH_TAC `e411 t = e412 t - Cx Motor_4 * inertance_f Jm_4 e421 p0 t`);;
e (SIMP_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;


let INDEX_FINGER_FLEX_EXT_FINAL = top_thm();;

(* ------------------------------------------------------------------------- *)
(*              INDEX FINGER (Abd. & Add) SIMPLIFICATION                     *)
(* ------------------------------------------------------------------------- *)


g `!(p0:real^2) (e511:real^1->real^2) e512 f512 e521 f522 f533 e531 e314
    (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se (t:real^1).
     (&0 < Jm_5) /\  (&0 < Ra_5) /\  (&0 < J_5) /\ 
     (e314 t = e512 t) /\ (e314 t = src_e Se t) /\ 
      (f522 t = inertance_f Jm_5 e521 p0 t) /\ 
       (f533 t =  (-- inertance_f J_5 e531 p0 t + Cx Geer_5 * (inertance_f Jm_5 e521 p0 t))) /\ 
        (e511 t =  (-- Cx Motor_5 * inertance_f Jm_5 e521 p0 t + e512 t ))
 ==> index_finger_abd_add_eqs p0 e511 e512 f512 e521 f522 e531 f533
     Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 t = 
     index_finger_abd_add_simplified_eqs p0 e511 e512 f512 e521 f522 e531 f533 
      Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se t`;;
     


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [index_finger_abd_add_eqs;index_finger_abd_add_simplified_eqs]);;
e (REWRITE_TAC [res_e;res_f;inertance_f; compliance_e;src_e]);;
e (ASM_REWRITE_TAC [inertance_f]);;
e (SUBGOAL_THEN ` (e512:real^1->real^2) (t:real^1) = (e314:real^1->real^2) (t:real^1)` ASSUME_TAC);;
    e (UNDISCH_TAC ` (e314:real^1->real^2) (t:real^1) = (e512:real^1->real^2) (t:real^1)`);;
    e (REWRITE_TAC [EQ_SYM_EQ]);;
e (UNDISCH_TAC ` (e512:real^1->real^2) (t:real^1) = (e314:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (UNDISCH_TAC ` (e314:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);; 
e (SIMP_TAC [src_e]);;
e (DISCH_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;


let INDEX_FINGER_ABD_ADD_EQS_SIMPLIFY = top_thm();;


(* ------------------------------------------------------------------------- *)
(*   IMPLEMENTATION OF INDEX FINGER (Abd. & Add) EQUALS SIMP. EQS.           *)
(* ------------------------------------------------------------------------- *)

g `!(p0:real^2) (e511:real^1->real^2) e512 f512 e513 f513 e521 f522 e523 f523 e524
      f524 e531 e532 f532 f533 e314
    (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se (t:real^1).
     (&0 < Jm_5) /\  (&0 < Ra_5) /\  (&0 < J_5) /\ 
      (e314 t = e512 t) /\ (e314 t = src_e Se t) /\ 
      (f522 t = inertance_f Jm_5 e521 p0 t) /\ 
       (f533 t =  (-- inertance_f J_5 e531 p0 t + Cx Geer_5 * (inertance_f Jm_5 e521 p0 t))) /\ 
        (e511 t =  (-- Cx Motor_5 * inertance_f Jm_5 e521 p0 t + e512 t ))
 ==>  bg_main (index_finger_abd_add p0 e511 e512 f512 e513 f513 e521 f522 e523 f523 e524
      f524 e531 e532 f532 f533 Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5) t = 
       index_finger_abd_add_simplified_eqs p0 e511 e512 f512 e521 f522 e531 f533 
        Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se t`;;
   

e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [INDEX_FINGER_ABD_ADD_IMP_EQS]);;
e (MATCH_MP_TAC INDEX_FINGER_ABD_ADD_EQS_SIMPLIFY);;
e (EXISTS_TAC ` (e314:real^1->real^2)`);;
e (REPEAT STRIP_TAC);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC ` (e314:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);;
e (SIMP_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;


let INDEX_FINGER_ABD_ADD_IMP_SIMP_EQS = top_thm();;


(* ------------------------------------------------------------------------- *)
(*   INDEX FINGER (Abd. & Add.) SIMPLIFIED EQS. EQUALS STATE-SPACE MODEL     *)
(* ------------------------------------------------------------------------- *)


g`!(p0:real^2) (e511:real^1->real^2) e512 f512 e521 f522 e531 f533 (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se (t:real^1). 
      (f522 t = inertance_f Jm_5 e521 p0 t) /\ (f512 t = res_f Ra_5 e511 t) /\
       (f533 t =  (-- inertance_f J_5 e531 p0 t + Cx Geer_5 * (inertance_f Jm_5 e521 p0 t))) /\ 
        (e511 t =  (-- Cx Motor_5 * inertance_f Jm_5 e521 p0 t + e512 t))  
==> (index_finger_abd_add_simplified_eqs p0 e511 e512 f512 e521 f522 e531 f533 Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se t) = 
       (index_finger_abd_add_ss_model p0 e521 e531 Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se t) `;;


e (REPEAT STRIP_TAC);;
e (REWRITE_TAC [index_finger_abd_add_simplified_eqs;index_finger_abd_add_ss_model;ss_model;
                 index_finger_abd_add_system_mat;index_finger_abd_add_input_mat;index_finger_abd_add_state_vec;
                  index_finger_abd_add_state_vec_der;index_finger_abd_add_input_vec]);;

e (SUBGOAL_THEN`vector [vector [Cx (Motor_5 / Ra_5)]; vector [Cx (&0)]]:complex^1^2 ** vector [Cx Se] = 
                vector [(Cx (Motor_5 / Ra_5)* Cx(Se));Cx (&0)]`ASSUME_TAC);;
e (CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e (SIMP_TAC [COMPLEX_MUL_LZERO]);;
e (ASM_SIMP_TAC[]);;
e (SUBGOAL_THEN`vector [vector [Cx (--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5));Cx ((Geer_5 * D_5) / J_5)];
                       vector [Cx ((Geer_5 * D_5) / Jm_5); Cx (--D_5 / J_5)]]:complex^2^2 ** vector [momentum e521 p0 t; momentum e531 p0 t] = 
                vector [(Cx (--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 -Motor_5 pow 2 / (Jm_5 * Ra_5)) * momentum e521 p0 t + 
                        Cx ((Geer_5 * D_5) / J_5) * momentum e531 p0 t); (Cx ((Geer_5 * D_5) / Jm_5) * momentum e521 p0 t + 
                        Cx (--D_5 / J_5) * momentum e531 p0 t)]`ASSUME_TAC);;
e(CVEC_CMAT_SIMP_TAC [CMATRIX_CVECTOR_MUL_COMPONENT]);;
e(ASM_SIMP_TAC[]);;
e(POP_ASSUM (K ALL_TAC));;
e(POP_ASSUM (K ALL_TAC));;
e(REWRITE_TAC [GSYM CX_SUB]);;
e(CVEC_CMAT_SIMP_TAC []);;
e (REWRITE_TAC [MATRIX_ADD_COMPONENT]);;
e(CVEC_CMAT_SIMP_TAC []);;
e(REWRITE_TAC [GSYM VECTOR_ADD_COMPONENT]);;
e( SIMP_TAC [COMPLEX_ADD_RID] );;
e(REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;
 
let INDEX_FINGER_ABD_ADD_SIMP_EQS_SSM = top_thm();;


(* ------------------------------------------------------------------------- *)
(*                INDEX_FINGER (Abd. & Add.) FINAL FORM                      *)
(* ------------------------------------------------------------------------- *)



g `!(p0:real^2) (e511:real^1->real^2) e512 f512 e513 f513 e521 f522 e523 f523 e524 
    f524 e531 e532 f532 f533 e314 (Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se (t:real^1).
     (&0 < Jm_5) /\  (&0 < Ra_5) /\  (&0 < J_5) /\ 
     (e314 t = e512 t) /\ (e314 t = src_e Se t) /\ 
      (f522 t = inertance_f Jm_5 e521 p0 t) /\ 
       (f533 t =  (-- inertance_f J_5 e531 p0 t + Cx Geer_5 * (inertance_f Jm_5 e521 p0 t))) /\ 
        (e511 t =  (-- Cx Motor_5 * inertance_f Jm_5 e521 p0 t + e512 t )) /\ (f512 t = res_f Ra_5 e511 t)
 ==> bg_main (index_finger_abd_add p0 e511 e512 f512 e513 f513 e521 f522 e523 f523 e524
      f524 e531 e532 f532 f533 Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5) t =
      (index_finger_abd_add_ss_model p0 e521 e531 Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se t)`;;



e (REPEAT STRIP_TAC);;
e (MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `index_finger_abd_add_simplified_eqs p0 e511 e512 f512 e521 f522 e531 f533 
                  Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5 Se t`);;
e (CONJ_TAC);;
e (MATCH_MP_TAC INDEX_FINGER_ABD_ADD_IMP_SIMP_EQS);;
e (EXISTS_TAC ` (e314:real^1->real^2)`);;
e (ASM_REWRITE_TAC []);;

e (MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC ` (e314:real^1->real^2)(t:real^1)`);;
e (CONJ_TAC);;
e (UNDISCH_TAC ` (e314:real^1->real^2) (t:real^1) = (e512:real^1->real^2) (t:real^1)`);;
e (SIMP_TAC []);;
e (UNDISCH_TAC ` (e314:real^1->real^2) (t:real^1) = src_e (Se:real) (t:real^1)`);;
e (SIMP_TAC []);;
e (MATCH_MP_TAC INDEX_FINGER_ABD_ADD_SIMP_EQS_SSM);;
e (ASM_REWRITE_TAC []);;


let INDEX_FINGER_ABD_ADD_FINAL = top_thm();;


(* ------------------------------------------------------------------------- *)
(*                 STABILITY OF Prosthetic Hand Fingers                      *)
(* ------------------------------------------------------------------------- *)

(************************ THUMB FLEX. & EXT. ****************************)

g `!(Ra_1:real) Motor_1 Jm_1 Dm_1 Geer_1 J_1 D_1 K_1 .
   Cx (D_1 / J_1 - (--Dm_1 / Jm_1 - (Geer_1 pow 2 * D_1) / Jm_1 - Motor_1 pow 2 / (Jm_1 * Ra_1))) = Cx b1 + Cx r /\
   Cx ((Geer_1 / K_1) * Geer_1 / Jm_1 - (Geer_1 * D_1) / J_1 * (Geer_1 * D_1) / Jm_1 - &1 / K_1 * (-- &1 / J_1) +
      (--Dm_1 / Jm_1 - (Geer_1 pow 2 * D_1) / Jm_1 - Motor_1 pow 2 / (Jm_1 * Ra_1)) * (--D_1 / J_1)) = Cx c1 + Cx (b1 * r) /\
   Cx (--((Geer_1 * D_1) / J_1 * Geer_1 / Jm_1 * &1 / K_1) - (--Geer_1 / K_1) * (Geer_1 * D_1) / Jm_1 * (-- &1 / J_1) +
      (--Dm_1 / Jm_1 - (Geer_1 pow 2 * D_1) / Jm_1 - Motor_1 pow 2 / (Jm_1 * Ra_1)) * &1 / K_1 * (-- &1 / J_1) +
      (--Geer_1 / K_1) * (Geer_1 / Jm_1) * (--D_1 / J_1)) = Cx (c1 * r) /\
     (&0 < r \/
      &0 < b1 /\ (b1 pow 2 - &4 * c1 < &0 \/ b1 pow 2 - &4 * c1 = &0) \/
      &0 < b1 pow 2 - &4 * c1 /\
      (sqrt (b1 pow 2 - &4 * c1) < b1 \/ --b1 < sqrt (b1 pow 2 - &4 * c1)))
==> stable_sys (thumb_flex_ext_system_mat Ra_1 Motor_1 Jm_1 Dm_1 Geer_1 J_1 D_1 K_1)`;;

e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [thumb_flex_ext_system_mat]);;
e (MATCH_MP_TAC STABLE_MATRIX_3x3);;
e (EXISTS_TAC `(b1:real)`);; 
e (EXISTS_TAC `(c1:real)`);; 
e (EXISTS_TAC `(r:real)`);; 
e (REWRITE_TAC [REAL_ARITH `-- &0 - a = -- a`]);;
e (REWRITE_TAC [REAL_MUL_RZERO;REAL_ADD_LID;REAL_ADD_RID;REAL_SUB_LZERO]);;
e (REWRITE_TAC [REAL_ARITH `-- (-- (x:real)/ y) = x / y`]);;
e (POP_ASSUM MP_TAC);;
e (CONV_TAC REAL_FIELD);;

let THUMB_FLEX_EXT_STABILITY = top_thm();;



(************************ THUMB ABD. & ADD. ****************************)

g `!(Ra_2:real) Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2.
    &0 < --(--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) - (--D_2 / J_2) /\
         ((--(--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) - (--D_2 / J_2)) pow 2 -
    &4 * ((--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) * (--D_2 / J_2) -
         (Geer_2 * D_2) / J_2 * (Geer_2 * D_2) / Jm_2) < &0 \/
    (--(--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) - (--D_2 / J_2)) pow 2 -
    &4 * ((--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) * (--D_2 / J_2) - 
         (Geer_2 * D_2) / J_2 * (Geer_2 * D_2) / Jm_2) = &0) \/
   &0 < (--(--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) - (--D_2 / J_2)) pow 2 -
   &4 * ((--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) * (--D_2 / J_2) -
        (Geer_2 * D_2) / J_2 * (Geer_2 * D_2) / Jm_2) /\ (sqrt ((--(--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 -
         Motor_2 pow 2 / (Jm_2 * Ra_2)) - (--D_2 / J_2)) pow 2 - &4 * ((--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 -
         Motor_2 pow 2 / (Jm_2 * Ra_2)) * (--D_2 / J_2) - (Geer_2 * D_2) / J_2 * (Geer_2 * D_2) / Jm_2)) <
         --(--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) -(--D_2 / J_2) \/
         --Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2) + (--D_2 / J_2) <
  sqrt ((--(--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) - (--D_2 / J_2)) pow 2 -
   &4 * ((--Dm_2 / Jm_2 - (Geer_2 pow 2 * D_2) / Jm_2 - Motor_2 pow 2 / (Jm_2 * Ra_2)) * (--D_2 / J_2) -
         (Geer_2 * D_2) / J_2 * (Geer_2 * D_2) / Jm_2)))
==> stable_sys (thumb_abd_add_system_mat Ra_2 Motor_2 Jm_2 Dm_2 Geer_2 J_2 D_2)`;;
 
e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [thumb_abd_add_system_mat]);;
e (MATCH_MP_TAC STABLE_MATRIX_2x2);;
e (POP_ASSUM MP_TAC);;
e (CONV_TAC REAL_FIELD);;

let THUMB_ABD_ADD_STABILITY = top_thm();;



(************************ THUMB UP & DOWN ****************************)


g `!(Ra_3:real) Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3.
   &0 < --(--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) - (--D_3 / J_3) /\
        ((--(--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) - (--D_3 / J_3)) pow 2 -
  &4 * ((--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) * (--D_3 / J_3) -
        (Geer_3 * D_3) / J_3 * (Geer_3 * D_3) / Jm_3) < &0 \/
       (--(--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) - (--D_3 / J_3)) pow 2 -
  &4 * ((--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) * (--D_3 / J_3) -
       (Geer_3 * D_3) / J_3 * (Geer_3 * D_3) / Jm_3) = &0) \/
  &0 < (--(--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) -(--D_3 / J_3)) pow 2 -
  &4 * ((--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) * (--D_3 / J_3) -
       (Geer_3 * D_3) / J_3 * (Geer_3 * D_3) / Jm_3) /\ (sqrt ((--(--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 -
        Motor_3 pow 2 / (Jm_3 * Ra_3)) -( --D_3 / J_3)) pow 2 - &4 * ((--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 -
        Motor_3 pow 2 / (Jm_3 * Ra_3)) * (--D_3 / J_3) - (Geer_3 * D_3) / J_3 * (Geer_3 * D_3) / Jm_3)) <
       --(--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) - (--D_3 / J_3) \/
      (--Dm_3 / Jm_3) - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3) + (--D_3 / J_3) <
  sqrt ((--(--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) - (--D_3 / J_3)) pow 2 -
   &4 * ((--Dm_3 / Jm_3 - (Geer_3 pow 2 * D_3) / Jm_3 - Motor_3 pow 2 / (Jm_3 * Ra_3)) * (--D_3 / J_3) -
        (Geer_3 * D_3) / J_3 * (Geer_3 * D_3) / Jm_3)))   
==> stable_sys (thumb_up_down_system_mat Ra_3 Motor_3 Jm_3 Dm_3 Geer_3 J_3 D_3)`;;

e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [thumb_up_down_system_mat]);;
e (MATCH_MP_TAC STABLE_MATRIX_2x2);;
e (POP_ASSUM MP_TAC);;
e (CONV_TAC REAL_FIELD);;

let THUMB_UP_DOWN_STABILITY = top_thm();;




(********************* INDEX FINGER FLEX. & EXT. **************************)


g ` !(Ra_4:real) Motor_4 Jm_4 Dm_4 Geer_4 J_4 D_4 K_2.
   Cx (D_4 / J_4 - (--Dm_4 / Jm_4 - (Geer_4 pow 2 * D_4) / Jm_4 - Motor_4 pow 2 / (Jm_4 * Ra_4))) = Cx b1 + Cx r /\
   Cx ((Geer_4 / K_2) * Geer_4 / Jm_4 - (Geer_4 * D_4) / J_4 * (Geer_4 * D_4) / Jm_4 - &1 / K_2 * -- &1 / J_4  +
      (--Dm_4 / Jm_4 - (Geer_4 pow 2 * D_4) / Jm_4 - Motor_4 pow 2 / (Jm_4 * Ra_4)) * (--D_4 / J_4)) = Cx c1 + Cx (b1 * r) /\
   Cx (-- ((Geer_4 * D_4) / J_4 * Geer_4 / Jm_4 * &1 / K_2) - (--Geer_4 / K_2) * (Geer_4 * D_4) / Jm_4 * (-- &1 / J_4) +
      (--Dm_4 / Jm_4 - (Geer_4 pow 2 * D_4) / Jm_4 - Motor_4 pow 2 / (Jm_4 * Ra_4)) * &1 / K_2 * (-- &1 / J_4)  +
      (--Geer_4 / K_2) * Geer_4 / Jm_4 * (--D_4 / J_4)) = Cx (c1 * r) /\
  (&0 < r \/
  &0 < b1 /\ (b1 pow 2 - &4 * c1 < &0 \/ b1 pow 2 - &4 * c1 = &0) \/
  &0 < b1 pow 2 - &4 * c1 /\
  (sqrt (b1 pow 2 - &4 * c1) < b1 \/ --b1 < sqrt (b1 pow 2 - &4 * c1)))
==> stable_sys (index_finger_flex_ext_system_mat Ra_4 Motor_4 Jm_4 Dm_4 Geer_4 J_4 D_4 K_2)`;;


e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [index_finger_flex_ext_system_mat]);;
e (MATCH_MP_TAC STABLE_MATRIX_3x3);;
e (EXISTS_TAC `(b1:real)`);; 
e (EXISTS_TAC `(c1:real)`);; 
e (EXISTS_TAC `(r:real)`);; 
e (REWRITE_TAC [REAL_ARITH `-- &0 - a = -- a`]);;
e (REWRITE_TAC [REAL_MUL_RZERO;REAL_ADD_LID;REAL_ADD_RID;REAL_SUB_LZERO]);;
e (REWRITE_TAC [REAL_ARITH `-- (-- (x:real)/ y) = x / y`]);;
e (POP_ASSUM MP_TAC);;
e (CONV_TAC REAL_FIELD);;

let INDEX_FINGER_FLEX_EXT_STABILITY = top_thm();;


(********************* INDEX FINGER ABD. & ADD. **************************)

g `!(Ra_5:real) Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5.
   &0 < --(--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) - (--D_5 / J_5) /\
     ((--(--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) - (--D_5 / J_5)) pow 2 -
   &4 * ((--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) * (--D_5 / J_5) -
        (Geer_5 * D_5) / J_5 * (Geer_5 * D_5) / Jm_5) < &0 \/
     (--(--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) - (--D_5 / J_5)) pow 2 -
   &4 * ((--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) * (--D_5 / J_5) - 
        (Geer_5 * D_5) / J_5 * (Geer_5 * D_5) / Jm_5) = &0) \/
   &0 < (--(--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) - (--D_5 / J_5)) pow 2 -
   &4 * ((--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) * (--D_5 / J_5) -
        (Geer_5 * D_5) / J_5 * (Geer_5 * D_5) / Jm_5) /\ (sqrt ((--(--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 -
         Motor_5 pow 2 / (Jm_5 * Ra_5)) - (--D_5 / J_5)) pow 2 - &4 * ((--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 -
         Motor_5 pow 2 / (Jm_5 * Ra_5)) * (--D_5 / J_5) - (Geer_5 * D_5) / J_5 * (Geer_5 * D_5) / Jm_5)) <
   --(--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) - (--D_5 / J_5) \/
   --(Dm_5 / Jm_5) - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5) +
   --(D_5 / J_5) < sqrt ((--(--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) -
      (--D_5 / J_5)) pow 2 - &4 * ((--Dm_5 / Jm_5 - (Geer_5 pow 2 * D_5) / Jm_5 - Motor_5 pow 2 / (Jm_5 * Ra_5)) * (--D_5 / J_5) -
      (Geer_5 * D_5) / J_5 * (Geer_5 * D_5) / Jm_5)))
 ==> stable_sys (index_finger_abd_add_system_mat Ra_5 Motor_5 Jm_5 Dm_5 Geer_5 J_5 D_5)`;;

e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [index_finger_abd_add_system_mat]);;
e (MATCH_MP_TAC STABLE_MATRIX_2x2);;
e (POP_ASSUM MP_TAC);;
e (CONV_TAC REAL_FIELD);;

let INDEX_FINGER_ABD_ADD_STABILITY = top_thm();;

(*-------------------------------------------END-------------------------------------------------*)
