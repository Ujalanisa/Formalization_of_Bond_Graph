
(* ========================================================================= *)
(*                                                                           *)
(*                        SIMPLIFICATION TACTICS                             *)
(*                                                                           *)
(*     (c)  Ujala Qasim,                                                     *)
(*          Adnan Rashid,                                                    *)
(*          Osman Hasan                                                      *)
(* 	    SYSTEM ANALYSIS & VERIFICATION (SAVe) LAB                        *)
(*	    National University of Sciences and Technology (NUST), PAKISTAN  *)
(*   Last update: September 19, 2020                                         *)
(*                                                                           *)
(* ========================================================================= *)


(*---------------------------------------------------------------------------*)
(*                          Theories to load                                 *)
(*---------------------------------------------------------------------------*)

needs "numbers.ml";;
needs "BG Model.ml";;


(*********************************************)

let BOND_DIRECTION_TAC xs = 

REWRITE_TAC [bond_direction_cond;bond_direction;bonds_length;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN 
NUMBER_SFG_TAC1 [EL;TL;HD;snd_of_tuple] THEN REWRITE_TAC xs ;; 

(*********************************************)

let BOND_MODULUS_TAC xs =


REWRITE_TAC [modulus_cond; causality;bonds_length;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL;TL;HD] THEN
REWRITE_TAC [thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;frst_of_tuple] THEN
REWRITE_TAC [modulus;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;fifth_of_tuple] THEN REWRITE_TAC xs ;; 


(*********************************************)

let BOND_EFFORT_TAC xs =

REWRITE_TAC [bond_effort;CR;bonds_length;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;sixth_of_tuple] THEN REWRITE_TAC xs ;;


(*********************************************)

let BOND_FLOW_TAC xs =

REWRITE_TAC [bond_flow;CR;bonds_length;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;sixth_of_tuple] THEN REWRITE_TAC xs ;;


(*********************************************)

let BACKWRD_PATH_TAC xs = 

NUMBER_SFG_TAC1 [backwrd_path] THEN
REWRITE_TAC [type_of_jun; snd_last_bond_type;type_of_ele;bonds_length;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL; TL; HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;forth_of_tuple;snd_of_trpl] THEN
REWRITE_TAC [strong_bond_f;strong_bond_t;snd_last_bond_of_jun; last_bond_of_jun;bonds_length;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL; TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [causality_t;causality_f; causality; bond;bonds;jun; EL; TL; HD;thrd_of_trpl] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;frst_of_tuple;ARITH] THEN REWRITE_TAC xs ;; 


(*********************************************)

let FWRD_PATH_TAC xs = 

REWRITE_TAC [final_fwrd_path; jun_match;LENGTH; ARITH] THEN
NUMBER_SFG_TAC1 [jun_num_match; rev; REVERSE;APPEND;jun_num;jun;EL; TL; HD;frst_of_trpl;ARITH] THEN
NUMBER_SFG_TAC1 [fwrd_path; rev;REVERSE;APPEND] THEN
REWRITE_TAC [type_of_jun; last_bond_type;type_of_ele;bonds_length;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL; TL; HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;forth_of_tuple;snd_of_trpl] THEN
REWRITE_TAC [strong_bond_f;strong_bond_t;snd_last_bond_of_jun; last_bond_of_jun;bonds_length;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL; TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [causality_t;causality_f; causality; bond;bonds;jun; EL; TL; HD;thrd_of_trpl] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;frst_of_tuple;ARITH] THEN REWRITE_TAC xs ;; 


(*********************************************)

let PATHS_SELECTION_TAC xs =

REWRITE_TAC [path_selection;type_of_jun;jun] THEN
NUMBER_SFG_TAC1 [EL; TL;HD;snd_of_trpl] THEN
REWRITE_TAC [path_select_t;path_select_f;strong_bond_t;strong_bond_f;snd_last_bond_of_jun;last_bond_of_jun;bonds_length;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL; TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [causality_f;causality_t;causality;bond;bonds;jun;EL;TL;HD;thrd_of_trpl] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;frst_of_tuple;ARITH] THEN REWRITE_TAC xs ;; 


(*********************************************)

let CAUSAL_LOOP_TAC xs = 

REWRITE_TAC [causal_loop;branch;branch_num;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;thrd_of_tuple;ARITH] THEN
REWRITE_TAC [loop_jun_lst;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [loop_jun;loop_bonds_lst;bonds_length;bonds;bond;jun;EL;TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [loop_bonds;ARITH] THEN
REWRITE_TAC [loop_presence;branch;branch_num;type_of_ele;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;thrd_of_tuple;forth_of_tuple;ARITH] THEN REWRITE_TAC xs ;;


(*********************************************)

let CASE_SELECTION_TAC xs = 

REWRITE_TAC [bg_main;NOT_CONS_NIL;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [jun_selection;bond_selection_lst;bonds_length;bond;bonds;jun;EL;TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [bond_selection;case_selection;type_of_jun;type_of_ele;branch;causality;bond;bonds;jun;
EL; TL; HD;thrd_of_trpl;frst_of_tuple;thrd_of_tuple;forth_of_tuple;snd_of_trpl;ARITH] THEN 
REWRITE_TAC xs ;;


(*********************************************)

let BRANCH_TAC xs = 

REWRITE_TAC [branch_main;NOT_CONS_NIL;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [branch_jun; branch_bonds_lst;bonds_length;bonds;bond;jun;EL;TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [branch_bonds;branch_jun_recur_1_lst;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [branch_jun_recur_1;branch_bonds_recur_1_lst;bonds_length;bonds;bond;jun;EL;TL;HD;thrd_of_trpl;LENGTH;ARITH] THEN
NUMBER_SFG_TAC1 [ branch_bonds_recur_1] THEN
REWRITE_TAC [branch_presence;branch;branch_num;type_of_ele;bond;bonds;jun] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;thrd_of_tuple;ARITH] THEN
NUMBER_SFG_TAC1 [EL;TL;HD;thrd_of_trpl;thrd_of_tuple;forth_of_tuple;ARITH] THEN REWRITE_TAC xs ;;

(* ==================================================================================== *)
