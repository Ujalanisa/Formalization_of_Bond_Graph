(* ========================================================================= *)
(*                                                                           *)
(*              Formalization of Bond Graph using HOL Light                  *)
(*                                                                           *)
(*     (c)  Ujala Qasim,                                                     *)
(*          Adnan Rashid,                                                    *)
(*          Osman Hasan                                                      *) 
(* 	    SYSTEM ANALYSIS & VERIFICATION (SAVe) LAB                        *)
(*	    National University of Sciences and Technology (NUST), PAKISTAN  *)
(*   Last update: September 19, 2020                                         *)
(*                                                                           *)
(* ========================================================================= *)

(*---------------------------------------------------------------------------*)
(*                          Theories to load                                 *)
(*---------------------------------------------------------------------------*)

needs "Multivariate/realanalysis.ml";;

(*---------------------------------------------------------------------------*)
(*                           Formalization                                   *)
(*---------------------------------------------------------------------------*)

new_type_abbrev("effort",`:real^1->real^2`);;
new_type_abbrev("flow",`:real^1->real^2`);;
new_type_abbrev("causality",`: bool`);;
new_type_abbrev("direction",`: bool`);;
new_type_abbrev("mod",`: (real^2)list`);;
new_type_abbrev("branch",`: bool`);;
new_type_abbrev("ele_type",`: num`);;
new_type_abbrev("bond",`:  causality # direction # (branch # num) # ele_type # mod # (effort#flow)`);;
new_type_abbrev("bonds",`: (bond)list`);;
new_type_abbrev("jun_type",`: bool`);;
new_type_abbrev("jun_num",`: num`);;
new_type_abbrev("jun",`: jun_num # jun_type # bonds`);; 
new_type_abbrev("jun_list",`:(jun)list`);;


let frst_of_tuple = define
 `frst_of_tuple (a,b,c,d,e,f) = a`;;

let snd_of_tuple = define
 `snd_of_tuple (a,b,c,d,e,f) = b`;;

let thrd_of_tuple = define
 `thrd_of_tuple (a,b,c,d,e,f) = c`;;

let forth_of_tuple = define
 `forth_of_tuple (a,b,c,d,e,f) = d`;;

let fifth_of_tuple = define
 `fifth_of_tuple (a,b,c,d,e,f) = e`;;

let sixth_of_tuple = define
 `sixth_of_tuple (a,b,c,d,e,f) = f`;;

let frst_of_trpl = define
 `frst_of_trpl (a,b,c) = a`;;

let snd_of_trpl = define
 `snd_of_trpl (a,b,c) = b`;;

let thrd_of_trpl = define
 `thrd_of_trpl (a,b,c) = c`;;



(* ------------------------------------------------------------------------- *)
(*   Definition :  Basic Definitions                                         *)
(* ------------------------------------------------------------------------- *)

(*--------- i & k are jun and bond num respectively ---------*)

	   
let jun = define
 `  jun (j:jun_list) i = (EL i (j))`;; 


let jun_num = define
 `  jun_num (j:jun_list) i = (frst_of_trpl (jun j i))`;;


let type_of_jun = define
 `  type_of_jun (j:jun_list) i = (snd_of_trpl (jun j i))`;;


let bonds = define
 `  bonds (j:jun_list) i = (thrd_of_trpl (jun j i))`;;


let bond = define
 `  bond (j:jun_list) i k = (EL k (bonds j i))`;;


let CR = define
 `  CR (j:jun_list) i k  = (sixth_of_tuple (bond j i k))`;;


let type_of_ele = define
 `  type_of_ele (j:jun_list) i k = (forth_of_tuple (bond j i k))`;;


let causality = define
 `  causality (j:jun_list) i k  = (frst_of_tuple (bond j i k))`;;


let bond_direction = define
 `  bond_direction (j:jun_list) i k  = (snd_of_tuple (bond j i k))`;;


let bond_direction_cond = define
 `  bond_direction_cond (j:jun_list) i k  = 
    if ((bond_direction j i k) = T) then
          Cx(&1)
    else --Cx(&1)`;;


let modulus = define
 `  modulus (j:jun_list) i k  =
    (fifth_of_tuple (bond j i k))`;;


let branch = define
 `  branch (j:jun_list) i k  =
    FST (thrd_of_tuple (bond j i k))`;;


let branch_num = define
 `  branch_num (j:jun_list) i k  =
    SND (thrd_of_tuple (bond j i k))`;;


let bonds_length = define
  ` bonds_length (j:jun_list) i = 
    (LENGTH (bonds j i))`;;


(* -------------------------------------------------------------------------------- *)
(*   Definition :  Extraction of Effort and Flow of a bond with/without direction   *)
(* -------------------------------------------------------------------------------- *)

let bond_effort = define
 `  bond_effort (j:jun_list) (i:num) k (t:real^1) = 
     (FST (CR j i k) t)`;;


let bond_flow = define
 `  bond_flow (j:jun_list) (i:num) k (t:real^1) = 
    (SND (CR j i k) t)`;; 


let bond_effort_wd = define
 `  bond_effort_wd (j:jun_list) (i:num) k (t:real^1) = 
     (bond_direction_cond j i k) * (bond_effort j i k t)`;;


let bond_flow_wd = define
 `  bond_flow_wd (j:jun_list) (i:num) k (t:real^1) = 
     (bond_direction_cond j i k) * (bond_flow j i k t)`;;


(* ------------------------------------------------------------------------- *)
(*   Definition :  Junction's Equality Laws                                  *)
(* ------------------------------------------------------------------------- *)

(* ------------- k1 & k2 are two different bond num of a jun --------------- *)


let jun_1_f = define
`  jun_1_f (j:jun_list) i k1 k2 (t:real^1) = 
    (bond_flow j i k1 t) = (bond_flow j i k2 t)`;;
  
     
let jun_0_e = define
`  jun_0_e (j:jun_list) i k1 k2 (t:real^1) = 
    (bond_effort j i k1 t) = (bond_effort j i k2 t)`;;                  
  

(* ------------------------------------------------------------------------- *)
(*   Definition : Junction's Summation Laws  (Skip last two bonds of jun)    *)
(* ------------------------------------------------------------------------- *)
           
	    
let jun_0_f = define
  `jun_0_f (j:jun_list) (i:num) (t:real^1) = 
    vsum (0..((bonds_length j i) - 3))
   (\k. (bond_flow_wd j i k t))`;;


let jun_1_e = define
  `jun_1_e (j:jun_list) (i:num) (t:real^1) = 
    vsum (0..((bonds_length j i) - 3))
   (\k.(bond_effort_wd j i k t))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Strong bond Extraction                                    *)
(* ------------------------------------------------------------------------- *)


let causality_f = new_recursive_definition num_RECURSION
  `(causality_f (j:jun_list) i 0 = 0) /\
     (causality_f j i (SUC k)  =
      if ((causality j i (SUC k)) = F) then (SUC k)
	  else  (causality_f j i k)) `;;


let causality_t = new_recursive_definition num_RECURSION
  `(causality_t (j:jun_list) i 0 = 0) /\
     (causality_t j i (SUC k)  =
      if ((causality j i (SUC k)) = T) then (SUC k)
	  else (causality_t j i k)) `;;


let  strong_bond_f = define
  `  strong_bond_f (j:jun_list) i =
     (causality_f j i ((bonds_length j i) - 1))`;;


let  strong_bond_t = define
  `  strong_bond_t (j:jun_list) i =
     (causality_t j i ((bonds_length j i) - 1))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Different Bonds types                                      *)
(* ------------------------------------------------------------------------- *)


let snd_last_bond_type = define
  ` snd_last_bond_type (j:jun_list) i =
    (type_of_ele j i ((bonds_length j i) - 2))`;;


let last_bond_type = define
  ` last_bond_type (j:jun_list) i =
     (type_of_ele j i ((bonds_length j i) - 1))`;; 
 

(* ------------------------------------------------------------------------- *)
(*   Definition : Two Port Element Modulus                                   *)
(* ------------------------------------------------------------------------- *)
 

let modulus_cond = define
  ` modulus_cond (j:jun_list) i k = 
     if ((causality j i k) = T)
      then
        (EL 1 (modulus j i k))
     else
         (EL 0 (modulus j i k))`;;


let snd_last_bond_modulus_cond = define
  ` snd_last_bond_modulus_cond (j:jun_list) i = 
    (modulus_cond j i ((bonds_length j i) - 2))`;;


let last_bond_modulus_cond = define
  ` last_bond_modulus_cond (j:jun_list) i = 
    (modulus_cond j i ((bonds_length j i) - 1))`;;



(* ------------------------------------------------------------------------- *)
(*   Definition :  Direction of Bonds                                        *)
(* ------------------------------------------------------------------------- *)


let last_bond_dir = define
 `  last_bond_dir (j:jun_list) (i:num) =
      (bond_direction_cond j i ((bonds_length j i) - 1)) `;;


let snd_last_bond_dir = define
  ` snd_last_bond_dir (j:jun_list) (i:num) =
     (bond_direction_cond j i ((bonds_length j i) - 2)) `;; 


let last_bond_dir_cond = define
  ` last_bond_dir_cond (j:jun_list) (i:num) = 
     if ((bond_direction j i ((bonds_length j i) - 1)) = F) then
             Cx(&1)
     else
          -- Cx(&1)`;;


let snd_last_bond_dir_cond = define
  ` snd_last_bond_dir_cond (j:jun_list) (i:num) = 
     if ((bond_direction j i ((bonds_length j i) - 2)) = F) then
             Cx(&1)
     else
          -- Cx(&1)`;;


(* ------------------------------------------------------------------------- *)
(*   Definition :  Effort and Flow of Different Bonds                         *)
(* ------------------------------------------------------------------------- *)


let last_bond_e = define
 `  last_bond_e (j:jun_list) (i:num) (t:real^1)=
     (bond_effort j i ((bonds_length j i) - 1) t)`;;


let last_bond_f = define
 `  last_bond_f (j:jun_list) (i:num) (t:real^1) =
     (bond_flow j i ((bonds_length j i) - 1) t)`;;


let snd_last_bond_e = define
 `  snd_last_bond_e (j:jun_list) (i:num) (t:real^1) =
     (bond_effort j i ((bonds_length j i) - 2) t)`;;

let snd_last_bond_f = define
 `  snd_last_bond_f (j:jun_list) (i:num) (t:real^1) =
     (bond_flow j i ((bonds_length j i) - 2) t)`;;


let last_bond_of_jun = define
  ` last_bond_of_jun (j:jun_list) i =
    ((bonds_length j i) - 1) `;; 


let snd_last_bond_of_jun = define
  ` snd_last_bond_of_jun (j:jun_list) i =
    ((bonds_length j i) - 2) `;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Bonds of last jun following differnt path                  *)
(* ------------------------------------------------------------------------- *)


let fw_last_jun_e  = define
    `fw_last_jun_e (j:jun_list) (i:num) (t:real^1) =
      if (i = 0)  then
         (last_bond_dir j i) * (last_bond_e j i t)  
      else
	 Cx(&0)`;;


let fw_last_jun_f  = define
    `fw_last_jun_f (j:jun_list) (i:num) (t:real^1) =
      if (i = 0)  then
         (last_bond_dir j i) * (last_bond_f j i t)  
      else
	 Cx(&0)`;;


let bw_last_jun_e  = define
    `bw_last_jun_e (j:jun_list) (i:num) (t:real^1) =
      if (i = 0)  then
         (snd_last_bond_dir j i) * (snd_last_bond_e j i t)  
      else
	 Cx(&0)`;;


let bw_last_jun_f  = define
    `bw_last_jun_f (j:jun_list) (i:num) (t:real^1) =
      if (i = 0)  then
         (snd_last_bond_dir j i) * (snd_last_bond_f j i t)  
      else
	 Cx(&0)`;;



(* ------------------------------------------------------------------------- *)
(*   Definition : Summation of last jun following differnt path              *)
(* ------------------------------------------------------------------------- *)


let fw_jun_e_sum  = define
    `fw_jun_e_sum (j:jun_list) (i:num) (t:real^1) =
      ((jun_1_e j i t) + (fw_last_jun_e j i t)) `;;


let fw_jun_f_sum  = define
    `fw_jun_f_sum (j:jun_list) (i:num) (t:real^1)=
      ((jun_0_f j i t) + (fw_last_jun_f j i t)) `;;


let bw_jun_e_sum  = define
    `bw_jun_e_sum (j:jun_list) (i:num) (t:real^1)=
      ((jun_1_e j i t) + (bw_last_jun_e j i t)) `;;


let bw_jun_f_sum  = define
    `bw_jun_f_sum (j:jun_list) (i:num) (t:real^1)=
     ((jun_0_f j i t) + (bw_last_jun_f j i t)) `;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Backward Path                                              *)
(* ------------------------------------------------------------------------- *)


let backwrd_path = new_recursive_definition num_RECURSION
 ` (backwrd_path (j:jun_list) 0 t = (Cx(&0)) /\
   (backwrd_path j (SUC i) t) =
   (if  (((type_of_jun j (SUC i)) = F) /\
        (((snd_last_bond_type j (SUC i)) = 0) \/ 
        ((snd_last_bond_type j (SUC i)) = 5)) /\ 
        ((type_of_jun j i) = F))
	          \/
	(((type_of_jun j (SUC i)) = T) /\
        (((snd_last_bond_type j (SUC i)) = 0) \/ 
        ((snd_last_bond_type j (SUC i)) = 5)) /\ 
        ((type_of_jun j i) = F))
	          \/
        (((type_of_jun j (SUC i)) = T) /\
        ((snd_last_bond_type j (SUC i)) = 6) /\ 
        ((type_of_jun j i) = F))
	          \/
	(((type_of_jun j (SUC i)) = F) /\
        ((snd_last_bond_type j (SUC i)) = 6) /\ 
        ((type_of_jun j i) = F))
   then
        (if
            (((strong_bond_t j i) = (snd_last_bond_of_jun j i))
              /\ ~(i = 0))            
         then
            (last_bond_modulus_cond j i) * (backwrd_path j i t)
         else if
            (((strong_bond_t j i) = (last_bond_of_jun j i)) 
              /\ ~(i = 0)) 
         then
            (last_bond_dir_cond j i) * (last_bond_modulus_cond j i) * 
            ((bw_jun_f_sum j i t) + (backwrd_path j i t))
         else if
            (((strong_bond_t j i) = (last_bond_of_jun j i))
               /\ (i = 0))
         then
            (last_bond_dir_cond j i) * (last_bond_modulus_cond j i) *
            (bw_jun_f_sum j i t)
         else
            (last_bond_modulus_cond j i) * 
            (bond_effort j i (strong_bond_t j i) t))
   else if
        (((type_of_jun j (SUC i)) = T) /\
        ((snd_last_bond_type j (SUC i)) = 6) /\ 
        ((type_of_jun j i) = T))
	          \/
	(((type_of_jun j (SUC i)) = T) /\
        (((snd_last_bond_type j (SUC i)) = 0) \/ 
        ((snd_last_bond_type j (SUC i)) = 5)) /\ 
        ((type_of_jun j i) = T))
	          \/
        (((type_of_jun j (SUC i)) = F) /\
        (((snd_last_bond_type j (SUC i)) = 0) \/ 
        ((snd_last_bond_type j (SUC i)) = 5)) /\ 
        ((type_of_jun j i) = T))
	          \/
	(((type_of_jun j (SUC i)) = F) /\
        ((snd_last_bond_type j (SUC i)) = 6) /\ 
        ((type_of_jun j i) = T))
then
         (if (((strong_bond_f j i) = (snd_last_bond_of_jun j i))      
               /\ ~(i = 0)) 
         then
            (last_bond_modulus_cond j i) * (backwrd_path j i t)
         else if             
            (((strong_bond_f j i) = (last_bond_of_jun j i)) 
               /\ ~(i = 0)) 
         then
            (last_bond_dir_cond j i) * (last_bond_modulus_cond j i) * 
            ((bw_jun_e_sum j i t) + (backwrd_path j i t))
         else if
            (((strong_bond_f j i) = (last_bond_of_jun j i)) 
               /\ (i = 0))
         then
            (last_bond_dir_cond j i) * (last_bond_modulus_cond j i) * 
            (bw_jun_e_sum j i t)
         else
            (last_bond_modulus_cond j i) * 
            (bond_flow j i (strong_bond_f j i) t))
else 
       Cx(&0)))`;;

(* ------------------------------------------------------------------------- *)
(*   Definition : Backward Path when BG has only one jun                     *)
(* ------------------------------------------------------------------------- *)

let backwrd_path_e = define 
 `  backwrd_path_e (j:jun_list) i (t:real^1) = 
   if ((LENGTH j - 1) = 0) then
      (snd_last_bond_e j i t)
   else
      (backwrd_path j i t)`;;


let backwrd_path_f = define 
 ` backwrd_path_f (j:jun_list) i (t:real^1) = 
   if ((LENGTH j - 1) = 0) then
      (snd_last_bond_f j i t)
   else
      (backwrd_path j i t)`;;

(* ------------------------------------------------------------------------- *)
(*   Definition : Forward Path                                               *)
(* ------------------------------------------------------------------------- *)


let rev = define
 ` rev (j:jun_list) = REVERSE j `;;


let fwrd_path = new_recursive_definition num_RECURSION
 ` (fwrd_path (j:jun_list) 0 t = (Cx(&0)) /\
   (fwrd_path j (SUC i) t) =
   (if  (((type_of_jun (rev j) (SUC i)) = F) /\
        (((last_bond_type (rev j) (SUC i)) = 0) \/ 
        ((last_bond_type (rev j) (SUC i)) = 5)) /\ 
        ((type_of_jun (rev j) i) = F))  
                    \/
        (((type_of_jun (rev j) (SUC i)) = T) /\
        (((last_bond_type (rev j) (SUC i)) = 0) \/ 
        ((last_bond_type (rev j) (SUC i)) = 5)) /\ 
        ((type_of_jun (rev j) i) = F))  
                    \/
        (((type_of_jun (rev j) (SUC i)) = T) /\
        ((last_bond_type (rev j) (SUC i)) = 6) /\ 
        ((type_of_jun (rev j) i) = F))  
                    \/
        (((type_of_jun (rev j) (SUC i)) = F) /\
        ((last_bond_type (rev j) (SUC i)) = 6) /\ 
        ((type_of_jun (rev j) i) = F)) 
   then
        (if
            (((strong_bond_t (rev j) i) = 
            (last_bond_of_jun (rev j) i)) /\ ~(i = 0)) 
         then
            (snd_last_bond_modulus_cond (rev j) i) * (fwrd_path j i t)
         else if
            (((strong_bond_t (rev j) i) =
            (snd_last_bond_of_jun (rev j) i)) /\ ~(i = 0)) 
         then
            (snd_last_bond_dir_cond j i) * (snd_last_bond_modulus_cond (rev j) i) * 
            ((fw_jun_f_sum (rev j) i t) + (fwrd_path j i t))
         else if
            (((strong_bond_t (rev j) i) = 
            (snd_last_bond_of_jun (rev j) i)) /\ (i = 0))
         then
            (snd_last_bond_dir_cond j i) * (snd_last_bond_modulus_cond (rev j) i) * 
            (fw_jun_f_sum (rev j) i t)
         else
            (snd_last_bond_modulus_cond (rev j) i) * 
            (bond_effort (rev j) i (strong_bond_t (rev j) i) t))
  else if  
           (((type_of_jun (rev j) (SUC i)) = T) /\
           ((last_bond_type (rev j) (SUC i)) = 6) /\
           ((type_of_jun (rev j) i) = T)) 
                     \/
           (((type_of_jun (rev j) (SUC i)) = T) /\
           (((last_bond_type (rev j) (SUC i)) = 0) \/ 
           ((last_bond_type (rev j) (SUC i)) = 5)) /\ 
           ((type_of_jun (rev j) i) = T))  
                    \/
           (((type_of_jun (rev j) (SUC i)) = F) /\
           (((last_bond_type (rev j) (SUC i)) = 0) \/ 
           ((last_bond_type (rev j) (SUC i)) = 5)) /\ 
           ((type_of_jun (rev j) i) = T))  
                    \/
           (((type_of_jun (rev j) (SUC i)) = F) /\
           ((last_bond_type (rev j) (SUC i)) = 6) /\ 
           ((type_of_jun (rev j) i) = T))
    then
         (if (((strong_bond_f (rev j) i) = 
         (last_bond_of_jun (rev j) i)) /\ ~(i = 0)) 
         then
            (snd_last_bond_modulus_cond (rev j) i) * (fwrd_path j i t)
         else if             
            (((strong_bond_f (rev j) i) = 
            (snd_last_bond_of_jun (rev j) i)) /\ ~(i = 0)) 
         then
            (snd_last_bond_dir_cond j i) * (snd_last_bond_modulus_cond (rev j) i) * 
            ((fw_jun_e_sum (rev j) i t) + (fwrd_path j i t))
         else if
            (((strong_bond_f (rev j) i) = 
            (snd_last_bond_of_jun (rev j) i)) /\ (i = 0))
         then
            (snd_last_bond_dir_cond j i) * (snd_last_bond_modulus_cond (rev j) i) * 
            (fw_jun_e_sum (rev j) i t)
         else
            (snd_last_bond_modulus_cond (rev j) i) * 
            (bond_flow (rev j) i (strong_bond_f (rev j) i) t))
 else 
     Cx(&0)))`;; 

(* ------------------------------------------------------------------------- *)
(*   Definition : Matching jun number with its actual num                    *)
(* ------------------------------------------------------------------------- *)

(* --------- n is the num of reversed jun --------- *)


let jun_num_match = define
 ` (jun_num_match (j:jun_list) 0 i = (jun_num (rev j) 0)) /\
   (jun_num_match j (SUC n) i = 
   if (i = (jun_num (rev j) (SUC n))) then (SUC n) 
   else  
    (jun_num_match j n i))`;;


let jun_match = define
 ` jun_match (j:jun_list) i = (jun_num_match j ((LENGTH j) - 1) i)`;;


let final_fwrd_path = define 
 ` final_fwrd_path (j:jun_list) i (t:real^1) = (fwrd_path j (jun_match j i) t)`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Forward Path when BG has only one jun                      *)
(* ------------------------------------------------------------------------- *)


let final_fwrd_path_e = define 
 ` final_fwrd_path_e (j:jun_list) i (t:real^1) = 
   if ((LENGTH j - 1) = 0) then
      (last_bond_e j i t)
   else
      (final_fwrd_path j i t)`;;


let final_fwrd_path_f = define 
 ` final_fwrd_path_f (j:jun_list) i (t:real^1) = 
   if ((LENGTH j - 1) = 0) then
      (last_bond_f j i t)
   else
      (final_fwrd_path j i t)`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Path Selection based on junction position/number           *)
(* ------------------------------------------------------------------------- *)


let causal_paths = define
 `  causal_paths (j:jun_list) (i:num) (t:real^1) = 
     (last_bond_dir j i) * (final_fwrd_path j i t) + 
     (snd_last_bond_dir j i) * (backwrd_path j i t) `;;
 

let search_path_e = define
  ` search_path_e (j:jun_list) (i:num) (t:real^1)= 
    if (i = 0)  then
       (snd_last_bond_dir j i) * (snd_last_bond_e j i t) +
       (last_bond_dir j i) * (final_fwrd_path_e j i t)
    else if (i = ((LENGTH j) - 1)) then
            (last_bond_dir j i) * (last_bond_e j i t) +
            (snd_last_bond_dir j i) * (backwrd_path_e j i t)
    else
              Cx(&0)`;;


let search_path_f = define
  ` search_path_f (j:jun_list) (i:num) (t:real^1) = 
    if (i = 0)  then
       (snd_last_bond_dir j i) * (snd_last_bond_f j i t) +
       (last_bond_dir j i) * (final_fwrd_path_f j i t)
    else if (i = ((LENGTH j) - 1)) then
            (last_bond_dir j i) * (last_bond_f j i t) + 
            (snd_last_bond_dir j i) * (backwrd_path_f j i t)
    else
              Cx(&0)`;;


(* ------------------------------------------------------------------------- *)
(* Definition : Path Selection based on integral causality                   *)
(* ------------------------------------------------------------------------- *)


let path_select_t = define
    `path_select_t (j: jun_list) (i:num) (t:real^1) =
      if ((strong_bond_t j i) = (last_bond_of_jun j i)) /\
         ~(i= ((LENGTH j) - 1)) 
        then
           (final_fwrd_path j i t)
      else if ((strong_bond_t j i) = (snd_last_bond_of_jun j i))
                /\ ~(i=0) 
        then
	   (backwrd_path j i t)
      else
         (bond_effort j i (strong_bond_t j i) t)`;;


let path_select_f = define
    `path_select_f (j: jun_list) (i:num) (t:real^1) =
      if ((strong_bond_f j i) = (last_bond_of_jun j i)) /\
          ~(i= ((LENGTH j) - 1)) 
        then
          (final_fwrd_path j i t)
      else if ((strong_bond_f j i) = (snd_last_bond_of_jun j i))
                /\ ~(i=0) 
        then
	   (backwrd_path j i t)
      else
          (bond_flow j i (strong_bond_f j i) t)`;;


let path_selection = define
  ` path_selection (j:jun_list) (i:num) k (t:real^1) = 
     if ((type_of_jun j i) = F) then
          ((bond_effort j i k t) = (path_select_t j i t))
     else
          ((bond_flow j i k t) = (path_select_f j i t))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Path Selection based on differential causality             *)
(* ------------------------------------------------------------------------- *)


let path_selection_der = define
  ` path_selection_der (j:jun_list) (i:num) k (t:real^1) = 
     if ((type_of_jun j i) = F) then
        ((\t.vector_derivative (bond_effort j i k) (at t)) =    
        (\t.vector_derivative (path_select_t j i) (at t)))
     else
        ((\t.vector_derivative (bond_flow j i k) (at t)) = 
        (\t.vector_derivative (path_select_f j i) (at t)))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Summation of a junction based on its position              *)
(* ------------------------------------------------------------------------- *)


let middle_jun_sum = define
  ` middle_jun_sum (j:jun_list) (i:num) (t:real^1) = 
     if ((type_of_jun j i) = T) then
          (jun_1_e j i t) +  (causal_paths j i t)
     else
          (jun_0_f j i t) +  (causal_paths j i t)`;; 


let side_jun_sum = define
  ` side_jun_sum (j:jun_list) (i:num) (t:real^1) = 
     if ((type_of_jun j i) = T) then
          (jun_1_e j i t)  + (search_path_e j i t)
     else
          (jun_0_f j i t)  + (search_path_f j i t)`;; 


let jun_sum = define
  ` jun_sum (j:jun_list) (i:num) (t:real^1) = 
    if (i = 0) \/ (i = ((LENGTH j) - 1)) then
         (side_jun_sum j i t)  
    else
         (middle_jun_sum j i t) `;;


let jun_sum_final = define
 ` jun_sum_final (j:jun_list)(i: num) (t:real^1) =
    ( (jun_sum j i t) = Cx(&0))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Summation of a junction based on differential causality    *)
(* ------------------------------------------------------------------------- *)


let jun_sum_der = define
 `jun_sum_der (j:jun_list)(i: num) (t:real^1) =
    ((\t.vector_derivative (jun_sum j i) (at t)) =
    (\t.vector_derivative (\t.vec 0) (at t)))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Path Selection based on Free causality                    *)
(* ------------------------------------------------------------------------- *)


let res_path_selection = define
  ` res_path_selection (j:jun_list) (i:num) k (t:real^1) = 
     if   ((causality j i k) = F) then
      (if  ((type_of_jun j i) = F)  then
          ((bond_effort j i k t) = (path_select_t j i t))
       else
          (jun_sum_final j i t))
     else
        (if   ((type_of_jun j i) = F)  then
              (jun_sum_final j i t)
         else
              ((bond_flow j i k t) = (path_select_f j i t)))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Branch in the form of Causal Loop within same jun_list     *)
(* ------------------------------------------------------------------------- *)

(* ----i k are jun num and bond num respectively 
       while i1 and n are jun num & bond num other than i & k ---- *)


let loop_presence = define
 `  loop_presence (j:jun_list) (i:num) k i1 n (t:real^1) = 
    if    ((branch j i1 n) = T) then
       if    ((branch_num j i k) = (branch_num j i1 n))  then 
         (if ((type_of_ele j i1 n) = 6) then    
             (((bond_effort j i k t) = ((EL 1 (modulus j i1 n)) * (bond_flow j i1 n t))) /\
                    ((bond_flow j i k t) = ((EL 0 (modulus j i1 n)) * (bond_effort j i1 n t))))
          else 
             (((bond_effort j i k t) = ((EL 0 (modulus j i1 n)) * (bond_effort j i1 n t))) /\
                    ((bond_flow j i k t) = ((EL 1 (modulus j i1 n)) * (bond_flow j i1 n t)))))
      else F
    else F`;; 



let loop_bonds = new_recursive_definition num_RECURSION
    ` (loop_bonds (j:jun_list) i k i1 0 (t:real^1) = 
       (if (0 = k) then F else (loop_presence j i k i1 0 t))) /\
        (loop_bonds j i k i1 (SUC n) t = 
         (if ((SUC n) = k) then F else
          ((loop_presence j i k i1 (SUC n) t) \/ (loop_bonds j i k i1 n t))))`;;



let loop_bonds_lst = define
 `  loop_bonds_lst (j:jun_list) (i:num) k i1 (t:real^1) = 
     (loop_bonds j i k i1 ((bonds_length j i1) - 1) t)`;;



let loop_jun = new_recursive_definition num_RECURSION
    ` (loop_jun (j:jun_list) i k 0 (t:real^1) = (loop_bonds_lst j i k 0 t)) /\
       (loop_jun j i k (SUC i1) t = 
        ((loop_bonds_lst j i k (SUC i1) t) \/ (loop_jun j i k i1 t)))`;;


let loop_jun_lst = define
 `  loop_jun_lst (j:jun_list) (i:num) k (t:real^1) = 
     (loop_jun j i k (LENGTH j - 1) t)`;;



let causal_loop = define
   `causal_loop (j:jun_list) (i:num) k (t:real^1) = 
    if (((branch j i k) = T) /\ 
       ~ ((branch_num j i k) = 0))
     then
        (loop_jun_lst j i k t)
    else F`;;



(*------------------ Cases for elements of a junction -----------------------*)

(* ------------------------------------------------------------------------- *)
(*   Definition : Case (Energy Storing Element is present)                   *)
(* ------------------------------------------------------------------------- *)


let frst_ordr_ele_a = define
 `   frst_ordr_ele_a (j:jun_list) (i:num) (t:real^1) =
      (jun_sum_final j i t)`;;


let frst_ordr_ele_b = define
  `  frst_ordr_ele_b (j:jun_list) (i:num) k (t:real^1) = 
      (path_selection j i k t)`;; 

(* ------------------------------------------------------------------------- *)
(*   Definition : Case  (Resistive Element)                                  *)
(* ------------------------------------------------------------------------- *)


let zero_ordr_ele = define
   ` zero_ordr_ele (j:jun_list) (i:num) k (t:real^1) = 
      (res_path_selection j i k t)`;;

(* ------------------------------------------------------------------------- *)
(*   Definition : Case  (Differential Causality)                           *)
(* ------------------------------------------------------------------------- *)   


let diff_causal_ele_a = define
 `  diff_causal_ele_a (j:jun_list) (i: num) (t:real^1) =
     (jun_sum_der j i t) `;;  


let diff_causal_ele_b = define
 `  diff_causal_ele_b (j:jun_list) (i: num) k (t:real^1) =
    (path_selection_der j i k t)`;;

(* ------------------------------------------------------------------------- *)
(*   Definition : Case (When branch is present on any bond of any jun)       *)
(* ------------------------------------------------------------------------- *)


let branch_type_a = define
 `  branch_type_a (j:jun_list) (i:num) k (t:real^1) =
      ((jun_sum_final j i t) \/ (causal_loop j i k t))`;;


let branch_type_b = define
   `branch_type_b (j:jun_list) (i:num) k (t:real^1) = 
       ((path_selection j i k t) \/ (causal_loop j i k t))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Case Selection of all bonds on a junction                  *)
(* ------------------------------------------------------------------------- *)


let case_selection = define
   `(case_selection (j:jun_list) (i:num)(k:num)(t:real^1) =
      if ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 2) /\ 
         ((causality j i k) = F)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 3) /\
         ((causality j i k) = T))) 
      then
         (frst_ordr_ele_a j i t)
      else if
         ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 3) /\
         ((causality j i k) = T)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 2) /\
         ((causality j i k) = F))) 
      then
         (frst_ordr_ele_b j i k t)
      else if
         ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 4) /\
         ((causality j i k) = T)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 4) /\
         ((causality j i k) = F)) \/
	 (((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 4) /\
         ((causality j i k) = F)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 4) /\
         ((causality j i k) = T)))
       then
           (zero_ordr_ele j i k t)
       else if
         ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 3) /\
         ((causality j i k) = F)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 2)) /\
         ((causality j i k) = T))
       then
           (diff_causal_ele_a j i t)
       else if  
         ((((type_of_jun j i) = T) /\
         ((type_of_ele j i k) = 2) /\
         ((causality j i k) = T)) \/
	 (((type_of_jun j i) = F) /\
         ((type_of_ele j i k) = 3) /\
         ((causality j i k) = F)))
       then
           (diff_causal_ele_b j i k t)
	else if
	 (((((type_of_jun j i) = T) /\
         ((branch j i k) = T) /\ 
         ((causality j i k) = F)) /\
	 (((type_of_ele j i k) = 0) \/
         ((type_of_ele j i k) = 5) \/ 
         ((type_of_ele j i k) = 6))) \/
	 ((((type_of_jun j i) = F) /\
         ((branch j i k) = T) /\
         ((causality j i k) = T)) /\
	 (((type_of_ele j i k) = 0) \/
         ((type_of_ele j i k) = 5) \/ 
         ((type_of_ele j i k) = 6)))) 
      then
          (branch_type_a j i k t)
      else if
         (((((type_of_jun j i) = T) /\
         ((branch j i k) = T) /\ 
         ((causality j i k) = T)) /\
         (((type_of_ele j i k) = 0) \/
         ((type_of_ele j i k) = 5) \/ 
         ((type_of_ele j i k) = 6))) \/
	 ((((type_of_jun j i) = F) /\
         ((branch j i k) = T) /\
         ((causality j i k) = F)) /\
	 (((type_of_ele j i k) = 0) \/
         ((type_of_ele j i k) = 5) \/ 
         ((type_of_ele j i k) = 6)))) 
      then
          (branch_type_b j i k t)
      else if
         ((type_of_ele j i k) = 0) \/
         ((type_of_ele j i k) = 1) \/
         ((type_of_ele j i k) = 5) \/ 
         ((type_of_ele j i k) = 6)
      then T
      else F)`;;

(* ------------------------------------------------------------------------- *)
(*   Definition : Recursive Function for cases of a Jun                      *)
(* ------------------------------------------------------------------------- *)


let bond_selection = new_recursive_definition num_RECURSION
  `(bond_selection (j:jun_list) (i:num) 0 (t:real^1)  =
    (case_selection j i 0 t)) /\
     (bond_selection j i (SUC k) t =
      ((case_selection j i (SUC k) t) /\
             (bond_selection j i k t)))`;;


let bond_selection_lst  = define
    `bond_selection_lst (j:jun_list) (i:num) (t:real^1) =
     (bond_selection j i ((bonds_length j i) - 1) t)`;; 


(* ------------------------------------------------------------------------- *)
(*   Definition : Recursive Function on all junctions                        *)
(* ------------------------------------------------------------------------- *)


let jun_selection = new_recursive_definition num_RECURSION
 ` (jun_selection (j:jun_list) 0 (t:real^1) =
   (bond_selection_lst j 0 t)) /\
   (jun_selection j (SUC i) t =
    ((bond_selection_lst j (SUC i) t) /\
           (jun_selection j i t)))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : Final Definition of BG                                     *)
(* ------------------------------------------------------------------------- *)

let bg_main = define
 `  bg_main (j:jun_list) (t:real^1) = (if (j = []) then F else
     (jun_selection j ((LENGTH j) - 1) t))`;;

(* ------------------------------------------------------------------------- *)
(*   Definition : Combining two different list of juns                       *)
(* ------------------------------------------------------------------------- *)

(*--------------- j is parent jun_list while j1 is child --------------------*)


let branch_presence = define
 `  branch_presence (j:jun_list) (j1:jun_list) (p:num) q p1 q1 (t:real^1) = 
    (if (((branch j p q) = T) /\ ((branch j1 p1 q1) = T)) then
      (if ((branch_num j p q) = (branch_num j1 p1 q1))  then 
        (if ((type_of_ele j1 p1 q1) = 6) then    
          (((bond_effort j p q t) = ((EL 1 (modulus j1 p1 q1)) * (bond_flow j1 p1 q1 t))) /\
                 ((bond_flow j p q t) = ((EL 0 (modulus j1 p1 q1)) * (bond_effort j1 p1 q1 t))))
        else 
          (((bond_effort j p q t) = ((EL 0 (modulus j1 p1 q1)) * (bond_effort j1 p1 q1 t))) /\
                 ((bond_flow j p q t) = ((EL 1 (modulus j1 p1 q1)) * (bond_flow j1 p1 q1 t)))))
      else F)
    else F)`;;


let branch_bonds_recur_1 = new_recursive_definition num_RECURSION
   ` (branch_bonds_recur_1 (j:jun_list) j1 (p:num) q p1 0 (t:real^1) = 
      (branch_presence j j1 p q p1 0 t)) /\
       (branch_bonds_recur_1 j j1 p q p1 (SUC q1) t = 
        ((branch_presence j j1 p q p1 (SUC q1) t) \/
               (branch_bonds_recur_1 j j1 p q p1 q1 t)))`;;


let branch_bonds_recur_1_lst = define
 `  branch_bonds_recur_1_lst (j:jun_list) j1 (p:num) q p1 (t:real^1) = 
      (branch_bonds_recur_1 j j1 p q p1 ((bonds_length j1 p1) - 1) t)`;;


let branch_jun_recur_1 = new_recursive_definition num_RECURSION
   ` (branch_jun_recur_1 (j:jun_list) j1 (p:num) q 0 (t:real^1) = 
      (branch_bonds_recur_1_lst j j1 p q 0 t)) /\
       (branch_jun_recur_1 j j1 p q (SUC p1) t = 
        ( (branch_bonds_recur_1_lst j j1 p q (SUC p1) t) \/
                (branch_jun_recur_1 j j1 p q p1 t)))`;;


let branch_jun_recur_1_lst = define
 `  branch_jun_recur_1_lst (j:jun_list) j1 (p:num) q (t:real^1) = 
     (branch_jun_recur_1 j j1 p q (LENGTH j1 - 1) t)`;;


let branch_bonds = new_recursive_definition num_RECURSION
   ` (branch_bonds (j:jun_list) j1 (p:num) 0 (t:real^1) = 
      (branch_jun_recur_1_lst j j1 p 0 t)) /\
       (branch_bonds j j1 p (SUC q) t = 
        ((branch_jun_recur_1_lst j j1 p (SUC q) t) \/
                (branch_bonds j j1 p q t)))`;;


let branch_bonds_lst = define
 `  branch_bonds_lst (j:jun_list) j1 (p:num) (t:real^1) = 
     (branch_bonds j j1 p ((bonds_length j p) - 1) t)`;;


let branch_jun = new_recursive_definition num_RECURSION
   ` (branch_jun (j:jun_list) j1 0 (t:real^1) = 
      (branch_bonds_lst j j1 0 t)) /\
       (branch_jun j j1 (SUC p) t = 
        ( (branch_bonds_lst j j1 (SUC p) t)  \/
                (branch_jun j j1 p t)))`;;


let branch_main = define
 `  branch_main (j:jun_list) j1 (t:real^1) = 
    (if ((j = []) \/ (j1 = [])) then F else
     (branch_jun j j1 (LENGTH j - 1) t))`;;


(* ------------------------------------------------------------------------- *)
(*   Definition : State Space Representation                                 *)
(* ------------------------------------------------------------------------- *)

(*------------------- REQUIRED LIBRARIES ------------------------*)

needs "cmatrix_theory.ml";;

(*****************************************************************)

let ss_model = define
  `ss_model (A:(complex)^N^N) (B:(complex)^P^N)
     (x:(complex)^N) (x_der:(complex)^N) (u:(complex)^P) = 
      (x_der = (A ** x + B ** u)) `;;

(* ========================================================================= *)
