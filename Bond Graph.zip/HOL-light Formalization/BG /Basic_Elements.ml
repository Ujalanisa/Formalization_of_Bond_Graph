
(* ========================================================================= *)
(*                                                                           *)
(*                         Elements of Bond Graph                            *)
(*                                                                           *)
(*     (c)  Ujala Qasim,                                                     *)
(*          Adnan Rashid,                                                    *)
(*          Osman Hasan                                                      *)                                                  
(* 	    SYSTEM ANALYSIS & VERIFICATION (SAVe) LAB                        *)
(*	    National University of Sciences and Technology (NUST), PAKISTAN  *)
(*   Last update: July 13, 2020                                              *)
(*                                                                           *)
(* ========================================================================= *)



let power = define 
` !(e:real^1->real^2) (f:real^1->real^2). power e f =
   (\t.e(t) * f(t))`;;

let momentum = define
 `!(e:real^1->real^2) (p0:real^2). momentum e p0 =
   (\t.p0 + integral (interval[lift(&0) , t]) e)`;;


let momentum_der = define
 `!(e:real^1->real^2) (p0:real^2). momentum_der e p0 =
   (\t.vector_derivative (momentum e p0) (at t))`;;


let displacement = define
 `!(f:real^1->real^2) (q0:real^2). displacement f q0 = 
 (\t.q0 + integral (interval [lift (&0) , t]) f)`;;


let displacement_der = define
 `!(f:real^1->real^2) (q0:real^2). displacement_der f q0 = 
 (\t.vector_derivative (displacement f q0) (at t))`;;


let src_e = define
 `!(Se:real). src_e Se = (\t. Cx(Se))`;;


let src_f = define
 `!(Sf:real). src_f Sf = (\t. Cx(Sf))`;;


let res_e = define
 `!(R:real) (f:real^1->real^2). res_e R f = 
   (\t.Cx(R) * f(t))`;;

let res_f = define
 `!(R:real) (e:real^1->real^2). res_f R e = 
   (\t. Cx(&1 / R) * e(t))`;;


let compliance_e = define
 `!(C:real) (f:real^1->real^2) (q0:real^2). compliance_e C f q0 = 
   (\t.Cx(&1 / C) * displacement f q0 t)`;;

   
let compliance_f = define
 `!(C:real) (e:real^1->real^2). compliance_f C e = 
   (\t.Cx(C) * (vector_derivative e (at t)))`;;
   

let inertance_f = define
 `!(e:real^1->real^2) (L:real) (p0:real^2). inertance_f L e p0= 
  (\t.Cx(&1 / L) * momentum e p0 t)`;;


let inertance_e = define
 `!(L:real) (f:real^1->real^2).inertance_e L f = 
   (\t.Cx(L) * (vector_derivative f (at t)))`;;

(* ========================================================================= *)
