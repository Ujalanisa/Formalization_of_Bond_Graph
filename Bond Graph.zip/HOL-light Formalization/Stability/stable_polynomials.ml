
(* ========================================================================= *)
(*                                                                           *)
(*                    STABLE POLYNOMIAL AND MATRICES                         *)
(*                                                                           *)
(*     (c)  Ujala Qasim                                                      *)
(* 	    SYSTEM ANALYSIS & VERIFICATION (SAVe) LAB                        *)
(*	    National University of Sciences and Technology (NUST), PAKISTAN  *)
(*   Last update: September 22, 2020                                         *)
(*                                                                           *)
(* ========================================================================= *)


(*---------------------------------------------------------------------------*)
(*                          Theories to load                                 *)
(*---------------------------------------------------------------------------*)

needs "polynomials.ml" 
needs "cmatrix_theory.ml"

(*--------------DENOM_LT_LDIV_0---------------------*)
g ` ! (x:real)(y:real)(z:real).
	((y < &0)) ==> ((z < x / y) = (x < z * y))`;;

e (REPEAT GEN_TAC);;
e (STRIP_TAC);;

(*--e (RW_TAC real_ss[REAL_LT_RDIV_EQ]);---*)
 e (SUBGOAL_THEN `(y = -- (abs y))` ASSUME_TAC);;
 e (SUBGOAL_THEN `~(&0 <= y)` ASSUME_TAC);;
e (REWRITE_TAC [REAL_NOT_LE]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (REWRITE_TAC [real_abs]);;
e (COND_CASES_TAC);;
e (ASM_MESON_TAC []);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
 e (SUBGOAL_THEN `~(abs y = &0)` ASSUME_TAC);;
e (MATCH_MP_TAC REAL_LT_IMP_NZ);;
e (UNDISCH_TAC `y = --abs y`);;
e (SIMP_TAC [GSYM REAL_LNEG_UNIQ]);;
e (ONCE_REWRITE_TAC [REAL_ADD_SYM]);;
e (SIMP_TAC [REAL_LNEG_UNIQ]);;
e (DISCH_TAC);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = -- &0`] );;
e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ASM_MESON_TAC []);;

 e (SUBGOAL_THEN `( &0 < abs y )` ASSUME_TAC);;
e (UNDISCH_TAC `y = --abs y`);;
e (SIMP_TAC [GSYM REAL_LNEG_UNIQ]);;
e (ONCE_REWRITE_TAC [REAL_ADD_SYM]);;
e (SIMP_TAC [REAL_LNEG_UNIQ]);;
e (DISCH_TAC);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = -- &0`] );;
e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ASM_MESON_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [real_div]);;
e (ONCE_REWRITE_TAC [REAL_INV_NEG]);;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_RMUL]);;
e (ONCE_REWRITE_TAC [REAL_NEG_LMUL]);;
e (ONCE_REWRITE_TAC [REAL_MUL_SYM]);;


e (ONCE_REWRITE_TAC [GSYM REAL_LT_NEG2]);;

e (ONCE_REWRITE_TAC [GSYM REAL_NEG_RMUL]);;

e (SIMP_TAC [REAL_NEG_NEG]);;
e (SUBGOAL_THEN ` (inv (abs y) * x < --z ) = (abs y * z < --x)` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [REAL_ARITH `inv (abs y) * x = x * inv (abs y)`]);;
e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` (abs y) * --z = --z *  (abs y)`]);;
e (ONCE_REWRITE_TAC [REAL_ARITH `(abs y * z < --x) = (x < --z * abs y )`]);;
e (MATCH_MP_TAC REAL_LT_LDIV_EQ);;
e (ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC []);;

let DENOM_LT_LDIV_0 = top_thm();;


 (*==========================================================*)
   (*******************REAL ROOT CASES**************************)
   (***************For x = -b + sqrt (x)/ 2 a*******************)
   (*==========================================================*)

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 1-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ sqrt (b pow 2 - &4 * a * c) < b-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

g ` !(a:real) (b:real) (c:real). 
  ~(Cx(&0) = Cx(a)) /\
  ((&0) < (b pow 2 - &4 * a * c)) /\ 
  (sqrt (b pow 2 - &4 * a * c) < b) /\ 
  (&0 < a)  ==> 
  ~(!x. Cx(a)* x pow 2 + Cx(b) * x + Cx(c) = Cx(&0) /\ Re x < &0 <=> x IN {} )`;;

e (REPEAT GEN_TAC);;
    e (STRIP_TAC);;
e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)
e (SIMP_TAC [GSYM CX_MUL]);;
e (SIMP_TAC [CX_INJ]);;
 e (SUBGOAL_THEN `&0 < &2*a ` ASSUME_TAC);;
e (MATCH_MP_TAC REAL_LT_MUL);;
e (ASM_REWRITE_TAC []);;
e (REAL_ARITH_TAC);;


e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `	((&0)) = ((&0) * inv (&2 * a)) 
     		       `]);;


e (SUBGOAL_THEN `(--b + sqrt (b pow 2 - &4 * a * c)) * inv (&2 * a) < &0 * inv (&2 * a) ` ASSUME_TAC);;	
e (MATCH_MP_TAC REAL_LT_RMUL);;	   
e (CONJ_TAC);;  
r(1);;
e (MATCH_MP_TAC REAL_INV_POS);;	   
e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `(--b + sqrt (b pow 2 - &4 * a * c)) * inv (&2 * a) < &0 * inv (&2 * a)`);;
e (SIMP_TAC []);;
e (ASM_REWRITE_TAC [NOT_IN_EMPTY]);;
e (ONCE_REWRITE_TAC [REAL_FIELD `(--b + sqrt (b pow 2 - &4 * a * c) < &0) = (sqrt (b pow 2 - &4 * a * c) < b)`]);;
e (ASM_SIMP_TAC []);;


let QUAD_REAL_CASE_ONE = top_thm();;



(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 2-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*a < 0  /\ b < sqrt (b pow 2 - &4 * a * c)-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 


g ` !(a:real) (b:real) (c:real). 
   ~(Cx(&0) = Cx(a)) /\  
    (&0 < (b pow 2 - &4 * a * c)) /\ 
    (b < sqrt (b pow 2 - &4 * a * c)) /\ 
    (a < &0)  ==>
    ~(!x. Cx(a)* x pow 2 + Cx(b) * x + Cx(c) = Cx(&0) /\ Re x < &0 <=> x IN {} )`;;



 e (REPEAT GEN_TAC);;
    e (STRIP_TAC);;
    e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)

	   



 e (SUBGOAL_THEN `(&2 * a) < &0 ` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&2 * a < &0`);;
e (REWRITE_TAC[GSYM real_div]);;

e (SIMP_TAC [DENOM_LT_0]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(&2 * a) * &0 = &0	  
     		       `]);;

e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 < --(a:real) + b) = (&0 < b + --a) `]);;

e (REWRITE_TAC[GSYM REAL_LT_SUB_RADD]);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 - --(a:real) =  a)`]);;


e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

let QUAD_REAL_CASE_TWO = top_thm();;




(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 3-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < b/a  /\ (b pow 2 - &4 * a * c) = 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 

g ` !(a:real) (b:real) (c:real). 
 ~(Cx(&0) = Cx(a))  /\ 
  ((b pow 2 - &4 * a * c) = &0) /\
  (&0 < b / a)  ==> 
  ~(!x. Cx(a)* x pow 2 + Cx(b) * x + Cx(c) = Cx(&0) /\ Re x < &0 <=> x IN {} )`;;


 e (REPEAT GEN_TAC);;
    e (STRIP_TAC);;
    e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;

e (UNDISCH_TAC `b pow 2 - &4 * a * c = &0`);;
e (SIMP_TAC []);;

e (SIMP_TAC [CSQRT_0]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (Cx(&0) *(a:complex) = Cx(&0)  )`]);;

e (REWRITE_TAC[RE_CX]);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real)  + &0 = --b * c  )`]);;


 e (SUBGOAL_THEN `--b * inv (&2 * a) < &0` ASSUME_TAC);;


e (REWRITE_TAC[REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real) * d = (--b * d) * c  )`]);;

 e (SUBGOAL_THEN `&0 < inv (&2 )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;


e (UNDISCH_TAC `&0 < inv (&2)`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;

e (DISCH_TAC);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (&0 / (c:real) = &0  )`]);;
e (REWRITE_TAC[GSYM REAL_NEG_LMUL]);;

e (REWRITE_TAC[REAL_NEG_LT0]);;
e (ASM_MESON_TAC [real_div]);;
e (REWRITE_TAC[GSYM CX_ADD]);;

e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--(a:real)*b + &0 = --a*b   )`]);;
e (DISCH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

let QUAD_REAL_CASE_THREE = top_thm();;


   (*==========================================================*)
   (*******************REAL ROOT CASES**************************)
   (***************For x = -b - sqrt (x)/ 2 a*******************)
   (*==========================================================*)

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 4-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ sqrt (b pow 2 - &4 * a * c) < --b*-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


g ` !(a:real) (b:real) (c:real). 
  ~(Cx(&0) = Cx(a)) /\
   (&0 < (b pow 2 - &4 * a * c)) /\ 
   (sqrt (b pow 2 - &4 * a * c) < --b ) /\ 
   (a < &0)  ==> 
 ~(!x. Cx(a)* x pow 2 + Cx(b) * x + Cx(c) = Cx(&0) /\ Re x < &0 <=> x IN {} )`;;

 e (REPEAT GEN_TAC);;
    e (STRIP_TAC);;
    e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)

	   



 e (SUBGOAL_THEN `(&2 * a) < &0 ` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&2 * a < &0`);;
e (REWRITE_TAC[GSYM real_div]);;

e (ASM_SIMP_TAC [DENOM_LT_0]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(&2 * a) * &0 = &0	  
     		       `]);;

e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 < --(a:real) - b) = (b < --a ) `]);;

e (REWRITE_TAC[GSYM REAL_LT_SUB_RADD]);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 - --(a:real) =  a)`]);;


e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

let QUAD_REAL_CASE_FOUR  = top_thm();;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 5-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ --b < (b pow 2 - &4 * a * c) **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


g ` !(a:real) (b:real) (c:real). 
  ~(Cx(&0) = Cx(a)) /\
   ((&0) < (b pow 2 - &4 * a * c)) /\
   (--b < sqrt (b pow 2 - &4 * a * c) ) /\
   (&0 < a)  ==> 
   ~(!x. Cx(a)* x pow 2 + Cx(b) * x + Cx(c) = Cx(&0) /\ Re x < &0 <=> x IN {} )`;;

 e (REPEAT GEN_TAC);;
    e (STRIP_TAC);;
    e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)
e (SIMP_TAC [GSYM CX_MUL]);;
e (SIMP_TAC [CX_INJ]);;
 e (SUBGOAL_THEN `&0 < &2*a ` ASSUME_TAC);;
e (MATCH_MP_TAC REAL_LT_MUL);;
e (ASM_REWRITE_TAC []);;
e (SIMPLE_COMPLEX_ARITH_TAC);;


e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `	((&0)) = ((&0) * inv (&2 * a)) 
     		       `]);;


e (SUBGOAL_THEN `(--b - sqrt (b pow 2 - &4 * a * c)) * inv (&2 * a) < &0 * inv (&2 * a) ` ASSUME_TAC);;	
e (MATCH_MP_TAC REAL_LT_RMUL);;	   
e (CONJ_TAC);;  
r(1);;
e (MATCH_MP_TAC REAL_INV_POS);;	   
e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `(--b - sqrt (b pow 2 - &4 * a * c)) * inv (&2 * a) < &0 * inv (&2 * a)`);;
e (SIMP_TAC []);;
e (ONCE_REWRITE_TAC[REAL_RING ` ((( --(b:real) - c)) < ( &0)) = (c < --b)`] );;
e (ASM_REWRITE_TAC [NOT_IN_EMPTY]);;
e (ONCE_REWRITE_TAC [REAL_FIELD `(--(x:real) - y < (&0)) = (--x < y)`]);;
e (ASM_REWRITE_TAC []);;


let QUAD_REAL_CASE_FIVE  = top_thm();;
   (*==========================================================*)
   (***************IMAGINARY ROOT CASES*************************)
   (***************For x = -b +/- sqrt (x)/ 2 a*****************)
   (*==========================================================*)
   

(*-*-*-*-*-*-*-*-*-*-*-*-*-Imaginary Case*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < b/a  /\ (b pow 2 - &4 * a * c) < 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 


g ` !(a:real) (b:real) (c:real). 
 ~(Cx(&0) = Cx(a))  /\ 
  ((b pow 2 - &4 * a * c) < &0)/\ 
  (&0 < b / a) ==> 
  ~(!x. Cx(a)* x pow 2 + Cx(b) * x + Cx(c) = Cx(&0) /\ Re x < &0 <=> x IN {} )`;;


e (REPEAT GEN_TAC);;
    e (STRIP_TAC);;
    e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;
    e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
    e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;


 e (SUBGOAL_THEN `((b pow 2 - &4 *( a:real) * c) = --(&4 * a * c -  b pow 2)) ` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [REAL_NEG_SUB]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC ``);;
e (ONCE_ASM_REWRITE_TAC []);;
 e (SUBGOAL_THEN `(--(&4 * a * c - b pow 2)) = -- &1 * (&4 * a * c - b pow 2)` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_MINUS1]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `--(&4 * a * c - b pow 2) = -- &1 * (&4 * a * c - b pow 2)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [CX_MUL]);;
e (ONCE_REWRITE_TAC [CX_NEG]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_II_2]);;

 e (SUBGOAL_THEN ` Cx (&4 * a * c - b pow 2)  = (csqrt ( Cx (&4 * a * c - b pow 2) ))pow 2` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [CSQRT]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;



e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [GSYM  COMPLEX_POW_MUL]);;


 e (SUBGOAL_THEN `csqrt ((ii * csqrt (Cx (&4 * a * c - b pow 2))) pow 2) = (ii * csqrt (Cx (&4 * a * c - b pow 2)))` ASSUME_TAC);;
e (MATCH_MP_TAC POW_2_CSQRT);;
e (DISJ2_TAC);;

e (CONJ_TAC);;

 e (SUBGOAL_THEN `(ii * csqrt (Cx (&4 * a * c - b pow 2))) = ( csqrt (Cx (&4 * a * c - b pow 2)) * ii )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_MUL_II]);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;

e (ONCE_REWRITE_TAC [IM_CX]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [IM]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (UNDISCH_TAC `Cx (&4 * a * c - b pow 2) = csqrt (Cx (&4 * a * c - b pow 2)) pow 2`);;

e (SIMP_TAC [CX_SQRT]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISCH_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC SQRT_POS_LT);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt ((ii * csqrt (Cx (&4 * a * c - b pow 2))) pow 2) =
      ii * csqrt (Cx (&4 * a * c - b pow 2))`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) =
   		  (Cx (sqrt(&4 * a * c - b pow 2))) ` ASSUME_TAC);;


e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2))`);;

e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_NEG]);;

e (ONCE_REWRITE_TAC [complex_div]);;
e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
e (ONCE_REWRITE_TAC [GSYM CX_INV]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;

e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;



e (ONCE_REWRITE_TAC [ii]);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [complex_mul]);;

e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;

 e (SUBGOAL_THEN `(&0 * sqrt (&4 * a * c - b pow 2) * inv (&2 * a) - &1 * &0) = &0` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `(&0 * &0 + &1 * sqrt (&4 * a * c - b pow 2) * inv (&2 * a) ) 
  		     =  (sqrt (&4 * a * c - b pow 2) * inv (&2 * a))` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [complex_add]);;
e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;
e (ONCE_REWRITE_TAC [RE]);;

e (ONCE_REWRITE_TAC[REAL_ARITH `(--b * inv (&2 * a) + &0 < &0) = (--b * inv (&2 * a) < &0)`] );;

e (ONCE_REWRITE_TAC [REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `((a:real) * b * c) = ((a*c)*b)`] );;

 e (SUBGOAL_THEN `&0 < &2` ASSUME_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `&0 < &2`);;

e (ONCE_REWRITE_TAC [GSYM real_div]);;

e (SIMP_TAC [REAL_LT_LDIV_EQ]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(&0 * &2) = (&0)`] );;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_LMUL]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC []);;
e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

let QUAD_IMAG_CASE = top_thm();;


   (*==========================================================*)
   (***************QUAD ALL ROOTS THEOREM***********************)
   (************************************************************)
   (*==========================================================*)

g ` !(a:real) (b:real) (c:real).  
  ~(Cx (&0) = Cx a) /\
  (  
     ( (&0 < b / a) /\ 
       ( ((b pow 2 - &4 * a * c) < &0)   \/ 
    	    (b pow 2 - &4 * a * c = &0)) )    \/
     ( (&0 < b pow 2 - &4 * a * c)  /\
       ( (a < &0) /\ ( (b < sqrt (b pow 2 - &4 * a * c)   \/
                          (sqrt (b pow 2 - &4 * a * c) < --b)  ) )  \/ 
       ( (&0 < a) /\ ( (sqrt (b pow 2 - &4 * a * c) < b)   \/ 
                          (--b < sqrt (b pow 2 - &4 * a * c)) ) )))) 
    ==> ~(!x. Cx(a)* x pow 2 + Cx(b) * x + Cx(c) = Cx(&0) /\ Re x < &0 <=> x IN {} )`;;


e (REPEAT GEN_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC QUAD_IMAG_CASE );;
e (ASM_SIMP_TAC []);;
e (MATCH_MP_TAC QUAD_REAL_CASE_THREE);;
e (ASM_SIMP_TAC []);;
e (MATCH_MP_TAC QUAD_REAL_CASE_TWO);;
e (ASM_SIMP_TAC []);;
e (MATCH_MP_TAC QUAD_REAL_CASE_FOUR);;
e (ASM_SIMP_TAC []);;
e (MATCH_MP_TAC QUAD_REAL_CASE_ONE);;
e (ASM_SIMP_TAC []);;
e (MATCH_MP_TAC QUAD_REAL_CASE_FIVE);;
e (ASM_SIMP_TAC []);;


let QUAD_ALL_STABLE_CASES = top_thm();;


   (*==========================================================*)
   (***********QUAD ALL UNSTABLE ROOTS THEOREM******************)
   (************************************************************)
   (*==========================================================*)

g ` !(a:real) (b:real) (c:real).  
  ~(Cx (&0) = Cx a) /\
  (  
     ( (b / a < &0) /\ 
       ( ((b pow 2 - &4 * a * c) < &0)   \/ 
    	    (b pow 2 - &4 * a * c = &0)) )    \/
     ( (&0 < b pow 2 - &4 * a * c)  /\
       ( (&0 < a) /\ ( (b < sqrt (b pow 2 - &4 * a * c)   \/
                          (sqrt (b pow 2 - &4 * a * c) < --b)  ) )  \/ 
       ( (a < & 0) /\ ( (sqrt (b pow 2 - &4 * a * c) < b)   \/ 
                          (--b < sqrt (b pow 2 - &4 * a * c)) ) )))) 
    ==> ~(!x. Cx(a)* x pow 2 + Cx(b) * x + Cx(c) = Cx(&0) /\ Re x > &0 <=> x IN {} )`;;

e (REPEAT GEN_TAC);;
e (STRIP_TAC);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Imaginary Case*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* b/a <0  /\ (b pow 2 - &4 * a * c) < 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;
    e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
    e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;


 e (SUBGOAL_THEN `((b pow 2 - &4 *( a:real) * c) = --(&4 * a * c -  b pow 2)) ` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [REAL_NEG_SUB]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
 e (SUBGOAL_THEN `(--(&4 * a * c - b pow 2)) = -- &1 * (&4 * a * c - b pow 2)` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_MINUS1]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `--(&4 * a * c - b pow 2) = -- &1 * (&4 * a * c - b pow 2)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [CX_MUL]);;
e (ONCE_REWRITE_TAC [CX_NEG]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_II_2]);;

 e (SUBGOAL_THEN ` Cx (&4 * a * c - b pow 2)  = (csqrt ( Cx (&4 * a * c - b pow 2) ))pow 2` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [CSQRT]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;



e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [GSYM  COMPLEX_POW_MUL]);;


 e (SUBGOAL_THEN `csqrt ((ii * csqrt (Cx (&4 * a * c - b pow 2))) pow 2) = (ii * csqrt (Cx (&4 * a * c - b pow 2)))` ASSUME_TAC);;
e (MATCH_MP_TAC POW_2_CSQRT);;
e (DISJ2_TAC);;

e (CONJ_TAC);;

 e (SUBGOAL_THEN `(ii * csqrt (Cx (&4 * a * c - b pow 2))) = ( csqrt (Cx (&4 * a * c - b pow 2)) * ii )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_MUL_II]);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;

e (ONCE_REWRITE_TAC [IM_CX]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [IM]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (UNDISCH_TAC `Cx (&4 * a * c - b pow 2) = csqrt (Cx (&4 * a * c - b pow 2)) pow 2`);;

e (SIMP_TAC [CX_SQRT]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISCH_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC SQRT_POS_LT);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt ((ii * csqrt (Cx (&4 * a * c - b pow 2))) pow 2) =
      ii * csqrt (Cx (&4 * a * c - b pow 2))`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) =
   		  (Cx (sqrt(&4 * a * c - b pow 2))) ` ASSUME_TAC);;


e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2))`);;

e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_NEG]);;

e (ONCE_REWRITE_TAC [complex_div]);;
e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
e (ONCE_REWRITE_TAC [GSYM CX_INV]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;

e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;



e (ONCE_REWRITE_TAC [ii]);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [complex_mul]);;

e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;

 e (SUBGOAL_THEN `(&0 * sqrt (&4 * a * c - b pow 2) * inv (&2 * a) - &1 * &0) = &0` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `(&0 * &0 + &1 * sqrt (&4 * a * c - b pow 2) * inv (&2 * a) ) 
  		     =  (sqrt (&4 * a * c - b pow 2) * inv (&2 * a))` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [complex_add]);;
e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;
e (ONCE_REWRITE_TAC [RE]);;

e (ONCE_REWRITE_TAC[REAL_ARITH `(--b * inv (&2 * a) + &0 > &0) = (--b * inv (&2 * a) > &0)`] );;

e (ONCE_REWRITE_TAC [REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `((a:real) * b * c) = ((a*c)*b)`] );;

 e (SUBGOAL_THEN `&0 < &2` ASSUME_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `&0 < &2`);;

e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `((--b * inv a) / &2 > &0) =  (&0 < (--b * inv a) / &2)`]);;
e (SIMP_TAC [REAL_LT_RDIV_EQ]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(&0 * &2) = (&0)`] );;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_LMUL]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC []);;
e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 3-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* b/a < &0  /\ (b pow 2 - &4 * a * c) = 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 
    e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;

e (UNDISCH_TAC `b pow 2 - &4 * a * c = &0`);;
e (SIMP_TAC []);;

e (SIMP_TAC [CSQRT_0]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (Cx(&0) *(a:complex) = Cx(&0)  )`]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real)  + (&0) = --b * c  )`]);;


 e (SUBGOAL_THEN `--b * inv (&2 * a) > &0` ASSUME_TAC);;


e (REWRITE_TAC[REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real) * d = (--b * d) * c  )`]);;

 e (SUBGOAL_THEN `&0 < inv (&2 )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;


e (UNDISCH_TAC `&0 < inv (&2)`);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((--b * inv a) * inv (&2) > &0) = (&0 < (--b * inv a) * inv (&2))`]);;
e (SIMP_TAC [GSYM REAL_LT_LDIV_EQ]);;

e (DISCH_TAC);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (&0 / (c:real) = &0  )`]);;
e (REWRITE_TAC[GSYM REAL_NEG_LMUL]);;

e (REWRITE_TAC[REAL_NEG_GT0]);;
e (ASM_MESON_TAC [real_div]);;
e (DISCH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);; 

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 2-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*a > 0  /\ b < sqrt (b pow 2 - &4 * a * c)-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 

    e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)

	   



 e (SUBGOAL_THEN `&0 < (&2 * a) ` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_LDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&0 < &2 * a`);;
e (REWRITE_TAC[GSYM real_div]);;
e (SIMP_TAC [ REAL_ARITH `((--b + sqrt (b pow 2 - &4 * a * c)) / (&2 * a) > &0) = (&0 < (--b + sqrt (b pow 2 - &4 * a * c)) / (&2 * a))`]);;
e (SIMP_TAC [REAL_LT_RDIV_EQ]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `&0 * (&2 * a) = &0	  
     		       `]);;

e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 < --(a:real) + b) = (&0 < b + --a) `]);;

e (REWRITE_TAC[GSYM REAL_LT_SUB_RADD]);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 - --(a:real) =  a)`]);;


e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 4-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ sqrt (b pow 2 - &4 * a * c) < --b*-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)

	   



 e (SUBGOAL_THEN `&0 < (&2 * a) ` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_LDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&0 < &2 * a`);;
e (REWRITE_TAC[GSYM real_div]);;
e (SIMP_TAC [ REAL_ARITH `((--b - sqrt (b pow 2 - &4 * a * c)) / (&2 * a) > &0) = (&0 < (--b - sqrt (b pow 2 - &4 * a * c)) / (&2 * a))`]);;
e (SIMP_TAC [REAL_LT_RDIV_EQ]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `&0 * (&2 * a) = &0	  
     		       `]);;

e (ONCE_REWRITE_TAC [REAL_ARITH ` &0 = -- &0`]);;
e (SIMP_TAC [REAL_SUB_LNEG]);;
e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_REWRITE_TAC [REAL_ARITH `((x:real) + y < & 0) = (y < -- x)`]);;
e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;



(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 1-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*a < 0  /\ sqrt (b pow 2 - &4 * a * c) < b-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)
e (SIMP_TAC [GSYM CX_MUL]);;
e (SIMP_TAC [CX_INJ]);;
 e (SUBGOAL_THEN ` &2*a < &0` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;
e (ASM_MESON_TAC []);;

e (REWRITE_TAC [REAL_ARITH `((--b + sqrt (b pow 2 - &4 * a * c)) * inv (&2 * a) > &0) =
                                (&0 < (--b + sqrt (b pow 2 - &4 * a * c)) * inv (&2 * a) )`]);;

e (REWRITE_TAC[GSYM real_div]);;
e (UNDISCH_TAC`&2 * a < &0`);;
e (SIMP_TAC [DENOM_LT_LDIV_0]);;
e (DISCH_TAC);;
e (SIMP_TAC [REAL_ARITH `&0 * &2 * a  = &0`]);;
e (ONCE_REWRITE_TAC [REAL_FIELD `(--b + sqrt (b pow 2 - &4 * a * c) < &0) = (sqrt (b pow 2 - &4 * a * c) < b)`]);;
e (ASM_REWRITE_TAC [NOT_IN_EMPTY]);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 5-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*a < 0  /\ --b < (b pow 2 - &4 * a * c) **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


 e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)
e (SIMP_TAC [GSYM CX_MUL]);;
e (SIMP_TAC [CX_INJ]);;
 e (SUBGOAL_THEN `&2*a < &0` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;
e (ASM_MESON_TAC []);;

e (REWRITE_TAC [REAL_ARITH `((--b - sqrt (b pow 2 - &4 * a * c)) * inv (&2 * a) > &0) =
                                (&0 < (--b - sqrt (b pow 2 - &4 * a * c)) * inv (&2 * a) )`]);;

e (REWRITE_TAC[GSYM real_div]);;
e (UNDISCH_TAC`&2 * a < &0`);;
e (SIMP_TAC [DENOM_LT_LDIV_0]);;
e (DISCH_TAC);;
e (SIMP_TAC [REAL_ARITH `&0 * &2 * a  = &0`]);;
e (ONCE_REWRITE_TAC [REAL_FIELD `(--b - sqrt (b pow 2 - &4 * a * c) < &0) = (-- b < sqrt (b pow 2 - &4 * a * c))`]);;
e (ASM_REWRITE_TAC [NOT_IN_EMPTY]);;


let QUAD_ALL_UNSTABLE_CASES = top_thm();;


   (*==========================================================*)
   (***********QUAD ALL MARGINALLY STABLE ROOTS THEOREM*********)
   (************************************************************)
   (*==========================================================*)

g ` !(a:real) (b:real) (c:real).  
  ~(Cx (&0) = Cx a) /\
  (  
     ( (b / a = &0) /\ 
       ( ((b pow 2 - &4 * a * c) < &0)   \/ 
    	    (b pow 2 - &4 * a * c = &0)) )    \/
     ( (&0 < b pow 2 - &4 * a * c)  /\
       ( (&0 < a \/ a < &0) /\ ( ( sqrt (b pow 2 - &4 * a * c) = b)   \/ sqrt (b pow 2 - &4 * a * c) = -- b))))
    ==> ~(!x. Cx(a)* x pow 2 + Cx(b) * x + Cx(c) = Cx(&0) /\ Re x = &0 <=> x IN {} )`;;


e (REPEAT GEN_TAC);;
e (STRIP_TAC);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Imaginary Case*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* b/a = 0  /\ (b pow 2 - &4 * a * c) < 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;
    e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
    e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;


 e (SUBGOAL_THEN `((b pow 2 - &4 *( a:real) * c) = --(&4 * a * c -  b pow 2)) ` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [REAL_NEG_SUB]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
 e (SUBGOAL_THEN `(--(&4 * a * c - b pow 2)) = -- &1 * (&4 * a * c - b pow 2)` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_MINUS1]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `--(&4 * a * c - b pow 2) = -- &1 * (&4 * a * c - b pow 2)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [CX_MUL]);;
e (ONCE_REWRITE_TAC [CX_NEG]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_II_2]);;

 e (SUBGOAL_THEN ` Cx (&4 * a * c - b pow 2)  = (csqrt ( Cx (&4 * a * c - b pow 2) ))pow 2` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [CSQRT]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;



e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [GSYM  COMPLEX_POW_MUL]);;


 e (SUBGOAL_THEN `csqrt ((ii * csqrt (Cx (&4 * a * c - b pow 2))) pow 2) = (ii * csqrt (Cx (&4 * a * c - b pow 2)))` ASSUME_TAC);;
e (MATCH_MP_TAC POW_2_CSQRT);;
e (DISJ2_TAC);;

e (CONJ_TAC);;

 e (SUBGOAL_THEN `(ii * csqrt (Cx (&4 * a * c - b pow 2))) = ( csqrt (Cx (&4 * a * c - b pow 2)) * ii )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_MUL_II]);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;

e (ONCE_REWRITE_TAC [IM_CX]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [IM]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (UNDISCH_TAC `Cx (&4 * a * c - b pow 2) = csqrt (Cx (&4 * a * c - b pow 2)) pow 2`);;

e (SIMP_TAC [CX_SQRT]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISCH_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC SQRT_POS_LT);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt ((ii * csqrt (Cx (&4 * a * c - b pow 2))) pow 2) =
      ii * csqrt (Cx (&4 * a * c - b pow 2))`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c - b pow 2)) =
   		  (Cx (sqrt(&4 * a * c - b pow 2))) ` ASSUME_TAC);;


e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (&4 * a * c - b pow 2)) = Cx (sqrt (&4 * a * c - b pow 2))`);;

e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_NEG]);;

e (ONCE_REWRITE_TAC [complex_div]);;
e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
e (ONCE_REWRITE_TAC [GSYM CX_INV]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;

e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;



e (ONCE_REWRITE_TAC [ii]);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [complex_mul]);;

e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;

 e (SUBGOAL_THEN `(&0 * sqrt (&4 * a * c - b pow 2) * inv (&2 * a) - &1 * &0) = &0` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `(&0 * &0 + &1 * sqrt (&4 * a * c - b pow 2) * inv (&2 * a) ) 
  		     =  (sqrt (&4 * a * c - b pow 2) * inv (&2 * a))` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [complex_add]);;
e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;
e (ONCE_REWRITE_TAC [RE]);;

e (ONCE_REWRITE_TAC[REAL_ARITH `(--b * inv (&2 * a) + &0 = &0) = (--b * inv (&2 * a) = &0)`] );;

e (ONCE_REWRITE_TAC [REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `((a:real) * b * c) = ((a*c)*b)`] );;

e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `((--b * inv a) / &2 = &0) =  ( (--b * inv a)  = &0)`]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;
e (REWRITE_TAC[GSYM REAL_NEG_LMUL]);;

e (ONCE_REWRITE_TAC [REAL_EQ_NEG2]);;
e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (SIMP_TAC []);;
e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 3-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* b/a = &0  /\ (b pow 2 - &4 * a * c) = 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 
    e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;

e (UNDISCH_TAC `b pow 2 - &4 * a * c = &0`);;
e (SIMP_TAC []);;

e (SIMP_TAC [CSQRT_0]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (Cx(&0) *(a:complex) = Cx(&0)  )`]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real)  + (&0) = --b * c  )`]);;


 e (SUBGOAL_THEN `--b * inv (&2 * a) = &0` ASSUME_TAC);;


e (REWRITE_TAC[REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real) * d = (--b * d) * c  )`]);;

e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((--b * inv a) * inv (&2) = &0) = ((--b * inv a) = &0)`]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;
e (REWRITE_TAC[GSYM REAL_NEG_LMUL]);;

e (ONCE_REWRITE_TAC [REAL_EQ_NEG2]);;
e (ASM_REWRITE_TAC [GSYM real_div]);;
e (DISCH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);; 

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 2-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*a > 0  /\ b < sqrt (b pow 2 - &4 * a * c) = b-**-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 
e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;

(*---------2*a <> 0 (Up)-------------*)

e (REWRITE_TAC [NOT_IN_EMPTY]);;
e (REWRITE_TAC[REAL_ENTIRE]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(--a + b = &0) = (b = a)`] );;
e (ASM_REWRITE_TAC []);;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 4-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ sqrt (b pow 2 - &4 * a * c) = --b*-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;

(*---------2*a <> 0 (Up)-------------*)

e (REWRITE_TAC [NOT_IN_EMPTY]);;
e (REWRITE_TAC[REAL_ENTIRE]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `&0 = -- &0`]);;
e (SIMP_TAC [ REAL_SUB_LNEG;REAL_EQ_NEG2]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(a + b = &0) = (b = --a)`] );;
e (ASM_REWRITE_TAC []);;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 1-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*a < 0  /\ sqrt (b pow 2 - &4 * a * c) < b-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;

e (REWRITE_TAC [NOT_IN_EMPTY]);;
e (REWRITE_TAC[REAL_ENTIRE]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(--a + b = &0) = (b = a)`] );;
e (ASM_REWRITE_TAC []);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 5-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*a < 0  /\ --b < (b pow 2 - &4 * a * c) **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


 e (SUBGOAL_THEN `!x:complex. ((Cx a * x pow 2 + Cx b * x + Cx c = Cx (&0)) = (x =
              (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) \/
              x =
              (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
              (Cx (&2) * Cx a) ) )` ASSUME_TAC);;

   e (REPEAT GEN_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MESON_TAC[]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b pow 2 - &4 * a * c`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b pow 2 - &4 * a * c)) = Cx (sqrt (b pow 2 - &4 * a * c))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;


e (REWRITE_TAC [NOT_IN_EMPTY]);;
e (REWRITE_TAC[REAL_ENTIRE]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `&0 = -- &0`]);;
e (SIMP_TAC [ REAL_SUB_LNEG;REAL_EQ_NEG2]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(a + b = &0) = (b = --a)`] );;
e (ASM_REWRITE_TAC []);;


let QUAD_ALL_MARGINALLY_STABLE_CASES = top_thm();;



(*-*-*-*-*-*-*-*-*-*-*-CUBIC STABILITY-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-* *-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 

g `!a b1 c1 d1 r x.
         ~(Cx (&0) = Cx a) /\
         Cx b = Cx b1 + Cx (a * r) /\
         Cx c = Cx c1 + Cx (b1 * r) /\
         Cx d = Cx (c1 * r) /\
(
 (  &0 < (r:real)
 )
\/
 ((&0 < b1 / a /\
          (b1 pow 2 - &4 * a * c1 < &0 \/ b1 pow 2 - &4 * a * c1 = &0) \/
          &0 < b1 pow 2 - &4 * a * c1 /\
          (a < &0 /\
           (b1 < sqrt (b1 pow 2 - &4 * a * c1) \/
            sqrt (b1 pow 2 - &4 * a * c1) < --b1) \/
           &0 < a /\
           (sqrt (b1 pow 2 - &4 * a * c1) < b1 \/
            --b1 < sqrt (b1 pow 2 - &4 * a * c1))))
 
)
  
) ==> ~(!x. Cx a * x pow 3 + Cx b * x pow 2 + Cx c * x + Cx d = Cx(&0) /\ Re x < &0 <=> x IN {} ) `;;

e (REPEAT GEN_TAC);;
e (STRIP_TAC);;
e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (--Cx(r))`);;

e (ASM_REWRITE_TAC []);;
    e (ONCE_REWRITE_TAC [GSYM CX_NEG]);;
    e (ONCE_REWRITE_TAC [RE_CX]);;
e (ONCE_REWRITE_TAC [REAL_FIELD `(--r < &0) = (&0 < r)`]);;
e (ASM_SIMP_TAC []);;
e (ASM_SIMP_TAC [NOT_IN_EMPTY]);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Imaginary Case*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < b/a  /\ (b pow 2 - &4 * a * c) < 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          ((Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
        (Cx (&2) * Cx a) )`);;

e (ASM_REWRITE_TAC []);;
  e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
    e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;


 e (SUBGOAL_THEN `((b1 pow 2 - &4 *( a:real) * c1) = --(&4 * a * c1 -  b1 pow 2)) ` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [REAL_NEG_SUB]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC ``);;
e (ONCE_ASM_REWRITE_TAC []);;
 e (SUBGOAL_THEN `(--(&4 * a * c1 - b1 pow 2)) = -- &1 * (&4 * a * c1 - b1 pow 2)` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_MINUS1]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `--(&4 * a * c1 - b1 pow 2) = -- &1 * (&4 * a * c1 - b1 pow 2)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [CX_MUL]);;
e (ONCE_REWRITE_TAC [CX_NEG]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_II_2]);;

 e (SUBGOAL_THEN ` Cx (&4 * a * c1 - b1 pow 2)  = (csqrt ( Cx (&4 * a * c1 - b1 pow 2) ))pow 2` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [CSQRT]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;



e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [GSYM  COMPLEX_POW_MUL]);;


 e (SUBGOAL_THEN `csqrt ((ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))) pow 2) = (ii * csqrt (Cx (&4 * a * c1 - b1 pow 2)))` ASSUME_TAC);;
e (MATCH_MP_TAC POW_2_CSQRT);;
e (DISJ2_TAC);;

e (CONJ_TAC);;

 e (SUBGOAL_THEN `(ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))) = ( csqrt (Cx (&4 * a * c1 - b1 pow 2)) * ii )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_MUL_II]);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [IM_CX]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [IM]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (UNDISCH_TAC `Cx (&4 * a * c1 - b1 pow 2) = csqrt (Cx (&4 * a * c1 - b1 pow 2)) pow 2`);;

e (SIMP_TAC [CX_SQRT]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISCH_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC SQRT_POS_LT);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt ((ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))) pow 2) =
      ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) =
   		  (Cx (sqrt(&4 * a * c1 - b1 pow 2))) ` ASSUME_TAC);;


e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2))`);;

e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_NEG]);;

e (ONCE_REWRITE_TAC [complex_div]);;
e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
e (ONCE_REWRITE_TAC [GSYM CX_INV]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;

e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;



e (ONCE_REWRITE_TAC [ii]);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [complex_mul]);;

e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;

 e (SUBGOAL_THEN `(&0 * sqrt (&4 * a * c1 - b1 pow 2) * inv (&2 * a) - &1 * &0) = &0` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `(&0 * &0 + &1 * sqrt (&4 * a * c1 - b1 pow 2) * inv (&2 * a) ) 
  		     =  (sqrt (&4 * a * c1 - b1 pow 2) * inv (&2 * a))` ASSUME_TAC);;

e (REAL_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [complex_add]);;
e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;
e (ONCE_REWRITE_TAC [RE]);;

e (ONCE_REWRITE_TAC[REAL_ARITH `(--b1 * inv (&2 * a) + &0 < &0) = (--b1 * inv (&2 * a) < &0)`] );;

e (ONCE_REWRITE_TAC [REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `((a:real) * b * c) = ((a*c)*b)`] );;

 e (SUBGOAL_THEN `&0 < &2` ASSUME_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `&0 < &2`);;

e (ONCE_REWRITE_TAC [GSYM real_div]);;

e (SIMP_TAC [REAL_LT_LDIV_EQ]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(&0 * &2) = (&0)`] );;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_LMUL]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC []);;
e (ASM_MESON_TAC [NOT_IN_EMPTY]);;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 3-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < b/a  /\ (b pow 2 - &4 * a * c) = 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 
e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;

e (UNDISCH_TAC `b1 pow 2 - &4 * a * c1 = &0`);;
e (SIMP_TAC []);;

e (SIMP_TAC [CSQRT_0]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (Cx(&0) *(a:complex) = Cx(&0)  )`]);;

e (REWRITE_TAC[RE_CX]);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real)  + &0 = --b * c  )`]);;


 e (SUBGOAL_THEN `--b1 * inv (&2 * a) < &0` ASSUME_TAC);;


e (REWRITE_TAC[REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real) * d = (--b * d) * c  )`]);;

 e (SUBGOAL_THEN `&0 < inv (&2 )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;


e (UNDISCH_TAC `&0 < inv (&2)`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;

e (DISCH_TAC);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (&0 / (c:real) = &0  )`]);;
e (REWRITE_TAC[GSYM REAL_NEG_LMUL]);;

e (REWRITE_TAC[REAL_NEG_LT0]);;
e (ASM_MESON_TAC [real_div]);;
e (REWRITE_TAC[GSYM CX_ADD]);;

e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--(a:real)*b + &0 = --a*b   )`]);;
e (DISCH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;
(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 2-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < b/a  /\ (b pow 2 - &4 * a * c) = 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;


e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)

 e (SUBGOAL_THEN `(&2 * a) < &0 ` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&2 * a < &0`);;
e (REWRITE_TAC[GSYM real_div]);;

e (SIMP_TAC [DENOM_LT_0]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(&2 * a) * &0 = &0	  
     		       `]);;

e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 < --(a:real) + b) = (&0 < b + --a) `]);;

e (REWRITE_TAC[GSYM REAL_LT_SUB_RADD]);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 - --(a:real) =  a)`]);;


e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 4-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ (b pow 2 - &4 * a * c) < --b **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;
e (DISCH_TAC);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)

	   



 e (SUBGOAL_THEN `(&2 * a) < &0 ` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&2 * a < &0`);;
e (REWRITE_TAC[GSYM real_div]);;

e (ASM_SIMP_TAC [DENOM_LT_0]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(&2 * a) * &0 = &0	  
     		       `]);;

e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 < --(a:real) - b) = (b < --a ) `]);;

e (REWRITE_TAC[GSYM REAL_LT_SUB_RADD]);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 - --(a:real) =  a)`]);;


e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;
(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 1-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ --b < (b pow 2 - &4 * a * c) **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;


e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)
e (SIMP_TAC [GSYM CX_MUL]);;
e (SIMP_TAC [CX_INJ]);;
 e (SUBGOAL_THEN `&0 < &2*a ` ASSUME_TAC);;
e (MATCH_MP_TAC REAL_LT_MUL);;
e (ASM_REWRITE_TAC []);;
e (SIMPLE_COMPLEX_ARITH_TAC);;


e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `	((&0)) = ((&0) * inv (&2 * a)) 
     		       `]);;


e (SUBGOAL_THEN `(--b1 + sqrt (b1 pow 2 - &4 * a * c1)) * inv (&2 * a) < &0 * inv (&2 * a) ` ASSUME_TAC);;	
e (MATCH_MP_TAC REAL_LT_RMUL);;	   
e (CONJ_TAC);;  
e (ONCE_REWRITE_TAC [REAL_ARITH `(--(b:real) + c < &0) = (c < b) `]);;
e (ASM_SIMP_TAC []);;
e (MATCH_MP_TAC REAL_INV_POS);;	   
e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `(--b1 + sqrt (b1 pow 2 - &4 * a * c1)) * inv (&2 * a) < &0 * inv (&2 * a)`);;
e (SIMP_TAC []);;


    (*--------- e (REWRITE_TAC [REAL_LT_ADD_SUB]);;-------------*)
   (*---------  e (REWRITE_TAC [REAL_SUB_LZERO]);;-------------*)
    (*--------- e (REWRITE_TAC [REAL_LT_NEG2]);;-------------*)
(*---------e (ONCE_REWRITE_TAC[REAL_RING ` ((&0 - (b:real))) = ( - b)`] );;-------------*)
(*---------e (ASM_REWRITE_TAC []);;-------------*)
(*---------e (DISCH_TAC);;-------------*)
e (ASM_REWRITE_TAC [NOT_IN_EMPTY]);;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 5-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ --b < (b pow 2 - &4 * a * c) **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)
e (SIMP_TAC [GSYM CX_MUL]);;
e (SIMP_TAC [CX_INJ]);;
 e (SUBGOAL_THEN `&0 < &2*a ` ASSUME_TAC);;
e (MATCH_MP_TAC REAL_LT_MUL);;
e (ASM_REWRITE_TAC []);;
e (SIMPLE_COMPLEX_ARITH_TAC);;


e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `	((&0)) = ((&0) * inv (&2 * a)) 
     		       `]);;


e (SUBGOAL_THEN `(--b1 - sqrt (b1 pow 2 - &4 * a * c1)) * inv (&2 * a) < &0 * inv (&2 * a) ` ASSUME_TAC);;	
e (MATCH_MP_TAC REAL_LT_RMUL);;	   
e (CONJ_TAC);;  
r(1);;
e (MATCH_MP_TAC REAL_INV_POS);;	   
e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `(--b1 - sqrt (b1 pow 2 - &4 * a * c1)) * inv (&2 * a) < &0 * inv (&2 * a)`);;
e (SIMP_TAC []);;
e (ONCE_REWRITE_TAC[REAL_RING ` ((( --(b:real) - c)) < ( &0)) = (c < --b)`] );;
e (ASM_REWRITE_TAC [NOT_IN_EMPTY]);;
e (ONCE_REWRITE_TAC [REAL_FIELD `(--(x:real) - y < (&0)) = (--x < y)`]);;
e (ASM_REWRITE_TAC []);;

let CUBIC_ALL_STABLE_CASES = top_thm();;


(*-*-*-*-*-*-*-*-*-*-*-CUBIC UNSTABILITY-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-* *-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 
g `!a b1 c1 d1 r x.
         ~(Cx (&0) = Cx a) /\
         Cx b = Cx b1 + Cx (a * r) /\
         Cx c = Cx c1 + Cx (b1 * r) /\
         Cx d = Cx (c1 * r) /\
(
 ( (r:real) < &0
 )
\/ (( b1 / a < &0 /\
          (b1 pow 2 - &4 * a * c1 < &0 \/ b1 pow 2 - &4 * a * c1 = &0) \/
          &0 < b1 pow 2 - &4 * a * c1 /\
          (&0 < a /\
           (b1 < sqrt (b1 pow 2 - &4 * a * c1) \/
            sqrt (b1 pow 2 - &4 * a * c1) < --b1) \/
           a < &0 /\
           (sqrt (b1 pow 2 - &4 * a * c1) < b1 \/
            --b1 < sqrt (b1 pow 2 - &4 * a * c1))))
 
)
  
)
==> ~(!x. Cx a * x pow 3 + Cx b * x pow 2 + Cx c * x + Cx d = Cx(&0) /\ Re x > &0 <=> x IN {} ) `;;

e (REPEAT GEN_TAC);;
e (STRIP_TAC);;

e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (--Cx(r))`);;

e (ASM_REWRITE_TAC []);;
    e (ONCE_REWRITE_TAC [GSYM CX_NEG]);;
    e (ONCE_REWRITE_TAC [RE_CX]);;
e (ONCE_REWRITE_TAC [REAL_FIELD `(--r > &0) = (r < &0)`]);;
e (ASM_SIMP_TAC []);;
e (ASM_SIMP_TAC [NOT_IN_EMPTY]);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Imaginary Case*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* b/a <0  /\ (b pow 2 - &4 * a * c) < 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          ((Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
        (Cx (&2) * Cx a) )`);;

e (ASM_REWRITE_TAC []);;
  e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
    e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;


 e (SUBGOAL_THEN `((b1 pow 2 - &4 *( a:real) * c1) = --(&4 * a * c1 -  b1 pow 2)) ` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [REAL_NEG_SUB]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
 e (SUBGOAL_THEN `(--(&4 * a * c1 - b1 pow 2)) = -- &1 * (&4 * a * c1 - b1 pow 2)` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_MINUS1]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `--(&4 * a * c1 - b1 pow 2) = -- &1 * (&4 * a * c1 - b1 pow 2)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [CX_MUL]);;
e (ONCE_REWRITE_TAC [CX_NEG]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_II_2]);;

 e (SUBGOAL_THEN ` Cx (&4 * a * c1 - b1 pow 2)  = (csqrt ( Cx (&4 * a * c1 - b1 pow 2) ))pow 2` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [CSQRT]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;



e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [GSYM  COMPLEX_POW_MUL]);;


 e (SUBGOAL_THEN `csqrt ((ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))) pow 2) = (ii * csqrt (Cx (&4 * a * c1 - b1 pow 2)))` ASSUME_TAC);;
e (MATCH_MP_TAC POW_2_CSQRT);;
e (DISJ2_TAC);;

e (CONJ_TAC);;

 e (SUBGOAL_THEN `(ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))) = ( csqrt (Cx (&4 * a * c1 - b1 pow 2)) * ii )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_MUL_II]);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [IM_CX]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [IM]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (UNDISCH_TAC `Cx (&4 * a * c1 - b1 pow 2) = csqrt (Cx (&4 * a * c1 - b1 pow 2)) pow 2`);;

e (SIMP_TAC [CX_SQRT]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISCH_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC SQRT_POS_LT);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt ((ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))) pow 2) =
      ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) =
   		  (Cx (sqrt(&4 * a * c1 - b1 pow 2))) ` ASSUME_TAC);;


e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2))`);;

e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_NEG]);;

e (ONCE_REWRITE_TAC [complex_div]);;
e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
e (ONCE_REWRITE_TAC [GSYM CX_INV]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;

e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;



e (ONCE_REWRITE_TAC [ii]);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [complex_mul]);;

e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;

 e (SUBGOAL_THEN `(&0 * sqrt (&4 * a * c1 - b1 pow 2) * inv (&2 * a) - &1 * &0) = &0` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `(&0 * &0 + &1 * sqrt (&4 * a * c1 - b1 pow 2) * inv (&2 * a) ) 
  		     =  (sqrt (&4 * a * c1 - b1 pow 2) * inv (&2 * a))` ASSUME_TAC);;

e (REAL_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [complex_add]);;
e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;
e (ONCE_REWRITE_TAC [RE]);;

e (ONCE_REWRITE_TAC[REAL_ARITH `(--b1 * inv (&2 * a) + &0 > &0) = (--b1 * inv (&2 * a) > &0)`] );;

e (ONCE_REWRITE_TAC [REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `((a:real) * b * c) = ((a*c)*b)`] );;

 e (SUBGOAL_THEN `&0 < &2` ASSUME_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `&0 < &2`);;

e (ONCE_REWRITE_TAC [GSYM real_div]);;

e (SIMP_TAC [REAL_LT_LDIV_EQ]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(&0 * &2) = (&0)`] );;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_LMUL]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;
e (REWRITE_TAC [NOT_IN_EMPTY]);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` (a / b > c) <=> (c < a / b)`]);;
e (ONCE_REWRITE_TAC [REAL_ARITH `  (-- c < --(a) / b) <=> (-- c < -- (a /b))`]);;


e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_REWRITE_TAC [real_div]);;
e (ONCE_REWRITE_TAC [REAL_ARITH `&0 = &0 * inv (&2)`]);;
e (MATCH_MP_TAC REAL_LT_RMUL);;
e (CONJ_TAC);;
r(1);;
e (MATCH_MP_TAC REAL_INV_POS);;
e (ONCE_ASM_REWRITE_TAC []);;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 3-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* b/a < &0  /\ (b pow 2 - &4 * a * c) = 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 
     
e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;

e (UNDISCH_TAC `b1 pow 2 - &4 * a * c1 = &0`);;
e (SIMP_TAC []);;

e (SIMP_TAC [CSQRT_0]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (Cx(&0) *(a:complex) = Cx(&0)  )`]);;

e (REWRITE_TAC[RE_CX]);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real)  + &0 = --b * c  )`]);;


 e (SUBGOAL_THEN `--b1 * inv (&2 * a) > &0` ASSUME_TAC);;

e (ONCE_REWRITE_TAC [REAL_ARITH `(--b1 * inv (&2 * a) > &0) = (&0 < --b1 * inv (&2 * a) )  `]);;
e (REWRITE_TAC[REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real) * d = (--b * d) * c  )`]);;

 e (SUBGOAL_THEN `&0 < inv (&2 )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;


e (UNDISCH_TAC `&0 < inv (&2)`);;
e (SIMP_TAC [GSYM REAL_LT_LDIV_EQ]);;

e (DISCH_TAC);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (&0 / (c:real) = &0  )`]);;
e (REWRITE_TAC[GSYM REAL_NEG_LMUL]);;

e (REWRITE_TAC[REAL_NEG_GT0]);;
e (ASM_MESON_TAC [GSYM real_div]);;
e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--(a:real)*b + &0 = --a*b   )`]);;
e (DISCH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 2-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* b/a < 0 /\ (b pow 2 - &4 * a * c) = 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;


e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)

 e (SUBGOAL_THEN `&0 < (&2 * a) ` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_LDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&0 < &2 * a `);;
e (REWRITE_TAC[GSYM real_div]);;
e (ONCE_REWRITE_TAC [REAL_ARITH `((--b1 + sqrt (b1 pow 2 - &4 * a * c1)) / (&2 * a) > &0) = 
                                 (&0 < (--b1 + sqrt (b1 pow 2 - &4 * a * c1)) / (&2 * a) )`]);; 
e (SIMP_TAC [REAL_LT_RDIV_EQ]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `&0 * (&2 * a) = &0	  
     		       `]);;

e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 < --(a:real) + b) = (a < b) `]);;

e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 4-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ (b pow 2 - &4 * a * c) < --b **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;
e (DISCH_TAC);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)

	   



 e (SUBGOAL_THEN `(&2 * a) > &0 ` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` ((&2 * a) > &0) = (&0 < (&2 * a))`]);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_LDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&2 * a > &0`);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` (&2 * a > &0) = (&0 < &2 * a)`]);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` ((--b1 - sqrt (b1 pow 2 - &4 * a * c1)) * inv (&2 * a) > &0) = 
                                  ( &0 < (--b1 - sqrt (b1 pow 2 - &4 * a * c1)) * inv (&2 * a) )`]);;

e (REWRITE_TAC[GSYM real_div]);;
e (ASM_SIMP_TAC [REAL_LT_RDIV_EQ]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `&0 * (&2 * a)= &0	  
     		       `]);;

e (ONCE_REWRITE_TAC [REAL_ARITH ` (&0 < --(a:real) - b) = (b < --a ) `]);;

e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;



(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 1-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ --b < (b pow 2 - &4 * a * c) **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;


e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)
e (SIMP_TAC [GSYM CX_MUL]);;
e (SIMP_TAC [CX_INJ]);;
e (SUBGOAL_THEN `(&2 * a) < &0 ` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&2 * a < &0`);;


e (ONCE_REWRITE_TAC [REAL_ARITH ` (a > b) = (b <  a) `]);;
e (REWRITE_TAC[GSYM real_div]);;

e (SIMP_TAC [DENOM_LT_LDIV_0]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `&0 * (&2 * a) = &0	  
     		       `]);;

e (ONCE_REWRITE_TAC [REAL_ARITH ` ( --(a:real) + b < &0 ) = ( b < a) `]);;

e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 5-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ b < (b pow 2 - &4 * a * c) **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

   
e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;


(*--------2*a <> 0 (Down)--------*)

e (SUBGOAL_THEN ` ~( Cx (&0) = (Cx (&2) * Cx a)) ` ASSUME_TAC);;
 
	 e (SUBGOAL_THEN `( ( Cx (&0) = (Cx (&2) * Cx a)) = ( Cx (&0) = Cx (a) ) ) ` ASSUME_TAC);;

	   e (EQ_TAC);;
   	   e (DISCH_TAC);;
   	     e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) = Cx a )=(Cx (&0) = (Cx (&2) /Cx (&2))  * Cx a) `]);;
	   e (REWRITE_TAC [complex_div]);;
	   e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;		
	     e (SUBGOAL_THEN `Cx (&2) * inv (Cx (&2)) * Cx a = ( Cx (&2) * Cx (a)) * inv (Cx (&2))` ASSUME_TAC);;
	       e (SIMPLE_COMPLEX_ARITH_TAC);;
	       e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) * Cx a = (Cx (&2) * Cx a) * inv (Cx (&2))`);;
	       e (SIMP_TAC []);;	       
	       e (DISCH_TAC);;
	       e (REWRITE_TAC [GSYM complex_div]);;
	       	 e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;	       
		     e (DISCH_TAC);;
		      e (SIMP_TAC [COMPLEX_EQ_RDIV_EQ]);;
	      e (SUBGOAL_THEN `Cx (&0) * Cx (&2) = Cx (&0)` ASSUME_TAC);;
	      	e (SIMPLE_COMPLEX_ARITH_TAC);;
        	e (UNDISCH_TAC `Cx (&0) * Cx (&2) = Cx (&0)`);;
	       	e (SIMP_TAC []);;	       
	       	e (DISCH_TAC);;
	   e (ONCE_ASM_REWRITE_TAC []);;
           e (SIMPLE_COMPLEX_ARITH_TAC);;
	   e (DISCH_TAC);;
	   
	   e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (DISCH_TAC);;
		     e (REWRITE_TAC [complex_div]);;
		      e (UNDISCH_TAC `(Cx (&0) = Cx a)`);;
	       	     e (SIMP_TAC [GSYM COMPLEX_EQ_LDIV_EQ]);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		      e (UNDISCH_TAC `Cx (&0) = Cx (&2) * Cx a <=> Cx (&0) = Cx a`);;
		       e (SIMP_TAC []);;
		     
		     e (DISCH_TAC);;
		     
		     e (POP_ASSUM (K ALL_TAC));;
		     
		     e (ONCE_ASM_REWRITE_TAC []);;
		      e (ONCE_ASM_REWRITE_TAC []);;
(*---------2*a <> 0 (Up)-------------*)
e (SIMP_TAC [GSYM CX_MUL]);;
e (SIMP_TAC [CX_INJ]);;

 e (SUBGOAL_THEN `(&2 * a) < &0 ` ASSUME_TAC);;
e (REWRITE_TAC[REAL_MUL_SYM]);;
 e (SUBGOAL_THEN ` &0 < &2` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `&0 < &2`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` &0 / &2 = &0`]);;

e (DISCH_TAC);;


e (ASM_MESON_TAC []);;

e (UNDISCH_TAC `&2 * a < &0`);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` (a > b) = (b <  a) `]);;
e (REWRITE_TAC[GSYM real_div]);;

e (SIMP_TAC [DENOM_LT_LDIV_0]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `&0 * (&2 * a) = &0	  
     		       `]);;
e (ONCE_REWRITE_TAC [REAL_ARITH ` ( --(a:real) - b < &0 ) = ( --a < b) `]);;

e (ONCE_ASM_REWRITE_TAC []);;

e (ASM_MESON_TAC [NOT_IN_EMPTY]);;
e (ASM_REWRITE_TAC[GSYM real_div]);;

let CUBIC_ALL_UNSTABLE_CASES = top_thm();;


(*-*-*-*-*-*-*-*-*-CUBIC MARGINALLY STABLE-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-* *-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 


g `!a b1 c1 d1 r x.
         ~(Cx (&0) = Cx a) /\
         Cx b = Cx b1 + Cx (a * r) /\
         Cx c = Cx c1 + Cx (b1 * r) /\
         Cx d = Cx (c1 * r) /\
(
 ( (r:real) = &0
 )
\/
 ( b1 / a = &0 /\
 (b1 pow 2 - &4 * a * c1 < &0 \/ b1 pow 2 - &4 * a * c1 = &0) \/
          &0 < b1 pow 2 - &4 * a * c1 /\
          ((a < &0 \/ &0 < a) /\
           ( sqrt (b1 pow 2 - &4 * a * c1) = b1) \/
            sqrt (b1 pow 2 - &4 * a * c1) = -- b1))
 
)
 ==> ~(!x. Cx a * x pow 3 + Cx b * x pow 2 + Cx c * x + Cx d = Cx(&0) /\ Re x = &0 <=> x IN {} ) `;;



e (REPEAT GEN_TAC);;
e (STRIP_TAC);;

e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (--Cx(r))`);;

e (ASM_REWRITE_TAC []);;
    e (ONCE_REWRITE_TAC [GSYM CX_NEG]);;
    e (ONCE_REWRITE_TAC [RE_CX]);;
e (SIMP_TAC [REAL_NEG_0]);;
e (ASM_SIMP_TAC [NOT_IN_EMPTY]);;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Imaginary Case*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* b/a <= 0  /\ (b pow 2 - &4 * a * c) < 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)


e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          ((Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
        (Cx (&2) * Cx a) )`);;

e (ASM_REWRITE_TAC []);;
  e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
    e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;


 e (SUBGOAL_THEN `((b1 pow 2 - &4 *( a:real) * c1) = --(&4 * a * c1 -  b1 pow 2)) ` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [REAL_NEG_SUB]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
 e (SUBGOAL_THEN `(--(&4 * a * c1 - b1 pow 2)) = -- &1 * (&4 * a * c1 - b1 pow 2)` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_MINUS1]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `--(&4 * a * c1 - b1 pow 2) = -- &1 * (&4 * a * c1 - b1 pow 2)`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [CX_MUL]);;
e (ONCE_REWRITE_TAC [CX_NEG]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_II_2]);;

 e (SUBGOAL_THEN ` Cx (&4 * a * c1 - b1 pow 2)  = (csqrt ( Cx (&4 * a * c1 - b1 pow 2) ))pow 2` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [CSQRT]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;



e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [GSYM  COMPLEX_POW_MUL]);;


 e (SUBGOAL_THEN `csqrt ((ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))) pow 2) = (ii * csqrt (Cx (&4 * a * c1 - b1 pow 2)))` ASSUME_TAC);;
e (MATCH_MP_TAC POW_2_CSQRT);;
e (DISJ2_TAC);;

e (CONJ_TAC);;

 e (SUBGOAL_THEN `(ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))) = ( csqrt (Cx (&4 * a * c1 - b1 pow 2)) * ii )` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_MUL_II]);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [IM_CX]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [IM]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
e (ONCE_REWRITE_TAC [IM_MUL_II]);;
e (UNDISCH_TAC `Cx (&4 * a * c1 - b1 pow 2) = csqrt (Cx (&4 * a * c1 - b1 pow 2)) pow 2`);;

e (SIMP_TAC [CX_SQRT]);;
e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2) )` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;

e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [RE_CX]);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISCH_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC SQRT_POS_LT);;

e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt ((ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))) pow 2) =
      ii * csqrt (Cx (&4 * a * c1 - b1 pow 2))`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
 e (SUBGOAL_THEN `csqrt (Cx (&4 * a * c1 - b1 pow 2)) =
   		  (Cx (sqrt(&4 * a * c1 - b1 pow 2))) ` ASSUME_TAC);;


e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (ONCE_REWRITE_TAC [REAL_LE_LT]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC [GSYM  REAL_NEG_SUB]);;
e (ONCE_REWRITE_TAC[REAL_RING `&0 = --(&0)`] );;

e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (&4 * a * c1 - b1 pow 2)) = Cx (sqrt (&4 * a * c1 - b1 pow 2))`);;

e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_NEG]);;

e (ONCE_REWRITE_TAC [complex_div]);;
e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
e (ONCE_REWRITE_TAC [GSYM CX_INV]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;

e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (ONCE_REWRITE_TAC [GSYM CX_MUL]);;



e (ONCE_REWRITE_TAC [ii]);;
e (ONCE_REWRITE_TAC [CX_DEF]);;
e (ONCE_REWRITE_TAC [complex_mul]);;

e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;

 e (SUBGOAL_THEN `(&0 * sqrt (&4 * a * c1 - b1 pow 2) * inv (&2 * a) - &1 * &0) = &0` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `(&0 * &0 + &1 * sqrt (&4 * a * c1 - b1 pow 2) * inv (&2 * a) ) 
  		     =  (sqrt (&4 * a * c1 - b1 pow 2) * inv (&2 * a))` ASSUME_TAC);;

e (REAL_ARITH_TAC);;

e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [complex_add]);;
e (ONCE_REWRITE_TAC [RE]);;
e (ONCE_REWRITE_TAC [IM]);;
e (ONCE_REWRITE_TAC [RE]);;

e (ONCE_REWRITE_TAC[REAL_ARITH `(--b1 * inv (&2 * a) + &0 > &0) = (--b1 * inv (&2 * a) > &0)`] );;

e (ONCE_REWRITE_TAC [REAL_INV_MUL]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `((a:real) * b * c) = ((a*c)*b)`] );;

 e (SUBGOAL_THEN `&0 < &2` ASSUME_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;


e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (REWRITE_TAC [REAL_ADD_RID]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `((a * b) / &2 = &0) = (a * b = &0)`] );;
e (ONCE_REWRITE_TAC[REAL_ARITH `(--a * b = &0) = (--(a * b) = &0)`]);; 
e (REWRITE_TAC [REAL_NEG_EQ_0]);;
e (ONCE_REWRITE_TAC [GSYM real_div]);;

e (REWRITE_TAC [NOT_IN_EMPTY]);;

e (ASM_REWRITE_TAC []);;



(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 3-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* b/a < &0  /\ (b pow 2 - &4 * a * c) = 0 **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 
     
e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;

e (UNDISCH_TAC `b1 pow 2 - &4 * a * c1 = &0`);;
e (SIMP_TAC []);;

e (SIMP_TAC [CSQRT_0]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (Cx(&0) *(a:complex) = Cx(&0)  )`]);;

e (REWRITE_TAC[RE_CX]);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (--b * (c:real)  + &0 = --b * c  )`]);;

 e (SUBGOAL_THEN `--b1 * inv (&2 * a) = &0` ASSUME_TAC);;
e (ONCE_REWRITE_TAC[REAL_INV_MUL]);;

e (ONCE_REWRITE_TAC[REAL_ARITH `(--b1 * inv (&2) * inv a = &0) = (--b1 * inv (a) * inv (&2) = &0)`] );;
e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(--a * b / &2 = &0) = (--(a * b) / &2 = &0)`]);;
 e (ONCE_REWRITE_TAC[REAL_ARITH `(--(a * b) / &2 = &0) = (-- (a * b) = &0)`] );;

e (REWRITE_TAC [REAL_NEG_EQ_0]);;
e (ONCE_REWRITE_TAC [GSYM real_div]);;
e (ASM_REWRITE_TAC []);;

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ASM_REWRITE_TAC []);;
e (REWRITE_TAC [NOT_IN_EMPTY]);;
e (ARITH_TAC);;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 2-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* a < 0 /\ &0 < (b pow 2 - &4 * a * c)  **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;


e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_MUL]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;


e (REWRITE_TAC [NOT_IN_EMPTY]);;
e (REWRITE_TAC[REAL_ENTIRE]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(--a + b = &0) = (b = a)`] );;
e (ASM_REWRITE_TAC []);;

(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 4-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*0 < a  /\ (b pow 2 - &4 * a * c) = b **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;
e (DISCH_TAC);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;

e (EXISTS_TAC `
          (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;

e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_ADD_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;

e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(down)--------------*)

e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_ADD]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c + (b:real) * c = (--a + b) * c `] );;

e (REWRITE_TAC [NOT_IN_EMPTY]);;
e (REWRITE_TAC[REAL_ENTIRE]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(--a + b = &0) = (b = a)`] );;
e (ASM_REWRITE_TAC []);;


(*-*-*-*-*-*-*-*-*-*-*-*-*-Real Case 1-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-* &0 < (b pow 2 - &4 * a * c) **-**-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)

e (SUBGOAL_THEN `!(x:complex). ( (Cx a * x pow 3 +
       (Cx b) * x pow 2 +
       (Cx c) * x +
       Cx (d) =
       Cx (&0)) <=>
             ( (x = --Cx r) \/
              (x =
              (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) )  \/
              ( x =
              (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
              (Cx (&2) * Cx a) ) ) ) ` ASSUME_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CUBIC_ROOTS);;
e (ASM_SIMP_TAC []);;
e (POP_ASSUM MP_TAC);;
e (ASM_SIMP_TAC []);;

e (ONCE_REWRITE_TAC [NOT_FORALL_THM]);;
e (DISCH_TAC);;

e (EXISTS_TAC `
          (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
          (Cx (&2) * Cx a)`);;


e (ASM_REWRITE_TAC []);;

    e (REWRITE_TAC[complex_div]);;

    e (REWRITE_TAC[COMPLEX_SUB_RDISTRIB]);;
e (REWRITE_TAC[GSYM CX_MUL]);;
    e (REWRITE_TAC[GSYM CX_INV]);;

e (ONCE_REWRITE_TAC [GSYM CX_POW]);;
e (REWRITE_TAC[GSYM CX_SUB]);;
(*-------------csqrt--(down)--------------*)
 e (SUBGOAL_THEN `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))` ASSUME_TAC);;
e (REWRITE_TAC [EQ_SYM_EQ]);;
e (MATCH_MP_TAC CX_SQRT);;
e (REWRITE_TAC [REAL_LE_LT]);;
e (UNDISCH_TAC `&0 < b1 pow 2 - &4 * a * c1`);;

e (SIMP_TAC []);;
e (UNDISCH_TAC `csqrt (Cx (b1 pow 2 - &4 * a * c1)) = Cx (sqrt (b1 pow 2 - &4 * a * c1))`);;

e (SIMP_TAC []);;

(*-------------csqrt--(up)--------------*)


e (DISCH_TAC);;
e (REWRITE_TAC[GSYM CX_MUL]);;

e (REWRITE_TAC[GSYM CX_SUB]);;
e (REWRITE_TAC[RE_CX]);;
e (ONCE_REWRITE_TAC[REAL_RING `--a * c - (b:real) * c = (--a - b) * c `] );;

e (REWRITE_TAC [NOT_IN_EMPTY]);;
e (REWRITE_TAC[REAL_ENTIRE]);;
e (DISJ1_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(--a - b = &0) = (b = --a)`] );;
e (ASM_REWRITE_TAC []);;


let CUBIC_ALL_MARGINALLY_STABLE_CASES = top_thm();;

(*----------------------------END-----------------------------------*)

