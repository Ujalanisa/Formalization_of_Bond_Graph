
(* ========================================================================= *)
(*                                                                           *)
(*              Formalization of Stability Property                          *)
(*                                                                           *)
(*     (c)  Ujala Qasim                                                      *)
(* 	    SYSTEM ANALYSIS & VERIFICATION (SAVe) LAB                        *)
(*	    National University of Sciences and Technology (NUST), PAKISTAN  *)
(*   Last update: September 20, 2020                                         *)
(*                                                                           *)
(* ========================================================================= *)

(*---------------------------------------------------------------------------*)
(*                          Theories to load                                 *)
(*---------------------------------------------------------------------------*)

needs "Multivariate/cmatrix.ml";;


(* ------------------------------------------------------------------------- *)
(*                      Complex Matrix Definitions                           *)
(* ------------------------------------------------------------------------- *)

let stable_sys = define
   `stable_sys (A:complex^N^N) =
    ~({(c:complex) | cdet(A - c %%% cmat (Cx(&1))) = Cx(&0) /\ Re(c) < (&0)} = EMPTY)`;; 

let unstable_sys = define
   `unstable_sys (A:complex^N^N) =
    ~({(c:complex) | cdet(A - c %%% cmat (Cx(&1))) = Cx(&0) /\ Re(c) > (&0)} = EMPTY)`;; 

let marginally_stable_sys = define
   `marginally_stable_sys (A:complex^N^N) =
    ~({(c:complex) | cdet(A - c %%% cmat (Cx(&1))) = Cx(&0) /\ Re(c) = (&0)} = EMPTY)`;;


(* ------------------------------------------------------------------------- *)
(*                     Condition on Diagonal Element                         *)
(* ------------------------------------------------------------------------- *)

let stable_diagonal_ele_cond = define
   `stable_diagonal_ele_cond (A:complex^N^N) <=>
        (diagonal_cmatrix A \/  lt_cmatrix A \/ ut_cmatrix A)
         ==> (!(c:real^2).(!i. 1 <= i /\ i <= dimindex(:N) ==> (A$i$i = c)) /\ (Re(c) < (&0))) `;;

let unstable_diagonal_ele_cond = define
   `unstable_diagonal_ele_cond (A:complex^N^N) <=>
        (diagonal_cmatrix A \/  lt_cmatrix A \/ ut_cmatrix A)
         ==> (!(c:real^2).(!i. 1 <= i /\ i <= dimindex(:N) ==> (A$i$i = c)) /\ (Re(c) > (&0))) `;;

let marg_stable_diagonal_ele_cond = define
   `marg_stable_diagonal_ele_cond (A:complex^N^N) <=>
        (diagonal_cmatrix A \/  lt_cmatrix A \/ ut_cmatrix A)
         ==> (!(c:real^2).(!i. 1 <= i /\ i <= dimindex(:N) ==> (A$i$i = c)) /\ (Re(c) = (&0))) `;;

(* ------------------------------------------------------------------------- *)
(*                       Complex Determinant Properties                      *)
(* ------------------------------------------------------------------------- *)

g`!A:complex^N^N c.
        ut_cmatrix A 
        ==> cdet(A - c %%% cmat (Cx(&1)) ) =
	cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)))$i$i)`;;

e (REPEAT GEN_TAC);;
e (REWRITE_TAC [ut_cmatrix]);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CDET_UPPERTRIANGULAR);; 
e (REPEAT STRIP_TAC);;
e (SIMP_TAC[GSYM CMAT_CMUL; CMATRIX_SUB_COMPONENT]);;
e (ASM_SIMP_TAC[cmat;LAMBDA_BETA;LT_IMP_NE]);;
e (SIMP_TAC[COMPLEX_SUB_0]);;

let UPPERTRIANGULAR_CMAT_CDET = top_thm();;

(*****************************************************)

g`!A:complex^N^N c .
        lt_cmatrix A 
        ==> cdet(A - c %%% cmat (Cx(&1)) ) =
	cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)))$i$i)`;;

e (REPEAT GEN_TAC);;
e (REWRITE_TAC [lt_cmatrix]);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CDET_LOWERTRIANGULAR);; 
e (REPEAT STRIP_TAC);;
e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT]);;
e (ASM_SIMP_TAC[cmat;LAMBDA_BETA;LT_IMP_NE]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let LOWERTRIANGULAR_CMAT_CDET = top_thm();;

(*****************************************************)

g`!A:complex^N^N c .
        diagonal_cmatrix A 
        ==> cdet(A - c %%% cmat (Cx(&1)) ) =
	cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)`;;

e (REPEAT GEN_TAC);;
e (REWRITE_TAC [diagonal_cmatrix]);;
e (STRIP_TAC);;
e (MATCH_MP_TAC CDET_DIAGONAL);;
e (REWRITE_TAC [diagonal_cmatrix]);;
e (REPEAT STRIP_TAC);;
e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT]);;
e (ASM_SIMP_TAC[cmat;LAMBDA_BETA]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let DIAGONAL_CMAT_CDET = top_thm();;

(*****************************************************)

g`!A:complex^N^N c.
        diagonal_cmatrix A \/ lt_cmatrix A \/ ut_cmatrix A 
        ==> cdet(A - c %%% cmat (Cx(&1)) ) =
	cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)`;;

e (REPEAT GEN_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC DIAGONAL_CMAT_CDET);;
e (ASM_REWRITE_TAC []);;
e (MATCH_MP_TAC LOWERTRIANGULAR_CMAT_CDET);;
e (ASM_REWRITE_TAC []);;
e (MATCH_MP_TAC UPPERTRIANGULAR_CMAT_CDET);;
e (ASM_REWRITE_TAC []);;

let TRIANGULAR_ALL_CASES = top_thm();;


(* ------------------------------------------------------------------------- *)
(*                       Stability Properties                                *)
(* ------------------------------------------------------------------------- *)


g`!(A:complex^N^N). diagonal_cmatrix (A) /\  stable_diagonal_ele_cond A
                 ==> stable_sys A`;;

e (GEN_TAC);;
e (REWRITE_TAC [stable_diagonal_ele_cond; stable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC[IN_ELIM_THM]);;

     e(SUBGOAL_THEN `((cdet ((A:complex^N^N) - c %%% cmat (Cx(&1)) )) =
            cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)) `ASSUME_TAC);;
     e (MATCH_MP_TAC TRIANGULAR_ALL_CASES);;
     e (ASM_REWRITE_TAC[]);;

     e (REWRITE_TAC [NOT_FORALL_THM]);;
     e (EXISTS_TAC`c:complex`);; 
     e (ASM_REWRITE_TAC []);;
     e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT;cmat;LAMBDA_BETA]);;
     e (ASM_SIMP_TAC[]);;
     e (REWRITE_TAC [COMPLEX_SUB_REFL]);;
   
       e (SUBGOAL_THEN `cproduct (1..dimindex (:N)) (\i. Cx (&0)) = Cx (&0)`ASSUME_TAC);;
       e (SIMP_TAC[CPRODUCT_EQ_0_NUMSEG]);;
       e (EXISTS_TAC`1:num`);;
       e (SIMP_TAC[DIMINDEX_GE_1]);;
       e (ARITH_TAC);;
       e (ASM_REWRITE_TAC []);;
       e (REWRITE_TAC [NOT_IN_EMPTY]);;
       
let DIAGONAL_CMAT_STABLE = top_thm();;
     

(****************************************************************)

g`!(A:complex^N^N). lt_cmatrix A /\ stable_diagonal_ele_cond A
                 ==> stable_sys A`;;


e (GEN_TAC);;
e (REWRITE_TAC [stable_diagonal_ele_cond; stable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC[IN_ELIM_THM]);;

     e(SUBGOAL_THEN `((cdet ((A:complex^N^N) - c %%% cmat (Cx(&1)) )) =
            cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)) `ASSUME_TAC);;
     e (MATCH_MP_TAC TRIANGULAR_ALL_CASES);;
     e (ASM_REWRITE_TAC[]);;

     e (REWRITE_TAC [NOT_FORALL_THM]);;
     e (EXISTS_TAC`c:complex`);; 
     e (ASM_REWRITE_TAC []);;
     e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT;cmat;LAMBDA_BETA]);;
     e (ASM_SIMP_TAC[]);;
     e (REWRITE_TAC [COMPLEX_SUB_REFL]);;
   
       e (SUBGOAL_THEN `cproduct (1..dimindex (:N)) (\i. Cx (&0)) = Cx (&0)`ASSUME_TAC);;
       e (SIMP_TAC[CPRODUCT_EQ_0_NUMSEG]);;
       e (EXISTS_TAC`1:num`);;
       e (SIMP_TAC[DIMINDEX_GE_1]);;
       e (ARITH_TAC);;
       e (ASM_REWRITE_TAC []);;
       e (REWRITE_TAC [NOT_IN_EMPTY]);;
       
let LOWERTRIANGULAR_CMAT_STABLE = top_thm();;


(****************************************************************)

g`!(A:complex^N^N). ut_cmatrix (A) /\ stable_diagonal_ele_cond A
                 ==> stable_sys A`;;

e (GEN_TAC);;
e (REWRITE_TAC [stable_diagonal_ele_cond; stable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC[IN_ELIM_THM]);;

     e(SUBGOAL_THEN `((cdet ((A:complex^N^N) - c %%% cmat (Cx(&1)) )) =
            cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)) `ASSUME_TAC);;
     e (MATCH_MP_TAC TRIANGULAR_ALL_CASES);;
     e (ASM_REWRITE_TAC[]);;

     e (REWRITE_TAC [NOT_FORALL_THM]);;
     e (EXISTS_TAC`c:complex`);; 
     e (ASM_REWRITE_TAC []);;
     e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT;cmat;LAMBDA_BETA]);;
     e (ASM_SIMP_TAC[]);;
     e (REWRITE_TAC [COMPLEX_SUB_REFL]);;
   
       e (SUBGOAL_THEN `cproduct (1..dimindex (:N)) (\i. Cx (&0)) = Cx (&0)`ASSUME_TAC);;
       e (SIMP_TAC[CPRODUCT_EQ_0_NUMSEG]);;
       e (EXISTS_TAC`1:num`);;
       e (SIMP_TAC[DIMINDEX_GE_1]);;
       e (ARITH_TAC);;
       e (ASM_REWRITE_TAC []);;
       e (REWRITE_TAC [NOT_IN_EMPTY]);;
       
let UPPERTRIANGULAR_CMAT_STABLE = top_thm();;


(****************************************************************)

g`!(A:complex^N^N). (diagonal_cmatrix (A) \/ lt_cmatrix (A) \/ ut_cmatrix (A)) 
                      /\ stable_diagonal_ele_cond A ==> stable_sys A`;;


e (GEN_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC DIAGONAL_CMAT_STABLE);;
e (ASM_REWRITE_TAC []);;

e (MATCH_MP_TAC LOWERTRIANGULAR_CMAT_STABLE);;
e (ASM_REWRITE_TAC []);;

e (MATCH_MP_TAC UPPERTRIANGULAR_CMAT_STABLE);;
e (ASM_REWRITE_TAC []);;

let STABLE_CASES = top_thm();;



(* ------------------------------------------------------------------------- *)
(*                       Un-Stability Properties                             *)
(* ------------------------------------------------------------------------- *)


g`!(A:complex^N^N). diagonal_cmatrix A /\ unstable_diagonal_ele_cond A
                 ==> unstable_sys A`;;

e (GEN_TAC);;
e (REWRITE_TAC [unstable_diagonal_ele_cond; unstable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC[IN_ELIM_THM]);;

     e(SUBGOAL_THEN `((cdet ((A:complex^N^N) - c %%% cmat (Cx(&1)) )) =
            cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)) `ASSUME_TAC);;
     e (MATCH_MP_TAC TRIANGULAR_ALL_CASES);;
     e (ASM_REWRITE_TAC[]);;

     e (REWRITE_TAC [NOT_FORALL_THM]);;
     e (EXISTS_TAC`c:complex`);; 
     e (ASM_REWRITE_TAC []);;
     e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT;cmat;LAMBDA_BETA]);;
     e (ASM_SIMP_TAC[]);;
     e (REWRITE_TAC [COMPLEX_SUB_REFL]);;
   
       e (SUBGOAL_THEN `cproduct (1..dimindex (:N)) (\i. Cx (&0)) = Cx (&0)`ASSUME_TAC);;
       e (SIMP_TAC[CPRODUCT_EQ_0_NUMSEG]);;
       e (EXISTS_TAC`1:num`);;
       e (SIMP_TAC[DIMINDEX_GE_1]);;
       e (ARITH_TAC);;
       e (ASM_REWRITE_TAC []);;
       e (REWRITE_TAC [NOT_IN_EMPTY]);;
       
let DIAGONAL_CMAT_UNSTABLE = top_thm();;
     

(****************************************************************)

g`!(A:complex^N^N). lt_cmatrix A /\ unstable_diagonal_ele_cond A
                 ==> unstable_sys A`;;


e (GEN_TAC);;
e (REWRITE_TAC [unstable_diagonal_ele_cond; unstable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC[IN_ELIM_THM]);;

     e(SUBGOAL_THEN `((cdet ((A:complex^N^N) - c %%% cmat (Cx(&1)) )) =
            cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)) `ASSUME_TAC);;
     e (MATCH_MP_TAC TRIANGULAR_ALL_CASES);;
     e (ASM_REWRITE_TAC[]);;

     e (REWRITE_TAC [NOT_FORALL_THM]);;
     e (EXISTS_TAC`c:complex`);; 
     e (ASM_REWRITE_TAC []);;
     e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT;cmat;LAMBDA_BETA]);;
     e (ASM_SIMP_TAC[]);;
     e (REWRITE_TAC [COMPLEX_SUB_REFL]);;
   
       e (SUBGOAL_THEN `cproduct (1..dimindex (:N)) (\i. Cx (&0)) = Cx (&0)`ASSUME_TAC);;
       e (SIMP_TAC[CPRODUCT_EQ_0_NUMSEG]);;
       e (EXISTS_TAC`1:num`);;
       e (SIMP_TAC[DIMINDEX_GE_1]);;
       e (ARITH_TAC);;
       e (ASM_REWRITE_TAC []);;
       e (REWRITE_TAC [NOT_IN_EMPTY]);;
       
let LOWERTRIANGULAR_CMAT_UNSTABLE = top_thm();;


(****************************************************************)

g`!(A:complex^N^N). ut_cmatrix (A) /\ unstable_diagonal_ele_cond A
                 ==> unstable_sys A`;;

e (GEN_TAC);;
e (REWRITE_TAC [unstable_diagonal_ele_cond; unstable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC[IN_ELIM_THM]);;

     e(SUBGOAL_THEN `((cdet ((A:complex^N^N) - c %%% cmat (Cx(&1)) )) =
            cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)) `ASSUME_TAC);;
     e (MATCH_MP_TAC TRIANGULAR_ALL_CASES);;
     e (ASM_REWRITE_TAC[]);;

     e (REWRITE_TAC [NOT_FORALL_THM]);;
     e (EXISTS_TAC`c:complex`);; 
     e (ASM_REWRITE_TAC []);;
     e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT;cmat;LAMBDA_BETA]);;
     e (ASM_SIMP_TAC[]);;
     e (REWRITE_TAC [COMPLEX_SUB_REFL]);;
   
       e (SUBGOAL_THEN `cproduct (1..dimindex (:N)) (\i. Cx (&0)) = Cx (&0)`ASSUME_TAC);;
       e (SIMP_TAC[CPRODUCT_EQ_0_NUMSEG]);;
       e (EXISTS_TAC`1:num`);;
       e (SIMP_TAC[DIMINDEX_GE_1]);;
       e (ARITH_TAC);;
       e (ASM_REWRITE_TAC []);;
       e (REWRITE_TAC [NOT_IN_EMPTY]);;
       
let UPPERTRIANGULAR_CMAT_UNSTABLE = top_thm();;


(****************************************************************)

g`!(A:complex^N^N). (diagonal_cmatrix A \/ lt_cmatrix A \/ ut_cmatrix A) 
                      /\ (unstable_diagonal_ele_cond A) 
                         ==> unstable_sys A`;;

e (GEN_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC DIAGONAL_CMAT_UNSTABLE);;
e (ASM_REWRITE_TAC []);;

e (MATCH_MP_TAC LOWERTRIANGULAR_CMAT_UNSTABLE);;
e (ASM_REWRITE_TAC []);;

e (MATCH_MP_TAC UPPERTRIANGULAR_CMAT_UNSTABLE);;
e (ASM_REWRITE_TAC []);;

let UNSTABLE_CASES = top_thm();;


(* ------------------------------------------------------------------------- *)
(*                     Mrginal Stability Properties                          *)
(* ------------------------------------------------------------------------- *)


g`!(A:complex^N^N). diagonal_cmatrix A /\ marg_stable_diagonal_ele_cond A
                 ==> marginally_stable_sys A`;;

e (GEN_TAC);;
e (REWRITE_TAC [marg_stable_diagonal_ele_cond; marginally_stable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC[IN_ELIM_THM]);;

     e(SUBGOAL_THEN `((cdet ((A:complex^N^N) - c %%% cmat (Cx(&1)) )) =
            cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)) `ASSUME_TAC);;
     e (MATCH_MP_TAC TRIANGULAR_ALL_CASES);;
     e (ASM_REWRITE_TAC[]);;

     e (REWRITE_TAC [NOT_FORALL_THM]);;
     e (EXISTS_TAC`c:complex`);; 
     e (ASM_REWRITE_TAC []);;
     e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT;cmat;LAMBDA_BETA]);;
     e (ASM_SIMP_TAC[]);;
     e (REWRITE_TAC [COMPLEX_SUB_REFL]);;
   
       e (SUBGOAL_THEN `cproduct (1..dimindex (:N)) (\i. Cx (&0)) = Cx (&0)`ASSUME_TAC);;
       e (SIMP_TAC[CPRODUCT_EQ_0_NUMSEG]);;
       e (EXISTS_TAC`1:num`);;
       e (SIMP_TAC[DIMINDEX_GE_1]);;
       e (ARITH_TAC);;
       e (ASM_REWRITE_TAC []);;
       e (REWRITE_TAC [NOT_IN_EMPTY]);;
       
let DIAGONAL_CMAT_MARG_STABLE = top_thm();;
     

(****************************************************************)

g`!(A:complex^N^N). lt_cmatrix A /\ marg_stable_diagonal_ele_cond A
                 ==> marginally_stable_sys A`;;


e (GEN_TAC);;
e (REWRITE_TAC [marg_stable_diagonal_ele_cond; marginally_stable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC[IN_ELIM_THM]);;

     e(SUBGOAL_THEN `((cdet ((A:complex^N^N) - c %%% cmat (Cx(&1)) )) =
            cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)) `ASSUME_TAC);;
     e (MATCH_MP_TAC TRIANGULAR_ALL_CASES);;
     e (ASM_REWRITE_TAC[]);;

     e (REWRITE_TAC [NOT_FORALL_THM]);;
     e (EXISTS_TAC`c:complex`);; 
     e (ASM_REWRITE_TAC []);;
     e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT;cmat;LAMBDA_BETA]);;
     e (ASM_SIMP_TAC[]);;
     e (REWRITE_TAC [COMPLEX_SUB_REFL]);;
   
       e (SUBGOAL_THEN `cproduct (1..dimindex (:N)) (\i. Cx (&0)) = Cx (&0)`ASSUME_TAC);;
       e (SIMP_TAC[CPRODUCT_EQ_0_NUMSEG]);;
       e (EXISTS_TAC`1:num`);;
       e (SIMP_TAC[DIMINDEX_GE_1]);;
       e (ARITH_TAC);;
       e (ASM_REWRITE_TAC []);;
       e (REWRITE_TAC [NOT_IN_EMPTY]);;
       
let LOWERTRIANGULAR_CMAT_MARG_STABLE = top_thm();;


(****************************************************************)

g`!(A:complex^N^N). ut_cmatrix (A) /\ marg_stable_diagonal_ele_cond A
                 ==> marginally_stable_sys A`;;

e (GEN_TAC);;
e (REWRITE_TAC [marg_stable_diagonal_ele_cond; marginally_stable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC[IN_ELIM_THM]);;

     e(SUBGOAL_THEN `((cdet ((A:complex^N^N) - c %%% cmat (Cx(&1)) )) =
            cproduct (1..dimindex(:N)) (\i. (A - c %%% cmat (Cx(&1)) )$i$i)) `ASSUME_TAC);;
     e (MATCH_MP_TAC TRIANGULAR_ALL_CASES);;
     e (ASM_REWRITE_TAC[]);;

     e (REWRITE_TAC [NOT_FORALL_THM]);;
     e (EXISTS_TAC`c:complex`);; 
     e (ASM_REWRITE_TAC []);;
     e (SIMP_TAC[GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT;cmat;LAMBDA_BETA]);;
     e (ASM_SIMP_TAC[]);;
     e (REWRITE_TAC [COMPLEX_SUB_REFL]);;
   
       e (SUBGOAL_THEN `cproduct (1..dimindex (:N)) (\i. Cx (&0)) = Cx (&0)`ASSUME_TAC);;
       e (SIMP_TAC[CPRODUCT_EQ_0_NUMSEG]);;
       e (EXISTS_TAC`1:num`);;
       e (SIMP_TAC[DIMINDEX_GE_1]);;
       e (ARITH_TAC);;
       e (ASM_REWRITE_TAC []);;
       e (REWRITE_TAC [NOT_IN_EMPTY]);;
       
let UPPERTRIANGULAR_CMAT_MARG_STABLE = top_thm();;


(****************************************************************)

g`!(A:complex^N^N). (diagonal_cmatrix A \/ lt_cmatrix A \/ ut_cmatrix A) 
                      /\ (marg_stable_diagonal_ele_cond A) 
                         ==> marginally_stable_sys A`;;

e (GEN_TAC);;
e (STRIP_TAC);;
e (MATCH_MP_TAC DIAGONAL_CMAT_MARG_STABLE);;
e (ASM_REWRITE_TAC []);;

e (MATCH_MP_TAC LOWERTRIANGULAR_CMAT_MARG_STABLE);;
e (ASM_REWRITE_TAC []);;

e (MATCH_MP_TAC UPPERTRIANGULAR_CMAT_MARG_STABLE);;
e (ASM_REWRITE_TAC []);;

let MARG_STABLE_CASES = top_thm();;


(****************************************************************)

g`!(A:complex^N^N).
   (diagonal_cmatrix A \/ lt_cmatrix A \/ ut_cmatrix A) /\ 
    (stable_diagonal_ele_cond A \/ unstable_diagonal_ele_cond A \/
      marg_stable_diagonal_ele_cond A) 
       ==> (stable_sys A \/ unstable_sys A \/ marginally_stable_sys A)`;;

e (GEN_TAC);;
e (STRIP_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC STABLE_CASES);;
e (ASM_REWRITE_TAC []);;
e (DISJ2_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC UNSTABLE_CASES);;
e (ASM_REWRITE_TAC []);;
e (DISJ2_TAC);;
e (DISJ2_TAC);;
e (MATCH_MP_TAC MARG_STABLE_CASES);;
e (ASM_REWRITE_TAC []);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC STABLE_CASES);;
e (ASM_REWRITE_TAC []);;
e (DISJ2_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC UNSTABLE_CASES);;
e (ASM_REWRITE_TAC []);;
e (DISJ2_TAC);;
e (DISJ2_TAC);;
e (MATCH_MP_TAC MARG_STABLE_CASES);;
e (ASM_REWRITE_TAC []);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC STABLE_CASES);;
e (ASM_REWRITE_TAC []);;
e (DISJ2_TAC);;
e (DISJ1_TAC);;
e (MATCH_MP_TAC UNSTABLE_CASES);;
e (ASM_REWRITE_TAC []);;
e (DISJ2_TAC);;
e (DISJ2_TAC);;
e (MATCH_MP_TAC MARG_STABLE_CASES);;
e (ASM_REWRITE_TAC []);;

let TRIANGULAR_CMAT_STABILITY =  top_thm();;

(* ------------------------------------------------------------------------- *)
(*                   Hermitian and skew-Hermitian matrices                   *)
(* ------------------------------------------------------------------------- *)


let hermitian_cmatrix = new_definition
 `hermitian_cmatrix (A:complex^N^N) <=>  conj_ctransp A = A`;;


let skew_hermitian_cmatrix = new_definition
 `skew_hermitian_cmatrix (A:complex^N^N) <=> (conj_ctransp A) = -- A`;;


let stable_hermitian_cond = define
   `stable_hermitian_cond (A:complex^N^N) <=>
       (hermitian_cmatrix A 
        ==> (!(c:real^2).(Im(c) = &0) /\ (Re(c) < &0)))`;; 
 

let unstable_hermitian_cond = define
   `unstable_hermitian_cond (A:complex^N^N) <=>
       (hermitian_cmatrix A 
        ==> (!(c:real^2).(Im(c) = &0) /\ (Re(c) > &0)))`;; 
 

let marg_stable_hermitian_cond = define
   `marg_stable_hermitian_cond (A:complex^N^N) <=>
       (hermitian_cmatrix A 
        ==> (!(c:real^2).(Im(c) = &0) /\ (Re(c) = &0)))`;;  


let skew_hermitian_cond = define
   `skew_hermitian_cond (A:complex^N^N) <=>
       (skew_hermitian_cmatrix A ==> (!(c:real^2).(Re(c) = &0)))`;;

   
(*****************************************************)

g`!(A:complex^N^N) .((hermitian_cmatrix A) /\ 
                    ((unstable_hermitian_cond A) \/ (marg_stable_hermitian_cond A))) \/
                    ((skew_hermitian_cmatrix A) /\ (skew_hermitian_cond A)) 
                      ==> ~ stable_sys A`;;

e (GEN_TAC);;
e (REWRITE_TAC [unstable_hermitian_cond;marg_stable_hermitian_cond; skew_hermitian_cond ;stable_sys]);;
e (STRIP_TAC);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC [EMPTY;IN_ELIM_THM]);;
e (REWRITE_TAC [DE_MORGAN_THM]);;
e (X_GEN_TAC `c:complex`);;
e (DISJ2_TAC);;
e (MATCH_MP_TAC REAL_LT_GT);;
e (REWRITE_TAC[SIMPLE_COMPLEX_ARITH `(&0 < Re c)= (Re c > &0)`]);;
e (ASM_SIMP_TAC []);;
e (SIMP_TAC [EXTENSION]);;
  e (REWRITE_TAC [EMPTY;IN_ELIM_THM]);;
  e (REWRITE_TAC [DE_MORGAN_THM]);;
  e (X_GEN_TAC `c:complex`);;
  e (DISJ2_TAC);;
  e (REWRITE_TAC [REAL_NOT_LT;REAL_LE_LT]);;
  e (DISJ2_TAC);;
  e (ASM_SIMP_TAC[EQ_SYM_EQ]);;
e (SIMP_TAC [EXTENSION]);;
  e (REWRITE_TAC [EMPTY;IN_ELIM_THM]);;
  e (REWRITE_TAC [DE_MORGAN_THM]);;
  e (X_GEN_TAC `c:complex`);;
  e (DISJ2_TAC);;
  e (REWRITE_TAC [REAL_NOT_LT;REAL_LE_LT]);;
  e (DISJ2_TAC);;
  e (ASM_SIMP_TAC[EQ_SYM_EQ]);;


let HERM_NOT_STABLE_CASES = top_thm();;





