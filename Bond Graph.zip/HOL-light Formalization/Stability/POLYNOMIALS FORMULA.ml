(******************************************************)
(***************HOL-Light Code*************************)
(**********Formal Stability Analysis*******************)
(*************of Control Systems***********************)
(******************************************************)
(******************************************************)
(*----------------------------------------------------*)
(*-----Asad Ahmed-------------------------------------*)
(*-----Ph.D, Candidate--------------------------------*)
(*-----National university of Sciences and Technology,*)
(*-----NUST, SEECS, Islamabad, Pakistan---------------*)
(*----------------------------------------------------*)
#use "hol.ml";;
needs "Multivariate/complexes.ml";;
needs "Multivariate/realanalysis.ml";;
needs "Library/analysis.ml";;

let REAL_10 = REAL_ARITH `~(&1 = &0)`;;

(*********************************************)
g `!x. ~(x = &0) ==> ~(inv x = &0)`;;

e (GEN_TAC THEN DISCH_TAC);;
e ( DISCH_THEN(MP_TAC o AP_TERM ` (*) (x:real)`));;
e  (ASM_SIMP_TAC [REAL_MUL_RZERO]);;
  e (SUBGOAL_THEN `(x * inv x)=(&1)`ASSUME_TAC);;
  e (MATCH_MP_TAC REAL_MUL_RINV);;
  e (ASM_SIMP_TAC []);;
e (PURE_ASM_SIMP_TAC []);;
e (SIMP_TAC [REAL_10]);;

let REAL_INV_NZ = top_thm();;

(*********************************************)

let REAL_INV_POS = prove(
  `!x. &0 < x ==> &0 < inv x`,
  GEN_TAC THEN DISCH_TAC THEN REPEAT_TCL DISJ_CASES_THEN
   MP_TAC (SPECL [`inv x:real`; `&0`] REAL_LT_TOTAL) THENL
   [POP_ASSUM(ASSUME_TAC o MATCH_MP REAL_INV_NZ o
              GSYM o MATCH_MP REAL_LT_IMP_NE) THEN ASM_REWRITE_TAC[];
    ONCE_REWRITE_TAC[GSYM REAL_NEG_GT0] THEN
    DISCH_THEN(MP_TAC o MATCH_MP REAL_LT_MUL o C CONJ (ASSUME `&0 < x`)) THEN
    REWRITE_TAC[GSYM REAL_NEG_LMUL] THEN
    POP_ASSUM(fun th -> REWRITE_TAC
     [MATCH_MP REAL_MUL_LINV (GSYM (MATCH_MP REAL_LT_IMP_NE th))]) THEN
    REWRITE_TAC[REAL_NEG_GT0] THEN DISCH_THEN(MP_TAC o CONJ REAL_LT_01) THEN
    REWRITE_TAC[REAL_LT_ANTISYM];
    REWRITE_TAC[]]);;

(**************************************)

g `!x. &0 <= x pow 2`;;

e (STRIP_TAC);;
e (ONCE_REWRITE_TAC [GSYM REAL_POW2_ABS]);;
e (SUBGOAL_THEN `&0 = &0 pow 2` ASSUME_TAC);;
e (REWRITE_TAC [REAL_POW_ZERO]);;
e (COND_CASES_TAC);;
e (UNDISCH_TAC `2 = 0`);;
e (ARITH_TAC);;
e (REWRITE_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (MATCH_MP_TAC REAL_POW_LE2);;
e (CONJ_TAC);;
e (ARITH_TAC);;
e (ARITH_TAC);;

let REAL_POS_POW2 = top_thm();;
(*--------------DENOM_LT_0----(Down)-----------------*)
g ` ! (x:real)(y:real)(z:real).
	((y < &0)) ==> ((x / y < z) = ( y * z < x))`;;

e (REPEAT GEN_TAC);;
e (STRIP_TAC);;

e (REWRITE_TAC []);;
(*--e (RW_TAC real_ss[REAL_LT_RDIV_EQ]);---*)
 e (SUBGOAL_THEN `(y = -- (abs y))` ASSUME_TAC);;
 e (SUBGOAL_THEN `~(&0 <= y)` ASSUME_TAC);;
e (REWRITE_TAC [REAL_NOT_LE]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (REWRITE_TAC [real_abs]);;
e (COND_CASES_TAC);;
e (ASM_MESON_TAC []);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
 e (SUBGOAL_THEN `~(abs y = &0)` ASSUME_TAC);;
e (MATCH_MP_TAC REAL_LT_IMP_NZ);;
e (UNDISCH_TAC `y = --abs y`);;
e (SIMP_TAC [EQ_SYM]);;
e (SIMP_TAC [GSYM REAL_LNEG_UNIQ]);;
e (ONCE_REWRITE_TAC [REAL_ADD_SYM]);;
e (SIMP_TAC [REAL_LNEG_UNIQ]);;
e (SIMP_TAC [REAL_NEG_EQ]);;
e (SIMP_TAC [REAL_NEG_NEG]);;
e (DISCH_TAC);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = -- &0`] );;
e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ASM_MESON_TAC []);;

 e (SUBGOAL_THEN `( &0 < abs y )` ASSUME_TAC);;
e (UNDISCH_TAC `y = --abs y`);;
e (SIMP_TAC [EQ_SYM]);;
e (SIMP_TAC [GSYM REAL_LNEG_UNIQ]);;
e (ONCE_REWRITE_TAC [REAL_ADD_SYM]);;
e (SIMP_TAC [REAL_LNEG_UNIQ]);;
e (SIMP_TAC [REAL_NEG_EQ]);;
e (DISCH_TAC);;

e (ONCE_REWRITE_TAC[REAL_RING `&0 = -- &0`] );;
e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (ASM_MESON_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [real_div]);;
e (ONCE_REWRITE_TAC [REAL_INV_NEG]);;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_LMUL]);;
e (ONCE_REWRITE_TAC [REAL_NEG_RMUL]);;
e (ONCE_REWRITE_TAC [REAL_MUL_SYM]);;
e (UNDISCH_TAC `&0 < abs y`);;
e (SIMP_TAC [GSYM REAL_LT_RDIV_EQ]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM REAL_LT_NEG2]);;

e (ONCE_REWRITE_TAC [real_div]);;


e (ONCE_REWRITE_TAC [GSYM REAL_NEG_LMUL]);;
e (EQ_TAC);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC[REAL_ARITH `(--(z * abs y) > x) <=> (x < --(z * abs y))`]);;
e (ONCE_REWRITE_TAC [REAL_LT_NEG2]);;
e (UNDISCH_TAC `--z < -- --(inv (abs y) * x)`);;
e (SIMP_TAC [REAL_NEG_NEG]);;
e (REAL_ARITH_TAC);;
e (ONCE_REWRITE_TAC [REAL_NEG_NEG]);;

e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM REAL_NEG_NEG]);;
e (ONCE_REWRITE_TAC [REAL_LT_NEG22]);;
e (ONCE_REWRITE_TAC [REAL_NEG_NEG]);;
e (ONCE_REWRITE_TAC [REAL_MUL_SYM]);;

e (UNDISCH_TAC `--(x * inv (abs y)) < z`);;
e (REAL_ARITH_TAC);;
let DENOM_LT_0 = top_thm();;
(*--------------DENOM_LT_0----(Up)-----------------*)






(*-------------------Supplimentary Proves----------------------------------------------*)
(*-------------------COMPLEX_EQ_RDIV_EQ----------------------------------------------*)

g `!x y z. (~(z = Cx(&0)) ) ==> ( (x = y / z )<=> (x * z =  y) )`;;
 
e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (EQ_TAC);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((x * z) = y) = ((x *z) = (y * Cx (&1)))`]);;
e (SUBGOAL_THEN `Cx (&1) = (z / z)` ASSUME_TAC);;
       e (REWRITE_TAC [complex_div]);;
       e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
       e (MATCH_MP_TAC COMPLEX_MUL_RINV);;
       e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `Cx (&1) = z / z`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (REWRITE_TAC [complex_div]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

e (DISCH_TAC);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `( (x = y / z ) =  (x * Cx (&1) = y / z))`]);;
e (SUBGOAL_THEN `Cx (&1) = (z / z)` ASSUME_TAC);;
       e (REWRITE_TAC [complex_div]);;
       e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
       e (MATCH_MP_TAC COMPLEX_MUL_RINV);;
       e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `Cx (&1) = z / z`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (REWRITE_TAC [complex_div]);;


e (ONCE_REWRITE_TAC [COMPLEX_MUL_ASSOC]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let  COMPLEX_EQ_RDIV_EQ = top_thm();;


(*-------------------COMPLEX_EQ_LDIV_EQ--------------------------*)

g `!x y z. (~(z = Cx(&0)) ) ==> ( (x / z = y )<=> (x = z * y) )`;;
 
e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (EQ_TAC);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((x = z * y) =((x * Cx(&1)) = z * y) )`]);;
e (SUBGOAL_THEN `Cx (&1) = (z / z)` ASSUME_TAC);;
       e (REWRITE_TAC [complex_div]);;
       e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
       e (MATCH_MP_TAC COMPLEX_MUL_RINV);;
       e (ASM_REWRITE_TAC []);;
e (UNDISCH_TAC `Cx (&1) = z / z`);;
e (SIMP_TAC []);;
e (DISCH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (REWRITE_TAC [complex_div]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;

e (SUBGOAL_THEN `x * (z:complex) * inv z = (x * inv z)* z` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (REWRITE_TAC [GSYM complex_div]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

e (DISCH_TAC);;
e (REWRITE_TAC [complex_div]);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (SUBGOAL_THEN `(z * (y:complex) * inv z)=( (z * inv z )* y )` ASSUME_TAC);;
 
e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;

e (SIMPLE_COMPLEX_ARITH_TAC);;
e (ONCE_ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `(z * inv z = Cx (&1))` ASSUME_TAC);;
  e (UNDISCH_TAC `~(z = Cx (&0))`);;
  e (ONCE_REWRITE_TAC [COMPLEX_MUL_RINV]);;

e (ONCE_ASM_REWRITE_TAC []);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let COMPLEX_EQ_LDIV_EQ = top_thm();;


(*------------COMPLEX_SQRT_EQ_2------------------------------*)

g `!(x:complex) y. (x = y) ==> (csqrt (x) = csqrt (y))`;;
 e (ASM_MESON_TAC []);;
let COMPLEX_CSQRT_EQ_2=top_thm();;
(*------------COMPLEX_EQ_SQR_EQ------------------------------*)
g `!(x:complex) y. (x = y) ==> ( ((x)pow 2) = ((y) pow 2) )`;;
 e (ASM_MESON_TAC []);;
let COMPLEX_EQ_CSQR_EQ =top_thm();;
(*-------------CX_IM_0_PROD-----------------------------------*)
g `!(x:complex) y.((Im y = &0) /\ (Im x = &0))
   		 ==> (Re (x * y) = Re (x)* Re (y))`;;
		 e (REPEAT STRIP_TAC);;
		 e (REWRITE_TAC [ complex_mul]);;
		 e (REWRITE_TAC [RE]);;
		 e (UNDISCH_TAC `Im x = &0`);;
 		 e (SIMP_TAC []);;0123
 		 e (DISCH_TAC);;
		 e (SIMPLE_COMPLEX_ARITH_TAC);;
let CX_IM_0_PROD =top_thm();;
(*...................................................................*)
  (*................................................................*)
    (*=============================================================*)
    (*                     a*a*a = a pow 3	                   *)
    (*=============================================================*)
  (*................................................................*)
(*...................................................................*)
g `!(x:real). ( (x * x * x )=((x) pow 3 ) )`;;
e (GEN_TAC);;

 e (SUBGOAL_THEN `((3:num) = 2 + 1)` ASSUME_TAC);;
e (ARITH_TAC);;
e (ONCE_REWRITE_TAC[ARITH_TAC `((3:num) = 2 + 1)`] );;
e (UNDISCH_TAC `3 = 2 + 1`);;

e (SIMP_TAC[] );;
e (DISCH_TAC);;
 e (ONCE_REWRITE_TAC[REAL_POW_ADD] );;
 e (ONCE_REWRITE_TAC[REAL_POW_2] );;
 e (ONCE_REWRITE_TAC[REAL_POW_1] );;
e (REAL_ARITH_TAC);;
  let REAL_POW_3 = top_thm();;
(*...................................................................*)
  (*................................................................*)
    (*=============================================================*)
    (*                     a*a*a = a pow 3	                   *)
    (*=============================================================*)
  (*................................................................*)
(*...................................................................*)
g `!(x:complex). ( (x * x * x )=((x) pow 3 ) )`;;
e (GEN_TAC);;

 e (SUBGOAL_THEN `((3:num) = 2 + 1)` ASSUME_TAC);;
e (ARITH_TAC);;
e (ONCE_REWRITE_TAC[COMPLEX_FIELD `((3:num) = 2 + 1)`] );;
e (UNDISCH_TAC `3 = 2 + 1`);;

e (SIMP_TAC[] );;
e (DISCH_TAC);;
 e (ONCE_REWRITE_TAC[COMPLEX_POW_ADD] );;
 e (ONCE_REWRITE_TAC[COMPLEX_POW_2] );;
 e (ONCE_REWRITE_TAC[COMPLEX_POW_1] );;
e (SIMPLE_COMPLEX_ARITH_TAC);;
  let COMPLEX_POW_3 = top_thm();;

(*---------------------------Quadratic Formula---------------------------*)



g `!a b c s. ~(Cx (&0) = Cx (a)) ==> 
( ((Cx(a) * (s pow 2 )) + (Cx (b) * (s)) + Cx (c) = Cx (&0))
 <=>  ( (s = ( ( Cx (--b) + csqrt ( ((Cx (b)) pow 2) - (Cx (&4))*(Cx (a))*(Cx (c))  )  )/ ((Cx (&2))* (Cx (a))) ) )\/
      (s = ( ( Cx (--b) - csqrt ( ((Cx (b)) pow 2) - (Cx (&4))*(Cx (a))*(Cx (c))  )  )/ ((Cx (&2))* (Cx (a))) ) ) ) )`;; 

e (REPEAT GEN_TAC);;
e (STRIP_TAC);;
e (EQ_TAC);;
e (DISCH_TAC);;
e (SUBGOAL_THEN `( s + (Cx b) * inv (Cx (&2) * (Cx a))) pow 2 =
  		((Cx b pow 2 - Cx (&4) * Cx (a) * Cx (c))* inv (Cx (&4) * (Cx (a) ) pow 2)) ` ASSUME_TAC);;
  e (ONCE_REWRITE_TAC [COMPLEX_POW_2]);;		
  e (ONCE_REWRITE_TAC [COMPLEX_ADD_LDISTRIB]);;		
  e (ONCE_REWRITE_TAC [ COMPLEX_ADD_RDISTRIB]);;		
  e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_2]);;
  e (ONCE_REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;
  e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL]);;
  e (ONCE_REWRITE_TAC [COMPLEX_INV_MUL]);;
  e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL]);;
  e (ONCE_REWRITE_TAC [COMPLEX_POW_INV]);;
  e (ONCE_REWRITE_TAC [COMPLEX_POW_2]);;
  e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_2]);;
  e (SUBGOAL_THEN ` ( inv (Cx (&2) pow 2) = inv (Cx (&4)) )` ASSUME_TAC);;
     e (ONCE_REWRITE_TAC [COMPLEX_POW_2]);;
    e (SIMPLE_COMPLEX_ARITH_TAC);;
  e (UNDISCH_TAC `inv (Cx (&2) pow 2) = inv (Cx (&4))`);;
  e (SIMP_TAC []);;
  e (DISCH_TAC);;
  e (POP_ASSUM (K ALL_TAC));;
  e (ONCE_REWRITE_TAC [COMPLEX_SUB_RDISTRIB]);;
  e (ONCE_REWRITE_TAC [COMPLEX_ADD_ASSOC]);;
  e (ONCE_REWRITE_TAC [GSYM COMPLEX_EQ_SUB_LADD]);;
  e (ONCE_REWRITE_TAC [COMPLEX_ADD_RINV]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((a:complex) - b - (c + d) = a - b - c - d)`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `( (a:complex) - b - c - a = --b + --c  )`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `( ((a:complex)*b*c)*d*e = (a*d)*(b*e)*c  )`]);;
  e (ONCE_REWRITE_TAC [COMPLEX_POW_2]);;
  e (ONCE_REWRITE_TAC [COMPLEX_INV_MUL]);;
  e (SUBGOAL_THEN `~(Cx (&4) = Cx (&0))` ASSUME_TAC);;
    e (SIMPLE_COMPLEX_ARITH_TAC);;
  e (UNDISCH_TAC `~(Cx (&4) = Cx (&0))`);;
  e (SIMP_TAC [COMPLEX_MUL_RINV]);;
  e (DISCH_TAC);;
  e (POP_ASSUM (K ALL_TAC));;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&1) * (a:complex) = a)`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `( ((a:complex)*b*c)*d = a * d * (b * c)  )`]);;
  e (UNDISCH_TAC `~(Cx (&0) = Cx a)`);;
  e (SIMP_TAC [EQ_SYM_EQ]);;
  e (SIMP_TAC [COMPLEX_MUL_RINV]);;
  e (DISCH_TAC);;
  
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `( (a:complex) * b * c * d = b * d * (a * c)) `]);;
  e (UNDISCH_TAC `~(Cx a = Cx (&0))`);;
  e (SIMP_TAC [EQ_SYM_EQ]);;
  e (SIMP_TAC [COMPLEX_MUL_RINV]);;
  e (DISCH_TAC);;
  
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((a:complex) * b * (Cx (&1)) = a * b)`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) + b  = --c + --d)=
    		      			    		  (a + b + c + d = Cx (&0)))`]);;
  e (SUBGOAL_THEN `(Cx b * inv (Cx a) * s * inv (Cx (&2))) = (s * inv (Cx a) * Cx b * inv (Cx (&2)))` ASSUME_TAC);;
      e (SIMPLE_COMPLEX_ARITH_TAC);;
  e (UNDISCH_TAC `Cx b * inv (Cx a) * s * inv (Cx (&2)) =
      s * inv (Cx a) * Cx b * inv (Cx (&2))`);;
  e (SIMP_TAC []);;
  e (DISCH_TAC);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) + b + c + d = a + c + (b + d)))`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(( a + c + b + b) = a + c + Cx (&2)*b )`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `( (a:complex)*b*c*d = b * (c * d)* a)`]);;

  e (SUBGOAL_THEN `~(Cx (&2) = Cx (&0))` ASSUME_TAC);;
    e (SIMPLE_COMPLEX_ARITH_TAC);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `( (a:complex)*(b*c*d)*e = a * b * c * (e * d ) )`]);;
  e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
  e (SIMP_TAC [COMPLEX_MUL_RINV]);;
  e (DISCH_TAC);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) + b + c ) =(a + b + c) * (Cx (&1)) )`]);;
  
  e (SUBGOAL_THEN `Cx (a) * inv (Cx (a)) = Cx (&1)` ASSUME_TAC);;
    e (UNDISCH_TAC `~(Cx a = Cx (&0))`);;
    e (SIMP_TAC [COMPLEX_MUL_RINV]);;
  e (UNDISCH_TAC `Cx a * inv (Cx a) = Cx (&1)`);;
  e (SIMP_TAC [EQ_SYM_EQ]);;
  e (DISCH_TAC);;
  e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
  e (DISCH_TAC);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) + b) * c * d) = (((a + b) * c) * d )`]);;


  e (ONCE_REWRITE_TAC [GSYM complex_div]);;
   e (UNDISCH_TAC `~(Cx a = Cx (&0))`);;
   e (SIMP_TAC [COMPLEX_EQ_LDIV_EQ]);;
    e (SIMP_TAC [COMPLEX_MUL_RINV]);;

  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((a:complex) * b * (Cx (&1)) = a * b)`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((a:complex) * (Cx (&0)) = (Cx (&0)))`]);;
  e (DISCH_TAC);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) + b + c) * d) = (a * d + b * d + c * d )`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) + b + c) * d) = (a * d + b * d + c * d )`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) * b * c)*d) = (a*(d*b)*c)`]);;
  
  
    e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_2]);;
 e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) * b) * c) = ((c*b)*a)`]);;
  
  e (UNDISCH_TAC `~(Cx a = Cx (&0))`);;
  e (SIMP_TAC [COMPLEX_MUL_RINV]);;
   e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) *b)*c) = ((b*c)*a)`]);;
e (UNDISCH_TAC `~(Cx a = Cx (&0))`);;
  e (SIMP_TAC [COMPLEX_MUL_LINV]);;  
 e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx(&1) * (a:complex) ) = (a)`]);;
e (DISCH_TAC);;
 e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((a:complex)*b + c + d*e ) = (b*a + e*d+c)`]);;
  e (UNDISCH_TAC `Cx a * s pow 2 + Cx b * s + Cx c = Cx (&0)`);;
  e (SIMP_TAC []);;  
   e (UNDISCH_TAC `(s + Cx b * inv (Cx (&2) * Cx a)) pow 2 =
      (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&4) * Cx a pow 2)`);;
  e (ONCE_REWRITE_TAC [GSYM COMPLEX_SUB_0]);;  
  
 e (SUBGOAL_THEN `((Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&4) * Cx a pow 2) )
   		 = ((csqrt ((Cx b pow 2 - Cx (&4) * Cx a * Cx c))) * inv (Cx (&2) * Cx a)) pow 2` ASSUME_TAC);;
 e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL]);;
e (ONCE_REWRITE_TAC [CSQRT]);;
 e (ONCE_REWRITE_TAC [COMPLEX_POW_INV]);;
 e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL]);;
e (ONCE_REWRITE_TAC [COMPLEX_POW_2]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((Cx (&2) * Cx (&2))) = (Cx (&4))`]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
  e (ONCE_ASM_REWRITE_TAC []);;
   e (ONCE_REWRITE_TAC [COMPLEX_POW_2]);; 
 e (ONCE_REWRITE_TAC [GSYM COMPLEX_DIFFSQ]);; 
e (ONCE_REWRITE_TAC [COMPLEX_MUL_SYM]);;
 e (ONCE_REWRITE_TAC [ COMPLEX_ENTIRE]);; 
 e (ONCE_REWRITE_TAC [complex_div]);; 
e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);; 
e (ONCE_REWRITE_TAC [CX_NEG]);;
e (DISCH_TAC);;
 e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((a:complex) - (--c*b + d )) = (a + c*b - d)`]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(a - ( --c - d) * e) =
    		      			 ((a:complex) + c*e + d*e )`]);;

e (UNDISCH_TAC `(s + Cx b * inv (Cx (&2) * Cx a)) -
      csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a) =
      Cx (&0) \/
      (s + Cx b * inv (Cx (&2) * Cx a)) +
      csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a) =
      Cx (&0)`);;
  e (SIMP_TAC []);;
e (ONCE_ASM_REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` ((a + b) + c) = ((a:complex) + b + c) `]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` ((a + b) - c) = ((a:complex) + b - c) `]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` ((a *  b) * c) = c * ((a:complex) *  b ) `]);;
e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_2]);;
e (SUBGOAL_THEN `(Cx a * Cx (&2)) = (Cx (&2) * (Cx a))` ASSUME_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
 e (UNDISCH_TAC `Cx a * Cx (&2) = Cx (&2) * Cx a`);;
  e (SIMP_TAC []);; 
e (DISCH_TAC);;
e (POP_ASSUM (K ALL_TAC));;
e (ONCE_ASM_REWRITE_TAC []);;
(*---------------------------Part 2-------------------------------*)
 e (ONCE_REWRITE_TAC [COMPLEX_ADD_ASSOC ]);;
 e (ONCE_REWRITE_TAC [COMPLEX_LNEG_UNIQ]);;

 e (SUBGOAL_THEN `Cx (&1) = inv (Cx a) * inv (inv (Cx a)) ` ASSUME_TAC);;
    e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
    e (ONCE_REWRITE_TAC [COMPLEX_INV_INV]);;		  
    e (MATCH_MP_TAC COMPLEX_MUL_LINV);;
    e (ONCE_ASM_REWRITE_TAC []);;
    
    e (SIMPLE_COMPLEX_ARITH_TAC);;
    e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH ` (Cx a * s pow 2 + Cx b * s = --Cx c) =
    		      			    (Cx a * s pow 2 + Cx b * s) * (Cx (&1)) = --Cx c `]);;
    e (UNDISCH_TAC `Cx (&1) = inv (Cx a) * inv (inv (Cx a))`);;
    e (SIMP_TAC []);;
 e (DISCH_TAC);;
 e (POP_ASSUM (K ALL_TAC));;
 
 e (SUBGOAL_THEN `(Cx a * s pow 2 + Cx b * s) * inv (Cx a) * inv (inv (Cx a)) =
   ((Cx a * s pow 2 + Cx b * s) * inv (Cx a)) / (inv (Cx a)) 
   ` ASSUME_TAC);;
     e (ONCE_REWRITE_TAC [complex_div]);;		  
     e (SIMPLE_COMPLEX_ARITH_TAC);;
 e (UNDISCH_TAC `(Cx a * s pow 2 + Cx b * s) * inv (Cx a) * inv (inv (Cx a)) =
      ((Cx a * s pow 2 + Cx b * s) * inv (Cx a)) / inv (Cx a)`);;
 e (SIMP_TAC []);;
 e (DISCH_TAC);;

 e (POP_ASSUM (K ALL_TAC));;
  
 e (SUBGOAL_THEN `~(inv (Cx a) = Cx (&0) )
   ` ASSUME_TAC);;
   e (SUBGOAL_THEN `(((inv (Cx (a))) = Cx (&0)) = (Cx (a) = Cx(&0)) )
   ` ASSUME_TAC);;
       e (ONCE_REWRITE_TAC [ COMPLEX_INV_EQ_0]);;
       
       e (ONCE_ASM_REWRITE_TAC []);;
       e (ONCE_ASM_REWRITE_TAC []);;
       e (POP_ASSUM (K ALL_TAC));;
    e (ONCE_ASM_REWRITE_TAC []);;
    e (ONCE_ASM_REWRITE_TAC []);;
  e (UNDISCH_TAC `~(inv (Cx a) = Cx (&0))`);;
  e (SIMP_TAC [COMPLEX_EQ_LDIV_EQ]);;
  e (DISCH_TAC);;
  e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB ]);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `( (Cx a * s pow 2) * inv (Cx a) + (Cx b * s) * inv (Cx a) =
  inv (Cx a) * --Cx c ) = ( ((Cx a * s pow 2) * inv (Cx a) + (Cx b * s) * inv (Cx a)) + Cx (&0) =
  inv (Cx a) * --Cx c)`]);;

  e (SUBGOAL_THEN `Cx (&0) = 
    ( ((Cx b) pow 2 ) * inv (Cx (&4) * ((Cx a) pow 2 ) ) ) -  ( ((Cx b) pow 2 ) * inv (Cx (&4) * ((Cx a) pow 2 ) ) ) 
     	` ASSUME_TAC);;
        e (ONCE_REWRITE_TAC [ EQ_SYM_EQ]);;
	e (SIMPLE_COMPLEX_ARITH_TAC);;

  e (UNDISCH_TAC `Cx (&0) =
      Cx b pow 2 * inv (Cx (&4) * Cx a pow 2) -
      Cx b pow 2 * inv (Cx (&4) * Cx a pow 2)`);;
  e (SIMP_TAC []);;
  e (DISCH_TAC);;
  e (POP_ASSUM (K ALL_TAC));;
  (*----*)

  (*------*)
  (*---up---*)
 e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((((a:complex) + b) + c - d) = (a + b + c - d ))`]);;
(*------*)
(*------*)

  (*---*)
  (*-up--*)
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) + b + c - d) = ((a + b + c) - d ))`]);;
(*--*)
  e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
  e (ONCE_REWRITE_TAC [ COMPLEX_EQ_SUB_LADD]);;
  e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
  e (SUBGOAL_THEN `(Cx a * s pow 2) * inv (Cx a) =  (s pow 2)  ` ASSUME_TAC);;
  e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((Cx a * s pow 2) * inv (Cx a) = s pow 2) = 
     		       	((Cx a * s pow 2) * inv (Cx a) = Cx (&1) * s pow 2)`]);;
			
  e (SUBGOAL_THEN `Cx (&1) = inv (Cx a) * (Cx a) ` ASSUME_TAC);;
    		      e (UNDISCH_TAC `~(Cx (&0) = Cx a)`);;		  
    		      e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
    		      e (ONCE_REWRITE_TAC [COMPLEX_MUL_LINV]);;
    		      e (SIMPLE_COMPLEX_ARITH_TAC);;
    
  e (UNDISCH_TAC `Cx (&1) = inv (Cx a) * Cx a`);;
  e (SIMP_TAC []);;
  e (DISCH_TAC);;
  e (SIMPLE_COMPLEX_ARITH_TAC);;
  e (UNDISCH_TAC `(Cx a * s pow 2) * inv (Cx a) = s pow 2`);;
  e (SIMP_TAC []);;
  e (DISCH_TAC);;
  e (POP_ASSUM (K ALL_TAC));;
  
  e (SUBGOAL_THEN `(s pow 2 + (Cx b * s) * inv (Cx a) + Cx b pow 2 * inv (Cx (&4) * Cx a pow 2))  =
    		    (( s + (Cx b) * inv (Cx (&2) * Cx (a))) pow 2)` ASSUME_TAC);;
  		       	  e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
			  e (REWRITE_TAC [COMPLEX_POW_2]);;
			  e (ONCE_REWRITE_TAC [COMPLEX_ADD_LDISTRIB]);;
			  e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
			  e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_2]);;
			  e (ONCE_REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;
  
  
  e (ONCE_REWRITE_TAC [COMPLEX_ADD_LDISTRIB]);;
  e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
(*------*)

(*------*)
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((((a:complex)*b)*d) = 
     		       	(d*a*b))`]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex) + b + b + c) = 
     		       	(a + Cx(&2)*b + c))`]);;

(*-----*)
  e (ONCE_REWRITE_TAC [ COMPLEX_INV_MUL ]);;

  
  e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC ]);;
  (*------*)
 
(*---*)
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex)*b*c*d*e) = 
     		       	((a*d)*e*c*b))`]);;
(*----*)
  e (SUBGOAL_THEN `~( Cx (&2) = Cx (&0) )` ASSUME_TAC);;
		     e (SIMPLE_COMPLEX_ARITH_TAC);;
		     e (UNDISCH_TAC `~(Cx (&2) = Cx (&0))`);;
  e (DISCH_TAC);;
  e (SUBGOAL_THEN `(Cx (&2) * inv (Cx (&2))) = Cx (&1)` ASSUME_TAC);;
    		     e (UNDISCH_TAC `~( Cx (&2) = Cx (&0) )`);;
		     e (ONCE_REWRITE_TAC [COMPLEX_MUL_RINV]);;

  e (UNDISCH_TAC `Cx (&2) * inv (Cx (&2)) = Cx (&1)`);;
  e (SIMP_TAC []);;
  e (DISCH_TAC);;
  e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL]);;
  e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL]);;
   e (ONCE_REWRITE_TAC [COMPLEX_POW_INV]);;
e (ONCE_REWRITE_TAC [COMPLEX_POW_2]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((Cx (&2) * Cx (&2))) = 
     		       	(Cx (&4))`]);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((Cx (&1) * a * b * c)) = 
     		       	(a*b*c)`]);;

 e (SIMPLE_COMPLEX_ARITH_TAC);;

 e (UNDISCH_TAC `s pow 2 +
      (Cx b * s) * inv (Cx a) +
      Cx b pow 2 * inv (Cx (&4) * Cx a pow 2) =
      (s + Cx b * inv (Cx (&2) * Cx a)) pow 2`);;
 e (SIMP_TAC []);;
 e (DISCH_TAC);;

e (ONCE_REWRITE_TAC [COMPLEX_MUL_RNEG]);;

e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(--a + b) = 
     		       	(b + --a)`]);;

 e (ONCE_REWRITE_TAC [GSYM complex_sub]);;
(*------------------conjunction------------*)
e (REPEAT STRIP_TAC);;	 
e (UNDISCH_TAC `s =
      (Cx (--b) + csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
      (Cx (&2) * Cx a)`);;

e (SIMP_TAC [CX_NEG]);;
 e (DISCH_TAC);;
 e (ONCE_REWRITE_TAC [complex_div]);;
 e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
 e (ONCE_REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;

 e (ONCE_REWRITE_TAC [COMPLEX_ADD_SYM]);;
  e (ONCE_REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;
  e (SUBGOAL_THEN `(csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a) +
  Cx b * inv (Cx (&2) * Cx a) +
  --Cx b * inv (Cx (&2) * Cx a)) =(csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a) +
  Cx b * inv (Cx (&2) * Cx a) -
  Cx b * inv (Cx (&2) * Cx a))  ` ASSUME_TAC);;
 e (ONCE_REWRITE_TAC [complex_sub]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a) +
      Cx b * inv (Cx (&2) * Cx a) +
      --Cx b * inv (Cx (&2) * Cx a) =
      csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a) +
      Cx b * inv (Cx (&2) * Cx a) - Cx b * inv (Cx (&2) * Cx a)`);;
 e (SIMP_TAC []);;
 e (DISCH_TAC);;
 e (SUBGOAL_THEN `(csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a) +
  Cx b * inv (Cx (&2) * Cx a) - Cx b * inv (Cx (&2) * Cx a)) = (csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a) +
 ( Cx b * inv (Cx (&2) * Cx a) - Cx b * inv (Cx (&2) * Cx a) )) ` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [complex_sub]);;
e (ONCE_REWRITE_TAC [COMPLEX_SUB_REFL]);;
e (ONCE_REWRITE_TAC [COMPLEX_ADD_RID ]);;
e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL ]);;

e (ONCE_REWRITE_TAC [CSQRT ]);;

e (ONCE_REWRITE_TAC [COMPLEX_POW_INV]);;
e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL ]);;
e (ONCE_REWRITE_TAC [COMPLEX_INV_MUL]);;
e (ONCE_REWRITE_TAC [COMPLEX_SUB_RDISTRIB]);;
e (SUBGOAL_THEN `(Cx (&4) * Cx a * Cx c) * inv (Cx (&2) pow 2) * inv (Cx a pow 2) =( 
  		(Cx (&4) * inv (Cx (&2) pow 2) ) * (Cx a * inv (Cx a pow 2))* Cx c) ` ASSUME_TAC);;

e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `((Cx (&4) * Cx a * Cx c) * inv (Cx (&2) pow 2) * inv (Cx a pow 2) =
      (Cx (&4) * inv (Cx (&2) pow 2)) * (Cx a * inv (Cx a pow 2)) * Cx c)`);;
 e (SIMP_TAC []);;
 e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [COMPLEX_POW_2 ]);;
e (ONCE_REWRITE_TAC [COMPLEX_INV_MUL]);;


e (SUBGOAL_THEN `(( inv (Cx (&2)) * inv (Cx (&2))) = 
  		   ( inv (Cx (&4))))` ASSUME_TAC);;

e (ONCE_REWRITE_TAC [GSYM COMPLEX_INV_MUL]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `(inv (Cx (&2)) * inv (Cx (&2)) = inv (Cx (&4)))`);;
 e (SIMP_TAC []);;
 e (DISCH_TAC);;

e (SUBGOAL_THEN `~(Cx(&4) = Cx(&0))` ASSUME_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

e (SUBGOAL_THEN `((Cx (&4) * inv (Cx (&4))) = Cx(&1))` ASSUME_TAC);;

e (UNDISCH_TAC `~(Cx (&4) = Cx (&0))`);;

e (ONCE_REWRITE_TAC [COMPLEX_MUL_RINV]);;
e (UNDISCH_TAC `Cx (&4) * inv (Cx (&4)) = Cx (&1)`);;
e (SIMP_TAC []);;
 e (DISCH_TAC);;
e (POP_ASSUM (K ALL_TAC));;

e (POP_ASSUM (K ALL_TAC));;
e (POP_ASSUM (K ALL_TAC));;
e (POP_ASSUM (K ALL_TAC));;
e (POP_ASSUM (K ALL_TAC));;

e (POP_ASSUM (K ALL_TAC));;

e (SUBGOAL_THEN `(Cx a * inv (Cx a) * inv (Cx a)) =
  		   ((Cx a * inv (Cx a)) * inv (Cx a))  ` ASSUME_TAC);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_MUL_ASSOC]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `Cx a * inv (Cx a) * inv (Cx a) = (Cx a * inv (Cx a)) * inv (Cx a)`);;
e (SIMP_TAC []);;
 e (DISCH_TAC);;
e (SUBGOAL_THEN `((Cx a * inv (Cx a)) = Cx(&1))  ` ASSUME_TAC);;

e (UNDISCH_TAC `~(Cx (&0) = Cx a)`);;
e (SIMP_TAC [EQ_SYM_EQ]);;
 e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [EQ_SYM_EQ]);;
e (UNDISCH_TAC `~(Cx a = Cx (&0))`);;
e (ONCE_REWRITE_TAC [COMPLEX_MUL_RINV]);;
e (UNDISCH_TAC `Cx a * inv (Cx a) = Cx (&1)`);;
e (SIMP_TAC []);;
 e (DISCH_TAC);;
e (SIMPLE_COMPLEX_ARITH_TAC);;
(*-----------------------*)
e (UNDISCH_TAC `s =
      (Cx (--b) - csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c)) /
      (Cx (&2) * Cx a)`);;
e (SIMP_TAC [CX_NEG]);;
 e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [complex_div]);;
 e (ONCE_REWRITE_TAC [COMPLEX_ADD_RDISTRIB]);;
 e (ONCE_REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;

 e (ONCE_REWRITE_TAC [COMPLEX_ADD_SYM]);;
  e (ONCE_REWRITE_TAC [GSYM COMPLEX_ADD_ASSOC]);;
  e (ONCE_REWRITE_TAC [COMPLEX_SUB_RDISTRIB]);;

e (SUBGOAL_THEN `(Cx b * inv (Cx (&2) * Cx a) +
  --Cx b * inv (Cx (&2) * Cx a) -
  csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a)) =
(Cx (&0) -
  csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a))
   ` ASSUME_TAC);;
     		  
     e (SIMPLE_COMPLEX_ARITH_TAC);;

e (UNDISCH_TAC `Cx b * inv (Cx (&2) * Cx a) +
      --Cx b * inv (Cx (&2) * Cx a) -
      csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a) =
      Cx (&0) -
      csqrt (Cx b pow 2 - Cx (&4) * Cx a * Cx c) * inv (Cx (&2) * Cx a)`);;
e (SIMP_TAC []);;
 e (DISCH_TAC);;
  e (ONCE_REWRITE_TAC [COMPLEX_POW_2]);;
  e (ONCE_REWRITE_TAC [complex_sub]);;
 e (ONCE_REWRITE_TAC [COMPLEX_ADD_LDISTRIB]);;


e (COMPLEX_MUL);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx(&0) + --a) = 
     		       	(--a)`]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(--a * Cx(&0)) = 
     		       	(Cx(&0))`]);;
 e (ONCE_REWRITE_TAC [COMPLEX_NEG_MUL2]);;
 e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_2]);;
 e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL]);;
 e (ONCE_REWRITE_TAC [CSQRT]);;
e (ONCE_REWRITE_TAC [COMPLEX_SUB_RDISTRIB]);;
e (ONCE_REWRITE_TAC [COMPLEX_POW_INV]);;
 e (ONCE_REWRITE_TAC [COMPLEX_POW_MUL]);;
 e (ONCE_REWRITE_TAC [COMPLEX_POW_2]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((Cx (&2) * Cx (&2))) = 
     		       	(Cx (&4))`]);;
 e (ONCE_REWRITE_TAC [COMPLEX_INV_MUL]);;
 e (ONCE_REWRITE_TAC [COMPLEX_INV_MUL]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(((a:complex)*b*c)*d*e*f) = 
     		       	((a*d)*(b*e)*(f*c))`]);;
e (SUBGOAL_THEN `~(Cx (&4)=Cx (&0))
   ` ASSUME_TAC);;
     		  
     e (SIMPLE_COMPLEX_ARITH_TAC);;
e (UNDISCH_TAC `~(Cx (&4) = Cx (&0))`);;
e (SIMP_TAC [COMPLEX_MUL_RINV]);;
 e (DISCH_TAC);;
e (UNDISCH_TAC `~(Cx (&0) = Cx a)`);;
e (SIMP_TAC [EQ_SYM_EQ]);;
e (SIMP_TAC [COMPLEX_MUL_RINV]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_2]);;
e (ONCE_REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (&0) + ((a:complex)*b*c)-
     Cx (&1) * Cx (&1) * d *e  ) = 
     		       	(((a:complex)*b*c)-d *e )`]);;
 e (DISCH_TAC);;
e (ONCE_REWRITE_TAC [GSYM complex_sub]);;
  e (SIMPLE_COMPLEX_ARITH_TAC);;
let QUADRATIC_FORMULA = top_thm();;


   (*==========================================================*)
   (*******************CUBIC POLYNOMIAL*************************)
   (************************************************************)
   (*==========================================================*)

(*-*-*-*-*-*-*-*-*-*-*-CUBIC FACTORIZATION-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-* *-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 

g `!a b1 c1 d1 r (s:complex). 
   Cx(b) = Cx(b1) + Cx(a * r) /\
   Cx(c) = Cx(c1) + Cx(b1 * r)  /\
   Cx(d) = Cx(c1 * r)  
   ==> ((Cx(a) * s pow 3 + Cx(b) * s pow 2 + Cx(c) * s  + Cx(d) = Cx(&0)) <=>
        ((s + Cx(r)) *  ((Cx(a) * (s pow 2 )) + (Cx (b1) * (s)) + Cx (c1) )  = Cx(&0)))`;;


e (REPEAT STRIP_TAC THEN ASM_SIMP_TAC []);;
e (SIMP_TAC [COMPLEX_FIELD `((a:complex) + b ) *
 (d + e + f)  = 
  	    		      (a*d + a * e + a * f +  b * d + b * e + b * f )   
			       `]);;
e (ONCE_REWRITE_TAC [GSYM COMPLEX_POW_3; COMPLEX_POW_2]);;
e (ONCE_REWRITE_TAC [COMPLEX_RING `( 
s * Cx a * s * s +
 s * Cx b1 * s +
 s * Cx c1 +
 Cx r * Cx a * s * s +
 Cx r * Cx b1 * s +
 Cx r * Cx c1
   )  = 

 ( Cx a * s * s * s +
   Cx b1 * s * s + Cx r * Cx a * s * s +
   Cx c1 * s + Cx r * Cx b1 * s +
   Cx r * Cx c1
 )   
			       `]);;
e (SIMP_TAC [COMPLEX_RING `((Cx b1 * s * s +
 Cx r * Cx a * s * s) = ((Cx b1  +
 Cx r * Cx a ) * s * s) )  /\ 
 ( (Cx c1 * s +
 Cx r * Cx b1 * s) = ((Cx c1  +
 Cx r * Cx b1) * s) )`]);;
e (SIMPLE_COMPLEX_ARITH_TAC);;

let CUBIC_FACT = top_thm ();;

(*-*-*-*-*-*-*-*-*-*-*-CUBIC ROOTS-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-* *-*-*-*-*-*-*-*)
(*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*)
 

g `!a b1 c1 d1 r s.
         ~(Cx (&0) = Cx (a)) /\ 
	 Cx b = Cx b1 + Cx (a * r) /\
         Cx c = Cx c1 + Cx (b1 * r) /\
         Cx d = Cx (c1 * r)
         ==> ( ( (Cx a * s pow 3 + Cx b * s pow 2 + Cx c * s + Cx d = Cx (&0))) 
         = ( (s = --Cx(r))  \/ (s =
 (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
 (Cx (&2) * Cx a) ) \/ (s =
 (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
 (Cx (&2) * Cx a) )) )  `;;

e (REPEAT STRIP_TAC);;
e (SUBGOAL_THEN `(Cx a * s pow 3 + Cx b * s pow 2 + Cx c * s + Cx d = Cx (&0) <=>
              (s + Cx r) * (Cx a * s pow 2 + Cx b1 * s + Cx c1) = Cx (&0))` ASSUME_TAC );;
e (MATCH_MP_TAC CUBIC_FACT);;
e (ASM_SIMP_TAC []);;
e (ONCE_ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC [COMPLEX_RING `((s + Cx r) * (Cx a * s pow 2 + Cx b1 * s + Cx c1) = Cx (&0)) = ( (s + Cx r) = Cx (&0)  \/
 ((Cx a * s pow 2 + Cx b1 * s + Cx c1) =
 Cx (&0) )) `]);;
e (ASM_SIMP_TAC []);;
e (ONCE_REWRITE_TAC [COMPLEX_RING `(s + Cx r = Cx (&0)) = (s = --Cx r)`]);;



e (SUBGOAL_THEN `( Cx a * s pow 2 + Cx b1 * s + Cx c1 = Cx (&0)) = (s =
 (Cx (--b1) + csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
 (Cx (&2) * Cx a) \/
 s =
 (Cx (--b1) - csqrt (Cx b1 pow 2 - Cx (&4) * Cx a * Cx c1)) /
 (Cx (&2) * Cx a))` ASSUME_TAC);;
e (MATCH_MP_TAC QUADRATIC_FORMULA);;
e (ASM_SIMP_TAC []);;
e (ASM_REWRITE_TAC []);;


let CUBIC_ROOTS = top_thm();;


