
(* ========================================================================= *)
(*                                                                           *)
(*                          STABLE MATRICES                                  *)
(*                                                                           *)
(*     (c)  Ujala Qasim                                                      *)
(* 	    SYSTEM ANALYSIS & VERIFICATION (SAVe) LAB                        *)
(*	    National University of Sciences and Technology (NUST), PAKISTAN  *)
(*   Last update: September 22, 2020                                         *)
(*                                                                           *)
(* ========================================================================= *)


(*---------------------------------------------------------------------------*)
(*                          Theories to load                                 *)
(*---------------------------------------------------------------------------*)


Load "Properties of stability.ml" 
Load "stable_polynomial.ml"


(* -----------------------------STABLE_2x2_MATRIX---------------------------------- *)

 
 g `!a11 a12 a21 a22.
 (&0 < (-- a11 - a22) /\
  ((-- a11 - a22) pow 2 - &4 * (a11 * a22 - a12 * a21) < &0 \/
   (-- a11 - a22) pow 2 - &4  * (a11 * a22 - a12 * a21) = &0) \/
  &0 < (-- a11 - a22) pow 2 - &4  * (a11 * a22 - a12 * a21) /\
  (sqrt ((-- a11 - a22) pow 2 - &4 * (a11 * a22 - a12 * a21)) < (--a11 - a22) \/
     (a11 + a22) < sqrt ((-- a11 - a22) pow 2 - &4  * (a11 * a22 - a12 * a21))))
  ==> stable_sys ((vector [vector [Cx(a11); Cx(a12)];
       vector [Cx(a21); Cx(a22)]]): (complex)^2^2)`;;
 

e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [ stable_sys]);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC [IN_ELIM_THM]);;
e (SIMP_TAC [GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT]);;
e (SIMP_TAC [CDET_2]);;
e (SIMP_TAC [CMATRIX_SUB_COMPONENT]);;
e (REWRITE_TAC [MATRIX_2x2]);;
e (SUBGOAL_THEN`1 <= 1 /\ 1 <= dimindex (:2) /\ 1 <= 2 /\ 2 <= dimindex (:2)` ASSUME_TAC);;
e (SIMP_TAC [DIMINDEX_2;ARITH]);;
e (ASM_SIMP_TAC [CMAT_COMPONENT]);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_SUB_RZERO]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((Cx a11 - x) * (Cx a22 - x) - Cx a12 * Cx a21 = Cx (&0)) = 
                                        ( x * x + Cx(-- a11 - a22)* x + Cx(a11 * a22 - a12 * a21) = Cx(&0))`]);;

e (REWRITE_TAC [GSYM COMPLEX_POW_2]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(x pow 2 + Cx (-- a11 - a22) * x + Cx (a11 * a22 - a12 * a21) = Cx (&0)) = 
                                       (Cx(&1) * x pow 2 + Cx(-- a11 - a22) * x + Cx(a11 * a22 - a12 * a21) = Cx (&0))`]);;

e (MATCH_MP_TAC QUAD_ALL_STABLE_CASES);;
e (SIMP_TAC[SIMPLE_COMPLEX_ARITH `~(Cx (&0) = Cx (&1))`]);;
e (REWRITE_TAC [REAL_MUL_LID; REAL_DIV_1]);;
e (SIMP_TAC[REAL_ARITH `~(&1 < &0)` ]);;
e (SIMP_TAC[REAL_ARITH `(&0 < &1)` ]);;
e (REWRITE_TAC [REAL_SUB_LNEG;REAL_NEG_NEG]);;
e (REWRITE_TAC [GSYM REAL_SUB_LNEG]);;
e (ASM_REWRITE_TAC[]);;


let STABLE_MATRIX_2x2 = top_thm();;


(* -----------------------------UNSTABLE_2x2_MATRIX---------------------------------- *)

g `!a11 a12 a21 a22. 
((-- a11 - a22) < &0 /\
  ((-- a11 - a22) pow 2 - &4 * (a11 * a22 - a12 * a21) < &0 \/
   (-- a11 - a22) pow 2 - &4  * (a11 * a22 - a12 * a21) = &0) \/
  &0 < (-- a11 - a22) pow 2 - &4  * (a11 * a22 - a12 * a21) /\
  ((--a11 - a22) < sqrt ((-- a11 - a22) pow 2 - &4 * (a11 * a22 - a12 * a21)) \/
     sqrt ((-- a11 - a22) pow 2 - &4  * (a11 * a22 - a12 * a21)) < (a11 + a22)))
  ==> unstable_sys ((vector [vector [Cx(a11); Cx(a12)];
       vector [Cx(a21); Cx(a22)]]): (complex)^2^2)`;;
 

e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [unstable_sys]);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC [IN_ELIM_THM]);;
e (SIMP_TAC [GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT]);;
e (SIMP_TAC [CDET_2]);;
e (SIMP_TAC [CMATRIX_SUB_COMPONENT]);;
e (REWRITE_TAC [MATRIX_2x2]);;
e (SUBGOAL_THEN`1 <= 1 /\ 1 <= dimindex (:2) /\ 1 <= 2 /\ 2 <= dimindex (:2)` ASSUME_TAC);;
e (SIMP_TAC [DIMINDEX_2;ARITH]);;
e (ASM_SIMP_TAC [CMAT_COMPONENT]);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_SUB_RZERO]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((Cx a11 - x) * (Cx a22 - x) - Cx a12 * Cx a21 = Cx (&0)) = 
                                        ( x * x + Cx(-- a11 - a22)* x + Cx(a11 * a22 - a12 * a21) = Cx(&0))`]);;

e (REWRITE_TAC [GSYM COMPLEX_POW_2]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(x pow 2 + Cx (-- a11 - a22) * x + Cx (a11 * a22 - a12 * a21) = Cx (&0)) = 
                                       (Cx(&1) * x pow 2 + Cx(-- a11 - a22) * x + Cx(a11 * a22 - a12 * a21) = Cx (&0))`]);;

e (MATCH_MP_TAC QUAD_ALL_UNSTABLE_CASES);;
e (SIMP_TAC[SIMPLE_COMPLEX_ARITH `~(Cx (&0) = Cx (&1))`]);;
e (REWRITE_TAC [REAL_MUL_LID; REAL_DIV_1]);;
e (SIMP_TAC[REAL_ARITH `~(&1 < &0)` ]);;
e (SIMP_TAC[REAL_ARITH `(&0 < &1)` ]);;
e (REWRITE_TAC [REAL_SUB_LNEG;REAL_NEG_NEG]);;
e (REWRITE_TAC [GSYM REAL_SUB_LNEG]);;
e (ASM_REWRITE_TAC[]);;


let UNSTABLE_MATRIX_2x2 = top_thm();;


(* ----------------------MARGINALLY_STABLE_2x2_MATRIX--------------------------- *)

g `!a11 a12 a21 a22. 
((-- a11 - a22) = &0 /\
  ((-- a11 - a22) pow 2 - &4 * (a11 * a22 - a12 * a21) < &0 \/
   (-- a11 - a22) pow 2 - &4  * (a11 * a22 - a12 * a21) = &0) \/
  &0 < (-- a11 - a22) pow 2 - &4  * (a11 * a22 - a12 * a21) /\
  (sqrt ((-- a11 - a22) pow 2 - &4 * (a11 * a22 - a12 * a21)) = (--a11 - a22) \/
     sqrt ((-- a11 - a22) pow 2 - &4  * (a11 * a22 - a12 * a21)) = (a11 + a22)))
  ==> marginally_stable_sys ((vector [vector [Cx(a11); Cx(a12)];
       vector [Cx(a21); Cx(a22)]]): (complex)^2^2)`;;
 

e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [marginally_stable_sys]);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC [IN_ELIM_THM]);;
e (SIMP_TAC [GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT]);;
e (SIMP_TAC [CDET_2]);;
e (SIMP_TAC [CMATRIX_SUB_COMPONENT]);;
e (REWRITE_TAC [MATRIX_2x2]);;
e (SUBGOAL_THEN`1 <= 1 /\ 1 <= dimindex (:2) /\ 1 <= 2 /\ 2 <= dimindex (:2)` ASSUME_TAC);;
e (SIMP_TAC [DIMINDEX_2;ARITH]);;
e (ASM_SIMP_TAC [CMAT_COMPONENT]);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_SUB_RZERO]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `((Cx a11 - x) * (Cx a22 - x) - Cx a12 * Cx a21 = Cx (&0)) = 
                                        ( x * x + Cx(-- a11 - a22)* x + Cx(a11 * a22 - a12 * a21) = Cx(&0))`]);;

e (REWRITE_TAC [GSYM COMPLEX_POW_2]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(x pow 2 + Cx (-- a11 - a22) * x + Cx (a11 * a22 - a12 * a21) = Cx (&0)) = 
                                       (Cx(&1) * x pow 2 + Cx(-- a11 - a22) * x + Cx(a11 * a22 - a12 * a21) = Cx (&0))`]);;

e (MATCH_MP_TAC QUAD_ALL_MARGINALLY_STABLE_CASES);;
e (SIMP_TAC[SIMPLE_COMPLEX_ARITH `~(Cx (&0) = Cx (&1))`]);;
e (REWRITE_TAC [REAL_MUL_LID; REAL_DIV_1]);;
e (SIMP_TAC[REAL_ARITH `~(&1 < &0)` ]);;
e (SIMP_TAC[REAL_ARITH `(&0 < &1)` ]);;
e (REWRITE_TAC [REAL_SUB_LNEG;REAL_NEG_NEG]);;
e (REWRITE_TAC [GSYM REAL_SUB_LNEG]);;
e (ASM_REWRITE_TAC[]);;


let MARGINALLY_STABLE_MATRIX_2x2 = top_thm();;


(* -----------------------------STABLE_3x3_MATRIX---------------------------------- *)

g `!a11 a12 a13 a21 a22 a23 a31 a32 a33 a b1 c1 d1 r. 
     Cx (--a33 - a22 - a11) = Cx b1 + Cx (r) /\
     Cx
     (--a13 * a31 - a12 * a21 - a23 * a32 +
      a22 * a33 +
      a11 * a33 +
      a11 * a22) =
     Cx c1 + Cx (b1 * r) /\
     Cx
     (--a11 * a22 * a33 - a12 * a31 * a23 - a13 * a21 * a32 +
      a11 * a23 * a32 +
      a12 * a21 * a33 +
      a13 * a31 * a22) =
     Cx (c1 * r) /\
     (&0 < r \/
      &0 < b1 /\
      (b1 pow 2 - &4 * c1 < &0 \/ b1 pow 2 - &4 * c1 = &0) \/
      &0 < b1 pow 2 - &4 * c1 /\
      ((sqrt (b1 pow 2 - &4 * c1) < b1 \/
        --b1 < sqrt (b1 pow 2 - &4 * c1))))
    ==> stable_sys ((vector [vector [Cx(a11); Cx(a12); Cx(a13)];
                   vector [Cx(a21); Cx(a22); Cx(a23)]; vector [Cx(a31); Cx(a32); Cx(a33)]]): (complex)^3^3)`;;


e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [ stable_sys]);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC [IN_ELIM_THM]);;
e (SIMP_TAC [GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT]);;
e (SIMP_TAC [CDET_3]);;
e (SIMP_TAC [CMATRIX_SUB_COMPONENT]);;
e (REWRITE_TAC [MATRIX_3x3]);;
e (SUBGOAL_THEN `(1 <= 1 /\ 1 <= dimindex (:3)) /\
         (1 <= 2 /\ 2 <= dimindex (:3)) /\ (1 <= 3 /\ 3 <= dimindex (:3))`ASSUME_TAC);;
e (SIMP_TAC [DIMINDEX_3;ARITH]);;
e (ASM_SIMP_TAC [CMAT_COMPONENT]);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_SUB_RZERO]);;
       

e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `
   ((Cx a11 - x) * (Cx a22 - x) * (Cx a33 - x) +
        Cx a12 * Cx a23 * Cx a31 +
       Cx a13 * Cx a21 * Cx a32 -
       (Cx a11 - x) * Cx a23 * Cx a32 -
       Cx a12 * Cx a21 * (Cx a33 - x) -
       Cx a13 * (Cx a22 - x) * Cx a31 = Cx (&0) ) =
       ( --Cx(&1) * x * x * x + Cx(a33 + a22 + a11) * x * x +
        Cx(a13 * a31 + a12 * a21 + a23 * a32 - a22 * a33 - a11 * a33 - a11 * a22) * x +
	 Cx(a11 * a22 * a33 + a12 * a31 * a23 + a13 * a21 * a32 - a11 * a23 * a32 - a12 * a21 * a33 - a13 * a31 * a22)= Cx(&0) )`]);;


e (REWRITE_TAC [ COMPLEX_POW_3]);;
e (REWRITE_TAC [GSYM COMPLEX_POW_2]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `--Cx(&1) = Cx(-- &1)`]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (-- &1) * x pow 3 +
       Cx (a33 + a22 + a11) * x pow 2 +
       Cx
       (a13 * a31 +
        a12 * a21 +
        a23 * a32 - a22 * a33 - a11 * a33 - a11 * a22) *
       x +
       Cx
       (a11 * a22 * a33 +
        a12 * a31 * a23 +
        a13 * a21 * a32 - a11 * a23 * a32 - a12 * a21 * a33 - a13 * a31 * a22) =
       Cx (&0)) = ( Cx(&1) * x pow 3 + Cx (-- a33 - a22 - a11) * x pow 2 +
       Cx (-- a13 * a31 -
        a12 * a21 -
        a23 * a32 + a22 * a33 + a11 * a33 + a11 * a22) * x +
       Cx (-- a11 * a22 * a33 -
        a12 * a31 * a23 -
        a13 * a21 * a32 + a11 * a23 * a32 + a12 * a21 * a33 + a13 * a31 * a22) =
       Cx (&0))`]);;
e (MATCH_MP_TAC CUBIC_ALL_STABLE_CASES);;
e (EXISTS_TAC ` b1:real`);;
e (EXISTS_TAC ` c1:real`);;
e (EXISTS_TAC ` r:real`);;
e (SIMP_TAC [SIMPLE_COMPLEX_ARITH `~(Cx (&0) = Cx (&1))`]);;
e (REWRITE_TAC [CX_MUL; COMPLEX_MUL_LID; REAL_MUL_LID; REAL_DIV_1]);;
e (REWRITE_TAC [GSYM CX_MUL]);;
e (ASM_REWRITE_TAC[]);;
e (SIMP_TAC[REAL_ARITH `~(&1 < &0)` ]);;
e (SIMP_TAC[REAL_ARITH `(&0 < &1)` ]);;
e (ASM_REWRITE_TAC[]);;


let STABLE_MATRIX_3x3 = top_thm();;


(* -----------------------------UNSTABLE_3x3_MATRIX---------------------------------- *)

g `!a11 a12 a13 a21 a22 a23 a31 a32 a33 a b1 c1 d1 r. 
     Cx (--a33 - a22 - a11) = Cx b1 + Cx (r) /\
     Cx
     (--a13 * a31 - a12 * a21 - a23 * a32 +
      a22 * a33 +
      a11 * a33 +
      a11 * a22) =
     Cx c1 + Cx (b1 * r) /\
     Cx
     (--a11 * a22 * a33 - a12 * a31 * a23 - a13 * a21 * a32 +
      a11 * a23 * a32 +
      a12 * a21 * a33 +
      a13 * a31 * a22) =
     Cx (c1 * r) /\
     (r < &0 \/
      b1 < &0 /\
      (b1 pow 2 - &4 * c1 < &0 \/ b1 pow 2 - &4 * c1 = &0) \/
      &0 < b1 pow 2 - &4 * c1 /\
      ((b1 < sqrt (b1 pow 2 - &4 * c1) \/
       sqrt (b1 pow 2 - &4 * c1) < --b1)))
    ==> unstable_sys ((vector [vector [Cx(a11); Cx(a12); Cx(a13)];
                   vector [Cx(a21); Cx(a22); Cx(a23)]; vector [Cx(a31); Cx(a32); Cx(a33)]]): (complex)^3^3)`;;


e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [unstable_sys]);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC [IN_ELIM_THM]);;
e (SIMP_TAC [GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT]);;
e (SIMP_TAC [CDET_3]);;
e (SIMP_TAC [CMATRIX_SUB_COMPONENT]);;
e (REWRITE_TAC [MATRIX_3x3]);;
e (SUBGOAL_THEN `(1 <= 1 /\ 1 <= dimindex (:3)) /\
         (1 <= 2 /\ 2 <= dimindex (:3)) /\ (1 <= 3 /\ 3 <= dimindex (:3))`ASSUME_TAC);;
e (SIMP_TAC [DIMINDEX_3;ARITH]);;
e (ASM_SIMP_TAC [CMAT_COMPONENT]);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_SUB_RZERO]);;
       

e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `
   ((Cx a11 - x) * (Cx a22 - x) * (Cx a33 - x) +
        Cx a12 * Cx a23 * Cx a31 +
       Cx a13 * Cx a21 * Cx a32 -
       (Cx a11 - x) * Cx a23 * Cx a32 -
       Cx a12 * Cx a21 * (Cx a33 - x) -
       Cx a13 * (Cx a22 - x) * Cx a31 = Cx (&0) ) =
       ( --Cx(&1) * x * x * x + Cx(a33 + a22 + a11) * x * x +
        Cx(a13 * a31 + a12 * a21 + a23 * a32 - a22 * a33 - a11 * a33 - a11 * a22) * x +
	 Cx(a11 * a22 * a33 + a12 * a31 * a23 + a13 * a21 * a32 - a11 * a23 * a32 - a12 * a21 * a33 - a13 * a31 * a22)= Cx(&0) )`]);;


e (REWRITE_TAC [ COMPLEX_POW_3]);;
e (REWRITE_TAC [GSYM COMPLEX_POW_2]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `--Cx(&1) = Cx(-- &1)`]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (-- &1) * x pow 3 +
       Cx (a33 + a22 + a11) * x pow 2 +
       Cx
       (a13 * a31 +
        a12 * a21 +
        a23 * a32 - a22 * a33 - a11 * a33 - a11 * a22) *
       x +
       Cx
       (a11 * a22 * a33 +
        a12 * a31 * a23 +
        a13 * a21 * a32 - a11 * a23 * a32 - a12 * a21 * a33 - a13 * a31 * a22) =
       Cx (&0)) = ( Cx(&1) * x pow 3 + Cx (-- a33 - a22 - a11) * x pow 2 +
       Cx (-- a13 * a31 -
        a12 * a21 -
        a23 * a32 + a22 * a33 + a11 * a33 + a11 * a22) * x +
       Cx (-- a11 * a22 * a33 -
        a12 * a31 * a23 -
        a13 * a21 * a32 + a11 * a23 * a32 + a12 * a21 * a33 + a13 * a31 * a22) =
       Cx (&0))`]);;
e (MATCH_MP_TAC CUBIC_ALL_UNSTABLE_CASES);;
e (EXISTS_TAC ` b1:real`);;
e (EXISTS_TAC ` c1:real`);;
e (EXISTS_TAC ` r:real`);;
e (SIMP_TAC [SIMPLE_COMPLEX_ARITH `~(Cx (&0) = Cx (&1))`]);;
e (REWRITE_TAC [CX_MUL; COMPLEX_MUL_LID; REAL_MUL_LID; REAL_DIV_1]);;
e (REWRITE_TAC [GSYM CX_MUL]);;
e (ASM_REWRITE_TAC[]);;
e (SIMP_TAC[REAL_ARITH `~(&1 < &0)` ]);;
e (SIMP_TAC[REAL_ARITH `(&0 < &1)` ]);;
e (ASM_REWRITE_TAC[]);;


let UNSTABLE_MATRIX_3x3 = top_thm();;

(* -----------------------------MARGINALLY_STABLE_3x3_MATRIX---------------------------------- *)

g `!a11 a12 a13 a21 a22 a23 a31 a32 a33 a b1 c1 d1 r. 
     Cx (--a33 - a22 - a11) = Cx b1 + Cx (r) /\
     Cx
     (--a13 * a31 - a12 * a21 - a23 * a32 +
      a22 * a33 +
      a11 * a33 +
      a11 * a22) =
     Cx c1 + Cx (b1 * r) /\
     Cx
     (--a11 * a22 * a33 - a12 * a31 * a23 - a13 * a21 * a32 +
      a11 * a23 * a32 +
      a12 * a21 * a33 +
      a13 * a31 * a22) =
     Cx (c1 * r) /\
     (r = &0 \/
      b1 = &0 /\
      (b1 pow 2 - &4 * c1 < &0 \/ b1 pow 2 - &4 * c1 = &0) \/
      &0 < b1 pow 2 - &4 * c1 /\
      ((sqrt (b1 pow 2 - &4 * c1) = b1 \/
       sqrt (b1 pow 2 - &4 * c1) = --b1)))
    ==> marginally_stable_sys ((vector [vector [Cx(a11); Cx(a12); Cx(a13)];
                   vector [Cx(a21); Cx(a22); Cx(a23)]; vector [Cx(a31); Cx(a32); Cx(a33)]]): (complex)^3^3)`;;


e (REPEAT GEN_TAC);;
e (DISCH_TAC);;
e (REWRITE_TAC [marginally_stable_sys]);;
e (SIMP_TAC [EXTENSION]);;
e (REWRITE_TAC [IN_ELIM_THM]);;
e (SIMP_TAC [GSYM CMAT_CMUL;CMATRIX_SUB_COMPONENT]);;
e (SIMP_TAC [CDET_3]);;
e (SIMP_TAC [CMATRIX_SUB_COMPONENT]);;
e (REWRITE_TAC [MATRIX_3x3]);;
e (SUBGOAL_THEN `(1 <= 1 /\ 1 <= dimindex (:3)) /\
         (1 <= 2 /\ 2 <= dimindex (:3)) /\ (1 <= 3 /\ 3 <= dimindex (:3))`ASSUME_TAC);;
e (SIMP_TAC [DIMINDEX_3;ARITH]);;
e (ASM_SIMP_TAC [CMAT_COMPONENT]);;
e (REWRITE_TAC [ARITH]);;
e (REWRITE_TAC [COMPLEX_SUB_RZERO]);;
       

e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `
   ((Cx a11 - x) * (Cx a22 - x) * (Cx a33 - x) +
        Cx a12 * Cx a23 * Cx a31 +
       Cx a13 * Cx a21 * Cx a32 -
       (Cx a11 - x) * Cx a23 * Cx a32 -
       Cx a12 * Cx a21 * (Cx a33 - x) -
       Cx a13 * (Cx a22 - x) * Cx a31 = Cx (&0) ) =
       ( --Cx(&1) * x * x * x + Cx(a33 + a22 + a11) * x * x +
        Cx(a13 * a31 + a12 * a21 + a23 * a32 - a22 * a33 - a11 * a33 - a11 * a22) * x +
	 Cx(a11 * a22 * a33 + a12 * a31 * a23 + a13 * a21 * a32 - a11 * a23 * a32 - a12 * a21 * a33 - a13 * a31 * a22)= Cx(&0) )`]);;


e (REWRITE_TAC [ COMPLEX_POW_3]);;
e (REWRITE_TAC [GSYM COMPLEX_POW_2]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `--Cx(&1) = Cx(-- &1)`]);;
e (REWRITE_TAC [SIMPLE_COMPLEX_ARITH `(Cx (-- &1) * x pow 3 +
       Cx (a33 + a22 + a11) * x pow 2 +
       Cx
       (a13 * a31 +
        a12 * a21 +
        a23 * a32 - a22 * a33 - a11 * a33 - a11 * a22) *
       x +
       Cx
       (a11 * a22 * a33 +
        a12 * a31 * a23 +
        a13 * a21 * a32 - a11 * a23 * a32 - a12 * a21 * a33 - a13 * a31 * a22) =
       Cx (&0)) = ( Cx(&1) * x pow 3 + Cx (-- a33 - a22 - a11) * x pow 2 +
       Cx (-- a13 * a31 -
        a12 * a21 -
        a23 * a32 + a22 * a33 + a11 * a33 + a11 * a22) * x +
       Cx (-- a11 * a22 * a33 -
        a12 * a31 * a23 -
        a13 * a21 * a32 + a11 * a23 * a32 + a12 * a21 * a33 + a13 * a31 * a22) =
       Cx (&0))`]);;
e (MATCH_MP_TAC CUBIC_ALL_MARGINALLY_STABLE_CASES);;
e (EXISTS_TAC ` b1:real`);;
e (EXISTS_TAC ` c1:real`);;
e (EXISTS_TAC ` r:real`);;
e (SIMP_TAC [SIMPLE_COMPLEX_ARITH `~(Cx (&0) = Cx (&1))`]);;
e (REWRITE_TAC [CX_MUL; COMPLEX_MUL_LID; REAL_MUL_LID; REAL_DIV_1]);;
e (REWRITE_TAC [GSYM CX_MUL]);;
e (ASM_REWRITE_TAC[]);;
e (SIMP_TAC[REAL_ARITH `~(&1 < &0)` ]);;
e (SIMP_TAC[REAL_ARITH `(&0 < &1)` ]);;
e (ASM_REWRITE_TAC[]);;


let MARGINALLY_STABLE_MATRIX_3x3 = top_thm();;


(*----------------------------END-----------------------------------*)




